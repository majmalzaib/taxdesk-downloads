"""Practice guide: for each head of income and for sales tax, what is included, what is exempt, which expenses are
admissible and which are not, how it is taxed, and a worked example; and the order in which a return is filled.

Written from the wording of the Ordinance, the Acts and the Rules in law_text.json.gz (FBR's consolidated editions in
law.text_source), and cited so every section and rule opens its card. Rates change every Finance Act, so amounts are
quoted only where the section itself states them; the slabs are on the Rules & rates page.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Example:
    title: str
    rows: tuple[tuple[str, str], ...]  # (line, amount); an amount starting "=" is a total
    result: str = ""


@dataclass(frozen=True)
class Topic:
    id: str
    title: str
    group: str  # one of GROUPS
    act: str  # the law that bare "section"/"rule" references in the text belong to
    law: str
    summary: str
    parts: tuple[tuple[str, tuple[str, ...]], ...]  # (heading, points)
    example: Example | None = None


@dataclass(frozen=True)
class Step:
    title: str
    law: str
    what: str
    children: tuple["Step", ...] = field(default=())


@dataclass(frozen=True)
class Flow:
    id: str
    title: str
    act: str
    law: str
    summary: str
    steps: tuple[Step, ...]


INCLUDED = "What is included"
EXCLUDED = "Exempt or taxed under another head"
ALLOWED = "Admissible deductions"
DISALLOWED = "Inadmissible deductions"
TAXED = "How it is taxed"
POINTS = "Practice points"

GROUPS = ("Income tax: heads of income", "Income tax: reliefs and taxes paid", "Sales tax", "Filing flows")

T = Topic
TOPICS: list[Topic] = [
    # ------------------------------------------------------------------ salary
    T("salary", "Salary", GROUPS[0], "ITO", "Sections 12–14 and 149; rules 3–5",
      "Everything an employee receives from employment, in cash or in kind, is salary. No expense can be deducted "
      "from it.",
      ((INCLUDED, (
          "Pay, wages, leave pay, payment in lieu of leave, overtime, bonus, commission, fees, gratuity and work "
          "condition supplements: section 12(2)(a).",
          "Every allowance: house rent, cost of living, utilities, conveyance, education, entertainment, travel: "
          "section 12(2)(c). An allowance paid every month as a fixed amount or a percentage of salary is salary even "
          "if it is called an official allowance (Explanation to section 12(2)(c)).",
          "Perquisites, whether convertible to money or not: section 12(2)(b), valued under section 13 and rules 3–5.",
          "Car provided for private use: 5% of the employer's cost (or the vehicle's fair market value at the start of "
          "a lease) if used partly for private and partly for official use, 10% if for private use only: rule 5 with "
          "section 13(3).",
          "Accommodation provided: what the employer would otherwise have paid, but not less than 45% of the minimum "
          "of the basic pay scale (30% where house rent allowance is 30%): rule 4 with section 13(12).",
          "Utilities provided: fair market value less what the employee pays: section 13(6). Driver, cook, guard or "
          "other domestic staff paid by the employer: their salary less what the employee pays: section 13(5).",
          "Loan from the employer above Rs 1 million at no or low profit: profit at the benchmark rate (10%) less the "
          "profit actually paid: section 13(7) and (14). A debt waived by the employer, or the employee's obligation "
          "paid by the employer, is salary: section 13(9) and (10).",
          "Property transferred or services provided by the employer: fair market value less what the employee pays: "
          "section 13(11); any other perquisite at fair market value: section 13(13).",
          "Employee's own expenses paid or reimbursed by the employer: section 12(2)(d).",
          "Joining payments, compensation for changed conditions, termination pay and golden handshake, provident fund "
          "receipts beyond the employee's own non-deducted contributions, and payment for a restrictive covenant: "
          "section 12(2)(e).",
          "Pension or annuity: section 12(2)(f), see section 12(2A).",
          "Shares under an employee share scheme: fair market value when issued (or when free to transfer) less what "
          "the employee paid: section 14(2) and (3).",
          "Tax the employer pays on the employee's behalf: the salary is grossed up by it: section 12(3).",
          "Salary from a past or future employer, from an associate of the employer or from a third party under an "
          "arrangement with the employer, or paid to the employee's associate: section 12(5).",
      )),
       (EXCLUDED, (
           "An allowance actually and solely spent in performing the duties of employment: section 12(2)(c).",
           "Reimbursement of expenses incurred on the employer's behalf in doing the job: section 12(2)(d).",
           "Medical allowance up to 10% of basic salary, where free medical treatment, hospitalisation or "
           "reimbursement is not provided; medical treatment, hospitalisation or reimbursement given under the terms "
           "of employment is exempt in full: Second Schedule, Part I, clause (139).",
           "The grant of a share option is not taxed; only the shares when issued: section 14(1).",
           "A loan from the employer of up to Rs 1 million: no perquisite (second proviso to section 13(7)).",
           "Pension: an individual aged seventy or more is not taxed on pension; pension above Rs 10 million a year "
           "from a former employer is taxed as a final tax at the rates in the proviso to clause (2) of Division I of "
           "the First Schedule: section 12(2A).",
           "Other exempt receipts are listed in Part I of the Second Schedule. Find the clause before treating a "
           "receipt as exempt.",
       )),
       (ALLOWED, (
           "None against salary. Relief comes only after the heads are added up: deductible allowances (Zakat, "
           "section 60; tuition fees, section 60D) reduce taxable income, and tax credits (donations, section 61; "
           "approved pension fund, section 63) reduce the tax.",
       )),
       (DISALLOWED, (
           "Any expense incurred by the employee in earning the salary, such as travel to work, uniforms, books, "
           "professional subscriptions and a home office: section 12(4).",
           "A loss under another head can't be set off against salary: section 56(1).",
       )),
       (TAXED, (
           "Salary joins the other normally taxed income. Where salary is more than 75% of taxable income, the "
           "salaried slabs of Division I, Part I of the First Schedule apply (Rules & rates page).",
           "The employer deducts tax every month on the expected yearly salary: section 149. That tax is a credit in "
           "the return: section 168.",
           "Arrears that push salary into a higher slab may be taxed at the rates of the years they relate to: "
           "section 12(7). A golden handshake may be taxed at the average rate of the last three years: section 12(6). "
           "Either election is made by the return's due date: section 12(8).",
       )),
       (POINTS, (
           "Start from the employer's salary certificate, then check it against the payslips: every allowance and "
           "perquisite must appear.",
           "With two employers in the year, add both salaries and both certificates' tax.",
           "A salaried person's return must be filed online with proof of tax deducted and the wealth statement: "
           "section 118(2A).",
       ))),
      Example("Annual salary of a manager", (
          ("Basic salary", "2,400,000"),
          ("House rent allowance", "960,000"),
          ("Utilities allowance", "240,000"),
          ("Medical allowance 240,000, exempt up to 10% of basic (240,000)", "0"),
          ("Company car used partly for private use, cost 4,000,000 × 5% (rule 5)", "200,000"),
          ("Performance bonus", "400,000"),
          ("Income from salary", "=4,200,000"),
      ), "Taxed at the salaried slabs. The tax the employer deducted under section 149 is subtracted from the tax "
         "on the return.")),

    # ------------------------------------------------------------------ property
    T("property", "Income from property", GROUPS[0], "ITO", "Sections 15, 15A, 16 and 155",
      "Rent received or receivable for land or a building, less the allowances of section 15A.",
      ((INCLUDED, (
          "Rent received or receivable by the owner for the use or occupation of land or a building: section 15(1) "
          "and (2).",
          "A forfeited deposit under a contract to sell land or a building: section 15(2).",
          "An amount from a tenant that is not adjustable against rent: spread over the year received and the next "
          "nine years in equal parts: section 16(1).",
          "Where rent is below the fair market rent, the fair market rent is taken, unless the tenant is taxed on it "
          "as salary: section 15(4) and (5).",
      )),
       (EXCLUDED, (
           "A building let with plant and machinery: income from other sources: sections 15(3) and 39(1)(f).",
           "The part of the rent that is for amenities, utilities or other services: income from other sources: "
           "sections 15(3A) and 39(1)(fa).",
           "Rent from a sub-lease and ground rent received: income from other sources: section 39(1)(d) and (e).",
           "Rent exempt under the Second Schedule.",
       )),
       (ALLOWED, (
           "Repairs allowance of one-fifth of the rent, worked out before any other deduction. This replaces the "
           "actual cost of repairs: section 15A(1)(a).",
           "Insurance premium on the building: section 15A(1)(b).",
           "Local rates, taxes and cess on the property or its rent (not income tax): section 15A(1)(c).",
           "Ground rent paid: section 15A(1)(d).",
           "Profit on money borrowed to buy, build, renovate, extend or rebuild the property, and profit on a "
           "mortgage: section 15A(1)(e) and (g).",
           "Rent-sharing and appreciation paid to HBFC or a bank under a rent-sharing scheme (not repayment of "
           "capital): section 15A(1)(f).",
           "Administration and collection expenses up to 4% of the rent: section 15A(1)(h).",
           "Legal expenses to defend title to the property or a suit about it: section 15A(1)(i).",
           "Rent that can't be recovered, if the tenancy was genuine, the tenant has left (or is being made to "
           "leave), legal steps were taken and the rent was taxed when due: section 15A(1)(j). If it is recovered "
           "later, it is taxed then: section 15A(2).",
       )),
       (DISALLOWED, (
           "Depreciation of the building: this head has no depreciation.",
           "Repairs beyond the one-fifth allowance, and collection expenses beyond 4% of the rent.",
           "Anything that section 21 bars for a business, such as personal expenses or large cash payments: "
           "section 15A(6).",
           "An expense already deducted under another head: section 15A(5).",
           "A deducted expense still unpaid three years after the year it was claimed becomes income: "
           "section 15A(3); it is deductible again when paid: section 15A(4).",
       )),
       (TAXED, (
           "The Finance Act 2021 omitted section 15(6) and Division VIA of Part I of the First Schedule, which taxed "
           "the rent of individuals and AOPs as a separate block. Rent less the section 15A deductions is now income "
           "under this head and part of taxable income at the normal rates.",
           "A business loss can't be set off against income from property: proviso to section 56(1).",
           "Tenants that are companies, governments, NPOs, schools, hospitals and similar bodies, and individuals paying "
           "rent of Rs 1.5 million or more a year, deduct tax under section 155. That tax is adjustable: section 168.",
       )),
       (POINTS, (
           "Keep the tenancy agreement, rent receipts, the property tax challan and the tenant's withholding "
           "certificate.",
           "Co-owners each declare their share of the rent and the deductions.",
       ))),
      Example("House let to a company", (
          ("Rent for the year", "1,800,000"),
          ("Non-adjustable deposit 500,000, one-tenth this year (section 16)", "50,000"),
          ("Rent chargeable", "=1,850,000"),
          ("Less repairs allowance, one-fifth (section 15A(1)(a))", "(370,000)"),
          ("Less property tax paid to the excise department", "(30,000)"),
          ("Less insurance of the building", "(20,000)"),
          ("Less agent's collection fee 90,000, limited to 4% (74,000)", "(74,000)"),
          ("Less profit on the mortgage", "(150,000)"),
          ("Income from property", "=1,206,000"),
      ), "Added to taxable income. The tax the company deducted under section 155 is a credit.")),

    # ------------------------------------------------------------------ business
    T("business", "Income from business", GROUPS[0], "ITO", "Sections 18–25, 21, 113 and 56–58",
      "Profit of a business, profession or vocation: receipts less expenses incurred wholly and exclusively for the "
      "business, after the add-backs of section 21 and with depreciation worked out under the Ordinance.",
      ((INCLUDED, (
          "Profits and gains of any business carried on at any time in the year: section 18(1)(a).",
          "Income of a trade, professional or similar association from goods or services sold to its members: "
          "section 18(1)(b).",
          "Income from the hire or lease of tangible movable property: section 18(1)(c).",
          "The fair market value of any benefit or perquisite from a business relationship, including a debt or "
          "profit waived: section 18(1)(d).",
          "Management fee of a management company or modaraba management company: section 18(1)(e).",
          "Profit on debt where earning it is the business: section 18(2).",
          "Sale price of a depreciable asset or intangible above its written down value: sections 22(8)(a) and 24(8)(a).",
          "Speculation business is kept separate from any other business: section 19.",
      )),
       (EXCLUDED, (
           "Income taxed under sections 5, 5A, 5AA, 6, 7 and 7A (dividends, sukuk returns, payments to non-residents, "
           "shipping) is not business income: Explanation to section 18(1).",
           "Exempt income under the Second Schedule, and income from which tax was deducted as a final tax: "
           "section 169.",
       )),
       (ALLOWED, (
           "Any expenditure incurred in the year wholly and exclusively for the business: section 20(1). This includes "
           "cost of goods sold, wages and salaries, rent of business premises, utilities, repairs, advertising, "
           "business travel, professional fees, insurance, bank charges and profit on business borrowings.",
           "Depreciation at the Third Schedule (Part I) rates on written down value: section 22(2). Only the business "
           "share where an asset is also used privately: section 22(3). The cost of a passenger vehicle not plying "
           "for hire is capped at Rs 7.5 million: section 22(13)(a). Land isn't depreciated: section 22(13)(b).",
           "Initial allowance on new eligible assets first used in Pakistan, at the Third Schedule (Part II) rate: "
           "section 23. Not for road vehicles (unless plying for hire), furniture, used plant or buildings: "
           "section 23(5).",
           "Amortisation of intangibles (software, licences, patents, franchises) over their useful life, or fifteen "
           "years where it can't be known: section 24.",
           "Pre-commencement expenditure, amortised: section 25.",
           "Bad debts written off, subject to the conditions of section 29.",
           "Loss on sale of a depreciable asset below written down value: section 22(8)(b). Animals used in the "
           "business that die or become useless: section 20(1A).",
       )),
       (DISALLOWED, (
           "Income tax, or any tax on profits: section 21(a). Tax deducted from your own receipts: section 21(b).",
           "Payments from which you had to deduct or collect tax but didn't deduct and deposit it. For purchases of "
           "raw materials and finished goods the disallowance is capped at 20% of those purchases: section 21(c).",
           "Commission over 0.2% of supplies of goods taxed on retail price under the sales tax law, paid to "
           "someone not on the Active Taxpayers List: section 21(ca).",
           "Entertainment beyond the prescribed limits: section 21(d).",
           "Contributions to an unapproved fund; more than 50% of contributions to an approved gratuity, pension or "
           "superannuation fund; contributions to an employees' fund that does not deduct tax under section 149 from "
           "its payments: section 21(e), (ea) and (f).",
           "Fines and penalties for breaking any law, rule or regulation: section 21(g).",
           "Personal expenses: section 21(h). Amounts carried to a reserve or capitalised: section 21(i).",
           "Profit on debt, brokerage, commission, salary or other pay an AOP gives its members: section 21(j).",
           "Expenses under a single account head that add up to more than Rs 250,000, paid other than by a crossed "
           "cheque, crossed draft or pay order, or online from the business bank account. Payments of Rs 25,000 or "
           "less, utility bills, freight, travel fares, postage and taxes are excepted: section 21(l). For "
           "companies, once notified, only digital means from the business account declared under section 114A "
           "count: section 21(la).",
           "Salary above Rs 32,000 a month paid other than by crossed cheque, bank transfer or digital means: "
           "section 21(m).",
           "Capital expenditure (it is recovered through depreciation and amortisation instead): section 21(n).",
           "Sales promotion, advertisement and publicity of pharmaceutical manufacturers above 10% of turnover: "
           "section 21(o). Utility bills beyond prescribed limits: section 21(p).",
           "10% of purchases from persons without a National Tax Number (for agricultural produce, only purchases "
           "from middlemen): section 21(q).",
           "3% of expenses of a person who fails to integrate (POS or e-invoicing) as required: section 21(r).",
           "50% of the expenses relating to sales where more than Rs 200,000 was received against one invoice "
           "other than through a bank or digital means: section 21(s).",
           "Depreciation on additions where tax under section 152 or 153 was not deducted from the payment to the "
           "seller: proviso to section 22(1).",
       )),
       (TAXED, (
           "Business income joins taxable income at the normal rates: non-salaried slabs for individuals and AOPs, "
           "the corporate rate for companies.",
           "Minimum tax: a company, and an individual or AOP with turnover of Rs 100 million or more, pays at least "
           "the turnover percentage in Division IX of the First Schedule. The excess over normal tax is carried "
           "forward for two years: section 113.",
           "Super tax on high earners: section 4C. Advance tax is paid quarterly: section 147.",
           "Losses are set off against other heads except salary and property, with the business loss set off "
           "last: section 56. What is left is carried forward six years against business income: section 57. "
           "Speculation losses only against speculation profits: section 58.",
       )),
       (POINTS, (
           "Start from the accounting profit and adjust: add back book depreciation and every section 21 item, then "
           "deduct tax depreciation, initial allowance and amortisation.",
           "Match the tax withheld from your receipts (section 153, 235 on electricity, 148 at import) with the "
           "certificates. Where a deduction is a final or minimum tax, that income is kept out of the normal "
           "computation.",
       ))),
      Example("Trader's profit and loss account adjusted for tax", (
          ("Accounting net profit", "4,080,000"),
          ("Add accounting depreciation (not allowed; tax depreciation instead)", "550,000"),
          ("Add fine for late payment to a regulator (section 21(g))", "50,000"),
          ("Add family holiday charged to the business (section 21(h))", "120,000"),
          ("Add salary of Rs 40,000 a month paid in cash (section 21(m))", "480,000"),
          ("Add stationery paid in cash in four payments of Rs 75,000 (section 21(l))", "300,000"),
          ("Less tax depreciation under section 22", "(400,000)"),
          ("Income from business", "=5,180,000"),
      ), "Taxed at the non-salaried slabs. Compare with minimum tax under section 113 if turnover is Rs 100 million or "
         "more.")),

    # ------------------------------------------------------------------ capital gains
    T("capital_gains", "Capital gains", GROUPS[0], "ITO", "Sections 37, 37A, 38 and 59",
      "Gain on disposal of a capital asset: what you received less what it cost. Securities and immovable property "
      "are taxed separately at their own rates.",
      ((INCLUDED, (
          "Gain on disposal of any capital asset: consideration received less cost: section 37(1) and (2).",
          "Immovable property in Pakistan (plots, houses, flats, shops): taxed at the rates of Division VIII of "
          "Part I of the First Schedule: section 37(1A).",
          "Securities: shares of public companies, modaraba certificates, TFCs, sukuk, T-bills, PIBs and other debt "
          "securities, units of exchange traded funds and derivatives: taxed at the rates of Division VII: "
          "section 37A(1) and (3).",
          "Shares of a listed company sold outside the exchange (not settled through NCCPL), and unlisted shares, "
          "come under section 37 (proviso to section 37A(1)). The buyer of shares deducts 10% of fair market value: "
          "section 37(6).",
      )),
       (EXCLUDED, (
           "Stock-in-trade, consumable stores and raw materials: business income: section 37(5)(a).",
           "Depreciable assets and intangibles: the gain is business income under sections 22(8) and 24(8): "
           "section 37(5)(b).",
           "Movable property held for personal use by you or your family (car, furniture, household goods), except "
           "the assets in section 38(5): section 37(5)(d).",
       )),
       (ALLOWED, (
           "Cost: purchase price and the costs of acquiring, improving and selling the asset: section 76.",
           "Loss on disposal of another capital asset in the same year: section 38(1).",
           "Capital loss brought forward, for up to six years, only against capital gains: section 59.",
           "Loss on securities, only against gains on securities; unused losses from tax year 2019 on are carried "
           "forward for three years: section 37A(5).",
       )),
       (DISALLOWED, (
           "Cost already deducted under another provision, or of the kind section 21 disallows: section 37(4).",
           "A loss where a gain would have been exempt: section 38(2).",
           "Any loss on a painting, sculpture or other work of art, jewellery, a rare manuscript or book, a postage "
           "stamp or first day cover, a coin or medallion, or an antique: section 38(5).",
           "A capital loss against any other head: section 59(1).",
       )),
       (TAXED, (
           "Securities: a separate block, not added to taxable income: section 37A(4). NCCPL computes and collects "
           "the tax for listed shares.",
           "Immovable property: the rate depends on when it was bought, how long it was held and whether the seller "
           "is on the Active Taxpayers List (Rules & rates page). Advance tax collected at sale under section 236C is "
           "adjusted against it.",
           "Other capital assets: the gain is added to taxable income at the normal rates.",
       )),
       (POINTS, (
           "Keep the purchase deed or broker statement for cost, and the NCCPL capital gains statement for securities.",
           "The sale proceeds and the gain also go into the wealth statement reconciliation.",
       ))),
      Example("Plot bought in August 2024 and sold in March 2027", (
          ("Sale price", "14,000,000"),
          ("Less purchase price", "(10,000,000)"),
          ("Less transfer fee, stamp duty and other costs of buying it (section 76)", "(300,000)"),
          ("Capital gain under section 37(1A)", "=3,700,000"),
      ), "Taxed at the Division VIII rate for property acquired on or after 1 July 2024. The section 236C advance tax "
         "taken at sale is set against it.")),

    # ------------------------------------------------------------------ other sources
    T("other_sources", "Income from other sources", GROUPS[0], "ITO", "Sections 39, 40, 5, 7B, 150, 151 and 156",
      "Income of any kind that doesn't fall under another head: dividends, profit on debt, royalty, prizes, gifts, "
      "rent from sub-leases and similar receipts.",
      ((INCLUDED, (
          "Dividend: section 39(1)(a). Royalty: (b). Profit on debt: (c). Additional payment on a delayed tax refund: "
          "(cc).",
          "Ground rent: (d). Rent from a sub-lease: (e). Income from letting a building with plant or machinery: "
          "(f). Charges for amenities, utilities or other services with a let building: (fa).",
          "Annuity or pension not taxed as salary: (g).",
          "Prize bond, raffle, lottery, quiz, sales promotion prize and crossword winnings: (h).",
          "Amounts for the use or exploitation of property, including natural resources, and benefits received for "
          "it: (i) and (j).",
          "An amount received for vacating a building, less what you paid to get possession, spread over ten "
          "years: (k) and section 39(2).",
          "Payments from an approved income payment plan or annuity plan under the VPS Rules: (l).",
          "Money or property received as a gift or without consideration, except from a relative as defined in "
          "section 85(5): (la). Bonus shares issued to a shareholder: (lb).",
          "A loan, advance, deposit for shares or gift received other than by crossed cheque, banking channel or "
          "digital means is treated as income: section 39(3). Advance payments for sale of goods or services are not: "
          "section 39(4).",
      )),
       (EXCLUDED, (
           "Income chargeable under another head, and income taxed under sections 5, 5AA, 6, 7 or 7B: section 39(5).",
           "So dividends (section 5) and profit on debt of up to Rs 5 million received by a person other than a "
           "company (section 7B) are taxed on their own, on the gross amount.",
       )),
       (ALLOWED, (
           "Expenses paid in the year in earning the income, other than capital expenditure: section 40(1).",
           "Zakat deducted at source from profit on debt: section 40(2).",
           "For a building let with plant or machinery, depreciation and initial allowance: section 40(3).",
       )),
       (DISALLOWED, (
           "Capital expenditure, meaning anything with a useful life of more than one year: section 40(1) and (6).",
           "Expenses deductible under another head: section 40(4). Anything section 21 bars: section 40(5).",
           "No expense at all against dividends or profit on debt taxed under sections 5 and 7B, or against prizes "
           "taxed as a final tax under section 156.",
       )),
       (TAXED, (
           "Dividends: Division III rates on the gross dividend; the company deducts it under section 150.",
           "Profit on debt up to Rs 5 million (non-companies): Division IIIA rates on the gross amount; the bank "
           "deducts it under section 151. Above Rs 5 million, section 7B doesn't apply and the profit is taxed at "
           "the normal rates.",
           "Everything else under this head, less section 40 deductions, joins taxable income at the normal rates.",
       )),
       (POINTS, (
           "Collect the bank's yearly profit and tax certificate and the dividend tax statements.",
           "Gifts and loans received must be traceable through the bank, and they also appear as inflows in the "
           "wealth reconciliation.",
       ))),
      Example("An individual's other income", (
          ("Profit on savings account (section 7B, separate)", "600,000"),
          ("Dividends from listed companies (section 5, separate)", "200,000"),
          ("Rent of a workshop let with machinery", "900,000"),
          ("Less depreciation of the machinery (section 40(3))", "(150,000)"),
          ("Less repairs paid", "(50,000)"),
          ("Cash gift from a friend, not a relative (section 39(1)(la))", "300,000"),
          ("Income from other sources at normal rates", "=1,000,000"),
      ), "The 600,000 profit and 200,000 dividend are taxed on their own at their gross amounts. The bank's and "
         "companies' deductions cover that tax.")),

    # ------------------------------------------------------------------ allowances and credits
    T("reliefs", "Deductible allowances and tax credits", GROUPS[1], "ITO",
      "Sections 9, 60, 60A, 60B, 60D, 61, 63, 65 and 4(3)",
      "Allowances reduce taxable income; credits reduce the tax. Neither can touch income taxed as a final or "
      "separate tax.",
      (("Deductible allowances (reduce taxable income)", (
          "Taxable income is total income less deductible allowances, but not below zero: section 9.",
          "Zakat paid under the Zakat and Ushr Ordinance (not the Zakat already deducted from profit on debt): "
          "section 60.",
          "Workers' Welfare Fund and Workers' Participation Fund paid: sections 60A and 60B.",
          "Tuition fees, where taxable income is below Rs 1.5 million: the lowest of 5% of fees paid, 25% of "
          "taxable income and Rs 60,000 per child. Either parent claims it, giving the school's NTN or name: "
          "section 60D.",
      )),
       ("Tax credits (reduce tax)", (
           "Donations to approved institutions, NPOs, the Thirteenth Schedule bodies or persons eligible under "
           "section 100C. The credit is average rate × the lower of the donation and 30% of taxable income (20% for "
           "a company; 15% and 10% where the recipient is an associate): section 61.",
           "Contributions to an approved pension fund under the VPS Rules, by a person with salary or business "
           "income: average rate × the lower of the contribution and 20% of taxable income: section 63.",
           "Credits are applied in this order: foreign tax credit (section 103), then Part X credits, then "
           "withholding and advance tax (sections 147 and 168): section 4(3).",
       )),
       ("Not admissible", (
           "An allowance not used in the year is lost. It can't be refunded or carried forward: sections 60(3) and "
           "60D(3).",
           "The tuition allowance doesn't reduce the salary withholding under section 149: section 60D(5).",
           "A cash donation counts only if paid by crossed cheque: section 61(4).",
           "No allowance against income taxed as a final tax, and no credit against final or separate taxes: "
           "sections 8 and 169(2).",
       ))),
      Example("Donation credit", (
          ("Taxable income", "5,000,000"),
          ("Tax on it before credits (illustrative)", "900,000"),
          ("Donation by cheque to an approved hospital (limit 30% = 1,500,000)", "600,000"),
          ("Credit = 900,000 ÷ 5,000,000 × 600,000", "=108,000"),
      ), "Tax after the credit is 792,000, before the withholding and advance tax credits.")),

    T("tax_paid", "Withholding, advance, minimum and final tax", GROUPS[1], "ITO",
      "Sections 4, 8, 113, 147, 168, 169 and 170",
      "Tax already paid during the year is either a credit against the return's tax (adjustable) or the full tax on "
      "that income (final).",
      (("Adjustable (credit in the return)", (
          "Tax deducted or collected under Division II or III of Part V of Chapter X or Chapter XII is tax paid by "
          "you and a credit in the year it was deducted: section 168(1) and (2). Common ones: salary (section 149), "
          "profit on debt above the section 7B limit (section 151), rent (section 155), goods, services and contracts "
          "where not final (section 153), vehicles (section 231B), electricity bills (section 235), and property "
          "purchase and sale (sections 236K and 236C).",
          "Advance tax paid quarterly by individuals with latest assessed income (excluding salary and final tax "
          "income) of Rs 1 million or more, by 15 September, December, March and June: section 147(2), (4B) and (5). "
          "Companies and AOPs pay by the 25th of September, December and March and the 15th of June: section 147(5A).",
          "A credit that exceeds the tax is refunded: sections 147(10), 168(5) and 170.",
      )),
       ("Final (no further tax, no credit, no refund)", (
           "Tax under sections 5, 5A, 5AA, 6, 6A, 7, 7A, 7B and 7G is a final tax. The income stays out of taxable "
           "income, with no deductions, allowances, loss set-off or credits: section 8.",
           "The same applies to withholding taxes made final in section 169(1), such as section 152(1E), section "
           "154A(2), section 156 and section 236Z(7): section 169(2). Excess tax deducted at the higher rate for "
           "persons not on the Active Taxpayers List is adjustable if the return is filed: section 169(4).",
       )),
       ("Minimum and super tax", (
           "Section 113: companies, and individuals and AOPs with turnover of Rs 100 million or more, pay at least "
           "the Division IX percentage of turnover. Turnover excludes sales tax, excise and trade discounts: "
           "section 113(3). The excess over normal tax is carried forward two years: section 113(2)(c).",
           "Super tax on high earning persons at the rates of Division IIB: section 4C.",
       )),
       ("Refunds", (
           "Apply within three years of the assessment order or the payment, whichever is later. The Commissioner "
           "decides within sixty days: section 170(2) and (4).",
       )))),

    # ------------------------------------------------------------------ sales tax
    T("output_tax", "Output tax", GROUPS[2], "STA", "Sections 2(20), 2(33), 2(41), 2(44), 2(46), 3, 4, 9, 13 and 23",
      "Sales tax a registered person charges on taxable supplies. It is paid after subtracting admissible input tax.",
      ((INCLUDED, (
          "Sales tax at 18% of the value of taxable supplies made by a registered person in the course of taxable "
          "activity, and of imports: section 3(1). Output tax is defined in section 2(20).",
          "Supply includes sale or other transfer of goods, hire purchase, own goods used privately or for "
          "non-taxable purposes, auctions to settle a debt, and goods held when registration ends: section 2(33).",
          "Value of supply is the consideration including duties but excluding the sales tax. Open market price "
          "applies where paid in kind, or where an associated person pays below market: section 2(46). For Third "
          "Schedule goods tax is charged on the printed retail price: section 3(2)(a).",
          "Time of supply is delivery or receipt of payment, whichever is earlier: section 2(44).",
          "Further tax of 4% on supplies to a person not registered or not on the Active Taxpayers List: "
          "section 3(1A). It can't be paid out of input tax: section 7(1).",
          "Reduced rates under the Eighth Schedule and supplies of retailers, steel, CNG and others under their "
          "special regimes.",
      )),
       ("Zero-rated and exempt supplies", (
           "Zero-rated (0%), e.g. exports and Fifth Schedule supplies: section 4. No output tax, but input tax is "
           "admissible and the excess is refundable: section 10.",
           "Exempt supplies (Sixth Schedule): section 13. No output tax and no input tax on them: section 8(1)(a) and "
           "rule 25(2).",
       )),
       ("Changes after the invoice", (
           "Goods returned or a supply cancelled: the buyer issues a debit note; for an unregistered buyer the "
           "supplier issues a credit note, with the Commissioner's approval: rule 20.",
           "Price changed: supplier's debit note (increase) or credit note (decrease): rule 21. Each side adjusts "
           "in the return of the period the note is issued, only within 180 days of the supply (extendable by "
           "180 days): rule 22 and section 9.",
           "A credit note not accepted by the buyer, or tax withheld that the buyer hasn't declared, is allowed only "
           "provisionally and reversed in row 7(a) of the next return: rule 18(5) and (7).",
       )),
       ("Invoice and records", (
           "A serially numbered tax invoice at the time of supply with both parties' names, addresses and "
           "registration numbers (NIC or NTN of an unregistered distributor), date, description, quantity, value "
           "excluding tax, tax and value including tax: section 23(1). Only one invoice per supply.",
           "Electronic invoices with an FBR invoice number where notified; integration with FBR's system; tier-1 "
           "retailers integrate their POS: section 23(3)–(6).",
           "Records of purchases, sales, imports, zero-rated and exempt supplies, double-entry accounts, invoices, "
           "notes and bank statements: section 22.",
       ))),
      Example("Manufacturer's sales for the month", (
          ("Sales to registered buyers 10,000,000 × 18%", "1,800,000"),
          ("Sales to unregistered buyers 1,000,000 × 18%", "180,000"),
          ("Exports 5,000,000, zero-rated", "0"),
          ("Credit note for goods returned within 180 days, 500,000 × 18%", "(90,000)"),
          ("Output tax (row 15)", "=1,890,000"),
          ("Further tax on unregistered sales 1,000,000 × 4% (row 23a, separate)", "40,000"),
      ), "Admissible input tax is set against the 1,890,000. The further tax is paid in full.")),

    T("input_tax", "Input tax: admissible and inadmissible", GROUPS[2], "STA", "Sections 2(14), 7, 8, 8B(6) and 73; "
      "rules 12A, 23 and 25",
      "Tax paid on purchases and imports, set against output tax only where the conditions are met.",
      (("Admissible", (
          "Input tax is tax on goods supplied to you or imported by you, federal excise in sales tax mode, and "
          "provincial sales tax on services, except services the Board excludes: section 2(14).",
          "Allowed for taxable supplies made or to be made, in the tax period or any of the next six: section 7(1).",
          "You must hold a tax invoice in your name with your registration number, or for electricity and gas a "
          "bill with your number and the connection address: section 7(2)(i). For imports, the goods declaration "
          "in your name: section 7(2)(ii). For auctions, the treasury challan: section 7(2)(iii).",
          "The supplier must have declared the supply in his return and paid the tax: sections 7(2)(i) and 8(1)(l). "
          "Your return stays provisional until your suppliers file: rule 18(3).",
          "Payment of more than Rs 50,000 in a period to a supplier must go through the bank from your business "
          "account, and credit purchases must be paid within 180 days: section 73(1) and (2).",
          "Capital goods and fixed assets used for taxable supplies (row 4). They are outside the 90% cap: proviso "
          "to section 8B(1).",
          "Mixed taxable and exempt supplies: input used only for taxable supplies in full; residual input × "
          "taxable supplies ÷ all supplies. It is provisional monthly and settled at year end: section 8(2) and "
          "rule 25.",
      )),
       ("Inadmissible", (
           "For other than taxable supplies, or not related to them: section 8(1)(a) and (f). For exempt supplies: "
           "rule 25(2).",
           "Goods or services notified by the Federal Government: section 8(1)(b). Goods under section 3(5): (c).",
           "Tax not deposited by the supplier: (ca). A CREST discrepancy or input that can't be verified in the "
           "supply chain: (caa). Fake invoices: (d).",
           "Not giving information required under section 26(5): (e).",
           "Personal or non-business consumption: (g).",
           "Building and construction materials, paints, electrical and sanitary fittings, pipes, wires and cables "
           "used in or attached to immovable property, unless bought for resale or direct use in manufacturing: (h).",
           "Vehicles of Chapter 87 and their parts, electrical and gas appliances, furniture, furnishings and office "
           "equipment (except electronic cash registers), unless for resale: (i).",
           "Services whose input adjustment is barred by the provincial law: (j). Agricultural machinery taxed at "
           "7% under the Eighth Schedule: (k).",
           "Purchases the supplier didn't declare, or where the supplier didn't pay the tax shown: (l).",
           "Input attributable to supplies to unregistered distributors whose invoices lack their NIC or NTN, on a "
           "pro rata basis: (m). This is row 6a.",
           "Payment not through the bank as section 73 requires: section 73(2).",
           "Invoices of a non-active taxpayer: rule 12A(2)(c) and (4). Goods destroyed as unfit: rule 23.",
           "Tier-1 retailer not integrated with FBR: input for the whole period cut by 60%: section 8B(6), row 6b.",
           "Input older than six tax periods: proviso to section 7(1).",
       ))),
      Example("Purchases for the month", (
          ("Raw material from registered suppliers, tax per invoices", "1,080,000"),
          ("Less office furniture in those invoices (section 8(1)(i))", "(54,000)"),
          ("Imported raw material, tax on goods declaration", "450,000"),
          ("Factory electricity bill with registration number", "90,000"),
          ("New machinery (capital goods, row 4)", "180,000"),
          ("Admissible input tax", "=1,746,000"),
      ), "Of this, 1,566,000 (excluding the machinery) is subject to the 90% cap of section 8B.")),

    T("adjust_refund", "90% rule, carry forward and refund", GROUPS[2], "STA", "Sections 8B, 10, 34 and 66; rules 26 "
      "and 28",
      "How much input can be set off in a month, and what happens to the rest.",
      (("The 90% cap", (
          "Input tax set off in a period can't exceed 90% of the output tax: section 8B(1). Capital goods are "
          "outside the cap. Persons in Table-1 of SRO 1190(I)/2019 are excluded; Table-2 persons may go to 95% "
          "(rows 24 and 25 of the return).",
          "Input held back by the cap is carried forward, or adjusted or refunded once a year with the auditor's "
          "certificate showing value addition below the limit, in the second month after the year ends: "
          "section 8B(2) and (3).",
          "The Board may set other limits, including through its risk system: section 8B(4).",
      )),
       ("Excess input", (
           "Excess from zero-rated or export supplies is refunded within 45 days of the claim: section 10(1).",
           "Excess from other supplies is carried forward to the next period as input tax: first proviso to "
           "section 10(1).",
           "A refund is first adjusted against any tax, surcharge or penalty you owe: section 10(2).",
           "The claim is the amount in row 29 of the return. Annex-H (stock statement) may follow within 120 days: "
           "rule 28(1). Claim within one year: section 66.",
       )),
       ("If it goes wrong", (
           "Inadmissible input or refund attracts default surcharge at the higher of 12% a year or KIBOR + 3% from "
           "the date of adjustment: section 34(1)(a) and (2)(a), plus penalties under section 33.",
       ))),
      Example("Return with the 90% cap", (
          ("Output tax (row 15)", "1,000,000"),
          ("Input for the month excluding capital goods (8 − 4)", "1,200,000"),
          ("Capital goods input (row 4)", "100,000"),
          ("90% of output tax", "900,000"),
          ("Admissible credit, least of 1,200,000, 900,000 and 1,000,000 (row 25)", "=900,000"),
          ("Sales tax payable 1,000,000 − 900,000 (row 32)", "=100,000"),
          ("Excess unadjusted credit carried forward 1,300,000 − 900,000 (rows 26 and 30)", "=400,000"),
      ), "Capital goods are added to row 25 only when the other input is below 90% of output.")),

    T("str_updates", "Sales Tax Rules: what changed (edition of 31 July 2026)", GROUPS[2], "STA",
      "Sales Tax Rules 2006, FBR consolidation updated up to 31 July 2026",
      "Amendments since 2025 that change practice, from the notes to FBR's consolidated rules. Each rule opens with "
      "its current text.",
      (("Returns", (
          "Annex-A (purchases) and Annex-C (sales) of the STR-7 return replaced, and Annex-C1, payments received "
          "against sales invoices, added: S.R.O. 578(I)/2025 of 8 April 2025.",
          "Manufacturers report goods made and supplied in Annex-J; commercial importers, distributors and "
          "wholesalers report goods bought and supplied in Annex-H1: rule 14(1) provisos, S.R.O. 55(I)/2025 of "
          "24 January 2025.",
          "A return filed more than six months late needs the Commissioner's approval: rule 14(3).",
      )),
       ("Registration and status", (
           "De-registration is applied for online; the order comes within sixty days (was ninety); after applying "
           "you can't file Annex-C, Annex-D or the return: rule 11, S.R.O. 608(I)/2025 of 17 April 2025.",
           "Blacklisting and suspension updated: LTOs named, the period in clause (a)(iii) cut from six to three, "
           "and a thirty-day limit added in clause (a)(ix): rule 12, S.R.O. 608(I)/2025.",
           "Non-active taxpayers can't issue invoices, claim input or refund, or file goods declarations, and buyers "
           "get no input on their invoices: rule 12A. Restoration: rule 12B. Both are now in TaxDesk's index.",
       )),
       ("Retailers and integration", (
           "Retailers whose withholding under sections 236G and 236H of the Income Tax Ordinance in the preceding "
           "period exceeded Rs 100,000 or Rs 500,000 must integrate as tier-1 retailers: rule 150Q(3), "
           "S.R.O. 2071(I)/2025 of 3 November 2025.",
           "Sealing and de-sealing of integrated and non-integrated tier-1 retailers' premises: rules 150ZEO to "
           "150ZER, S.R.O. 164(I)/2025 of 17 February 2025.",
       )),
       ("Production monitoring and other chapters", (
           "Electronic monitoring of production of specified goods rewritten: rules 150ZQS to 150ZQZE, "
           "S.R.O. 364(I)/2025 of 14 March 2025; rule 150ZQZB omitted. Chapters XIV-AA and XIV-BB omitted by "
           "S.R.O. 69(I)/2025.",
           "Withholding by online marketplaces, payment intermediaries and couriers on digitally ordered goods: "
           "rules 150ZZM and 150ZZN, with their monthly statements under section 26(1).",
           "Forms STR-33, STR-35 and STR-36 added by S.R.O. 1429(I)/2025 of 4 August 2025; Annex-L replaced by "
           "S.R.O. 800(I)/2025.",
           "Independent Case Scrutiny Committees: field offices renamed (RTO-I and RTO-II Lahore, CTO-I and CTO-II "
           "Karachi; CTO Islamabad dropped): rule 62A, S.R.O. 1237(I)/2026 of 30 July 2026.",
       )))),
]

S = Step
FLOWS: list[Flow] = [
    Flow("itr_flow", "Income tax return (individual) on IRIS", "ITO", "Sections 114, 116, 118 and 137",
         "The order in which a return is built: from who must file, through each head, to tax payable and the "
         "wealth statement.",
         (S("Check whether a return is required", "Section 114(1) and (1A)",
            "Taxable income above the exempt limit; income subject to final tax; or any of the following.",
            (S("Assets and connections", "Section 114(1)(b)(iii)–(viii)",
               "Owning a plot of 500 sq yd or more, a flat of 2,000 sq ft or more in a rating area, or a vehicle above "
               "1000cc; holding an NTN; or a commercial or industrial electricity bill above Rs 500,000 a year."),
             S("Memberships and foreign assets", "Section 114(1)(b)(ix)–(x) and (c)",
               "Members of a chamber, trade body or professional council; residents who must file the foreign income "
               "and assets statement; persons notified by the Board."),
             S("Small business", "Section 114(1A)", "Business income of Rs 300,000 to Rs 400,000."))),
          S("Collect the documents", "Sections 149–156, 168, 236C and 236K",
            "Salary certificate, bank profit and tax certificates, dividend and NCCPL statements, rent agreements and "
            "withholding certificates, business accounts, Zakat and donation receipts, and closing balances of every "
            "asset and liability."),
          S("Declare income under each head (normal regime)", "Sections 10 and 11",
            "Each head has its own inclusions and deductions; open its guide for detail.",
            (S("Salary", "Sections 12–14", "Gross salary, perquisites and taxable allowances; exempt parts shown "
                                           "separately; tax deducted under section 149."),
             S("Income from property", "Sections 15, 15A and 16", "Rent chargeable less section 15A deductions."),
             S("Income from business", "Sections 18–25", "Accounting profit adjusted for section 21 add-backs and "
                                                         "tax depreciation; turnover for section 113."),
             S("Capital gains (normal regime)", "Section 37", "Gains on capital assets other than securities and "
                                                              "immovable property."),
             S("Income from other sources", "Sections 39 and 40", "Other income less section 40 deductions."))),
          S("Set off losses", "Sections 56–59",
            "This year's losses against other heads (not against salary; a business loss not against property; the "
            "business loss last), then losses brought forward: business six years, capital six years, securities "
            "three years."),
          S("Total income less deductible allowances = taxable income", "Sections 9, 60, 60A, 60B and 60D",
            "Zakat, WWF and WPPF paid, and tuition fees within the limits."),
          S("Work out the tax", "Sections 4, 4C and 113",
            "Slab tax on taxable income (salaried or non-salaried rates), surcharge where applicable, and super tax "
            "under section 4C; for business with turnover of Rs 100 million or more, the higher of normal tax and "
            "minimum tax under section 113."),
          S("Add the separately taxed income", "Sections 5, 7B, 37(1A), 37A, 8 and 169",
            "Dividends, profit on debt up to Rs 5 million, capital gains on securities and on immovable property, and "
            "income under final withholding. Each is taxed at its own rate and kept out of taxable income."),
          S("Subtract tax credits", "Sections 61, 63, 103 and 4(3)",
            "Donations and approved pension fund, then foreign tax credit, in the order of section 4(3)."),
          S("Subtract tax already paid", "Sections 147 and 168",
            "Adjustable withholding taxes and advance tax, each with its certificate or challan (CPR)."),
          S("Tax payable or refundable", "Sections 137 and 170",
            "Pay any balance before filing; the challan goes with the return (section 114(2)(d)). An excess is "
            "refundable on application under section 170."),
          S("Wealth statement and reconciliation", "Sections 116 and 116A",
            "Assets and liabilities at 30 June, reconciled with last year's through income and expenses (see the "
            "wealth statement flow)."),
          S("Submit by the due date", "Sections 118 and 114(6)",
            "30 September for individuals and AOPs (section 118(3)); companies by 31 December or 30 September "
            "(section 118(2)). A filed return can be revised within sixty days without approval, later with the "
            "Commissioner's approval: section 114(6)."))),

    Flow("wealth_flow", "Wealth statement and reconciliation", "ITO", "Sections 116, 116A and 111",
         "Every resident individual filing a return files a wealth statement and reconciles it with the year's "
         "income and spending.",
         (S("List assets at 30 June", "Section 116(1)(a)",
            "Property at cost, business capital, investments, vehicles, gold and jewellery, cash and bank balances, "
            "foreign assets, and receivables.",
            (S("Dependants", "Section 116(1)(b)",
               "Assets of a dependent spouse, minor children and other dependants go in your statement."),)),
          S("List liabilities", "Section 116(1)(a)", "Loans, credit cards, payables and advances received."),
          S("Net assets = assets − liabilities", "Section 116(2)", "Compare with last year's net assets."),
          S("Reconcile", "Section 116(1)(e)",
            "Opening net assets + income of the year (taxable, exempt and final-tax income) + gifts, inheritance and "
            "other inflows − personal expenses, taxes and gifts made = closing net assets.",
            (S("Personal expenses", "Section 116(1)(d)",
               "Household, rent, utilities, vehicle running, travel, education, medical, functions and other "
               "spending by you and your family."),
             S("Unexplained difference", "Section 111",
               "An increase in wealth that income can't explain may be taxed as unexplained income."))),
          S("Revise if needed", "Section 116(3)",
            "Revise before a notice under section 122(9), with reasons and a revised reconciliation, within five "
            "years of the return's due date."))),

    Flow("str_flow", "Sales tax return STR-7 (monthly)", "STA", "Section 26; rules 14 and 18; Form STR-7",
         "The annexures feed the return; the return works down from input (credits) and output (debits) to tax "
         "payable or refundable.",
         (S("Be registered and active", "Sections 14 and 2(1A); rules 12A and 12B",
            "Only an active taxpayer may issue invoices and claim input tax."),
          S("Enter sales in Annex-C and notes in Annex-I by the 10th", "Rule 18(3)",
            "Each invoice issued under section 23, with the buyer's registration number (or CNIC or NTN), sale type, "
            "rate, value, tax, further tax and tax withheld at source. Buyers then see it in their Purchase Data.",
            (S("Annex-C1", "Rule 18(3)", "Payments received against sales invoices."),
             S("Annex-D", "Section 4", "Exports, from the goods declarations."))),
          S("Load purchases in Annex-A and imports in Annex-B", "Rule 18(3)",
            "Import Annex-A from Purchase Data (your suppliers' Annex-C); type purchases from unregistered persons "
            "yourself. Annex-B comes from customs data."),
          S("Sales tax credits (input)", "Sections 7 and 8B; rows 1–8",
            "Row 1 purchases from registered persons, row 2 from unregistered persons, row 3 imports, row 4 capital "
            "goods; row 5 input for the month = 1 + 3 + 4; row 6 credit brought forward.",
            (S("Inadmissible input", "Sections 8(1)(m) and 8B(6); rows 6a–6c",
               "Supplies to unregistered distributors without NIC or NTN, and the 60% cut for a non-integrated "
               "tier-1 retailer, with its reversal."),
             S("Non-creditable and disallowed input", "Sections 8(1) and 7(2); rule 25; rows 7–7c",
               "Input for exempt supplies; input disallowed because the supplier didn't file; disallowed output "
               "reductions for withholding and credit notes, and those allowed back."),
             S("Accumulated credit", "Row 8", "Row 8 = 5 + 6 + 7b + 6c − (6a + 6b + 7 + 7a)."))),
          S("Sales tax debits (output)", "Sections 3 and 4; rows 9–20",
            "Row 9 local supplies (including reduced rate), row 10 reduced rate, row 11 exports, rows 12 and 14 "
            "fixed-rate sectors; row 15 output tax.",
            (S("Withheld by your buyers", "Rows 16 and 17",
               "Row 16 tax deducted by withholding agents; row 17 accumulated debit = 15 − 16."),
             S("Sector adjustments", "Rows 18–20", "Electricity to retailers, steel, ship-breaking."))),
          S("Other amounts payable", "Section 3(1A); rows 21–23b",
            "Ginned cotton, tax you withheld as a withholding agent, arrears, further tax on supplies to unregistered "
            "persons (23a), and extra tax."),
          S("Admissible credit under the 90% rule", "Section 8B; rows 24–30",
            "Row 25 = least of (8 − 4), 90% of row 15 and row 17, plus row 4 where (8 − 4) is below 90% of row 15. "
            "Rows 26–28 work out the unadjusted credit; row 29 is the refund claimed (Annex-H within 120 days); "
            "row 30 is carried forward."),
          S("Tax payable", "Rows 31–37",
            "Row 32 = (17 − 25 where positive) + 12 + 14b + 18 + 21 + 22 + 23 + 23a + 23b; plus FED (33, Annex-E) "
            "and petroleum levy (34) = row 35. On a revised return, less tax already paid (36) = row 37."),
          S("Pay by the 15th and file by the 18th", "Rule 18(8) and (9); section 6",
            "Pay by CPR (STR-11 challan) or e-payment, then submit. The return is provisional until your sellers file "
            "by the end of the month: rule 18(3)."),
          S("After filing", "Sections 26(3), 26(3A) and 34; rule 14(3)",
            "Revise within 120 days with approval, or within 60 days without approval if tax goes up or the refund "
            "goes down. Late payment carries default surcharge. Six months late needs the Commissioner's approval."))),
]

BY_ID: dict[str, Topic | Flow] = {t.id: t for t in TOPICS} | {f.id: f for f in FLOWS}


def _flow_text(steps: tuple[Step, ...]) -> str:
    return " ".join(f"{s.title} {s.law} {s.what} {_flow_text(s.children)}" for s in steps)


def text_of(item: Topic | Flow) -> str:
    """Everything an item says, for searching."""
    if isinstance(item, Flow):
        return f"{item.title} {item.law} {item.summary} {_flow_text(item.steps)}"
    parts = " ".join(f"{h} {' '.join(points)}" for h, points in item.parts)
    example = f"{item.example.title} {' '.join(r[0] for r in item.example.rows)} {item.example.result}" \
        if item.example else ""
    return f"{item.title} {item.law} {item.summary} {parts} {example}"


def search(text: str) -> list[Topic | Flow]:
    """Topics and flows whose text has every word of the query, in guide order."""
    words = text.lower().split()
    items: list[Topic | Flow] = [*TOPICS, *FLOWS]
    return [i for i in items if all(w in text_of(i).lower() for w in words)]
