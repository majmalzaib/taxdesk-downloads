"""Clients: import a customer list, check each client against FBR's Active Taxpayer Lists, and flag changes.

A client is "active" on a list when their CNIC or NTN appears on it, and "inactive" when it doesn't. A client with
neither identifier can't be checked. Each check is compared with the previous one, so a client who drops off a list
is flagged with the date of the list that showed it.
"""
from __future__ import annotations

import html
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from . import atl

FIELDS = ("name", "cnic", "ntn", "strn", "phone", "email", "notes")
LABELS = {"name": "Name", "cnic": "CNIC", "ntn": "NTN", "strn": "STRN", "phone": "Phone", "email": "Email",
          "notes": "Notes"}
# header words that identify each field in an uploaded file, most specific first
HEADER_WORDS = {
    "strn": ("strn", "sales tax reg", "gst reg", "gst no", "registration no"),
    "cnic": ("cnic", "nic", "id card", "national id", "identity"),
    "ntn": ("ntn", "national tax"),
    "email": ("email", "e-mail", "mail"),
    "phone": ("phone", "mobile", "cell", "contact", "whatsapp"),
    "name": ("name", "client", "customer", "party", "buyer", "title", "business"),
    "notes": ("note", "remark", "comment"),
}
STATUS_TEXT = {"active": "Active", "inactive": "Inactive", "": "Not checked"}


def map_headers(headers: list[str]) -> dict[str, str]:
    """{field: header} for an uploaded file's headers."""
    out: dict[str, str] = {}
    for field, words in HEADER_WORDS.items():
        for h in headers:
            low = h.lower().strip()
            if h not in out.values() and any(w in low for w in words) and field not in out:
                out[field] = h
    return out


def from_rows(rows: list[dict[str, str]]) -> tuple[list[dict[str, str]], list[str]]:
    """Clients from an uploaded table, and a note for each row skipped or with an identifier that can't be used."""
    if not rows:
        return [], ["The file has no rows."]
    cols = map_headers(list(rows[0]))
    if not {"cnic", "ntn"} & set(cols):
        return [], ["No CNIC or NTN column found. Name the columns e.g. “Name”, “CNIC”, “NTN”, “STRN”."]
    out, notes = [], []
    for n, row in enumerate(rows, start=2):  # row 1 is the header
        c = {f: str(row.get(cols[f], "") if f in cols else "").strip() for f in FIELDS}
        if re.search(r"\d\.\d+E\+\d+", f"{c['cnic']} {c['ntn']}", re.I):
            notes.append(f"Row {n}: the CNIC/NTN is in scientific form ({c['cnic'] or c['ntn']}), so digits were lost. "
                         "Format that column as text in Excel and upload again.")
            continue
        if c["cnic"] and not atl.norm_cnic(c["cnic"]):
            notes.append(f"Row {n}: “{c['cnic']}” isn't a 13-digit CNIC; left blank.")
            c["cnic"] = ""
        if c["cnic"]:
            d = atl.norm_cnic(c["cnic"])
            c["cnic"] = f"{d[:5]}-{d[5:12]}-{d[12]}"
        if not atl.keys_for(c["cnic"], c["ntn"]):
            notes.append(f"Row {n}: no usable CNIC or NTN; skipped.")
            continue
        c["name"] = c["name"] or c["ntn"] or c["cnic"]
        out.append(c)
    return out, notes


def import_file(store, path: Path | str) -> tuple[int, int, list[str]]:
    """Add or update clients from a CSV or Excel file. A client already on file (same CNIC or NTN) is updated
    with the columns the file has. Returns (added, updated, notes)."""
    found, notes = from_rows(atl.read_table(path))
    existing = store.clients()
    index: dict[str, dict] = {}
    for c in existing:
        for k in atl.keys_for(c["cnic"], c["ntn"]):
            index[k] = c
    added = updated = 0
    for c in found:
        match = next((index[k] for k in atl.keys_for(c["cnic"], c["ntn"]) if k in index), None)
        if match:
            merged = {f: c[f] or match[f] for f in FIELDS}
            if any(merged[f] != match[f] for f in FIELDS):
                store.save_client(merged, match["id"])
                updated += 1
        else:
            cid = store.save_client(c)
            for k in atl.keys_for(c["cnic"], c["ntn"]):
                index[k] = {**c, "id": cid}
            added += 1
    return added, updated, notes


def check(store, kind: str, path: Path | str, list_date: str, progress: Callable[[float], None] | None = None,
          cancelled: Callable[[], bool] | None = None) -> list[dict[str, Any]]:
    """Check every client against one downloaded list and record the result; returns the changes."""
    clients = [c for c in store.clients() if atl.keys_for(c["cnic"], c["ntn"])]
    wanted = set().union(*(atl.keys_for(c["cnic"], c["ntn"]) for c in clients)) if clients else set()
    if not wanted:
        return []
    found, _ = atl.scan(path, wanted, progress, cancelled)
    if cancelled and cancelled():
        return []
    results = {}
    for c in clients:
        hit = next((found[k] for k in sorted(atl.keys_for(c["cnic"], c["ntn"])) if k in found), None)
        results[c["id"]] = ("active", hit.name, hit.ntn, hit.business) if hit else ("inactive", "", "", "")
    return store.record_status(kind, results, list_date)


TEMPLATE_HEADERS = ["Name", "CNIC"]
EXPORT_HEADERS = ["Name", "CNIC", "NTN", "STRN", "Name on FBR list", "Business name (FBR)", "Income tax ATL",
                  "Income tax since", "Sales tax ATL", "Sales tax since", "FBR lists of", "Checked", "Phone", "Email",
                  "Notes"]
CNIC_CHECK = (13, 15, "A CNIC has 13 digits, e.g. 35202-1234567-1 or 3520212345671.")
GUIDE = [
    ["1. On the Clients sheet, type each client's name and CNIC: one client per row. Dashes are optional."],
    ["2. The CNIC column is already formatted as text, so Excel keeps all 13 digits. If you paste CNICs from "
     "elsewhere, use Paste Special → Values so the text format stays."],
    ["3. In TaxDesk open Clients & FBR status → Upload file & check…, and choose this file. Later, "
     "Download latest FBR lists gets FBR's newest lists, and Check clients updates every client's status."],
    ["4. TaxDesk matches each CNIC against FBR's Active Taxpayer Lists (income tax and sales tax) and fills in the NTN, "
     "the name and business name as FBR lists them, and each status. Clients already on file are updated, not "
     "duplicated."],
    ["5. More → Export clients with status gives back this list with every column filled."],
    ["STRN: FBR's public lists don't include STRNs, so TaxDesk can't fill them. Add a column named STRN if you want "
     "to keep them; it is uploaded with the rest."],
    ["NTN: a client who is on neither list gets no NTN from FBR. Add an NTN column if you have them."],
    ["Privacy: the CNICs stay on your computer. TaxDesk downloads FBR's lists and matches them locally."],
]


def write_template(path: Path | str) -> Path:
    """The Excel template for uploading clients: Name and CNIC, with the CNIC column kept as text."""
    from . import xlsx
    return xlsx.write(path, [
        xlsx.Sheet("Clients", TEMPLATE_HEADERS, widths=[40, 22], text_columns=(1,), length_check={1: CNIC_CHECK}),
        xlsx.Sheet("How to use", ["How to use this template"], GUIDE, widths=[110], wrap=True)])


def export_rows(clients: list[dict[str, Any]]) -> list[list[str]]:
    def ntn(c: dict) -> str:
        return c["ntn"] or c["it_ntn"] or c["st_ntn"]
    return [[c["name"], c["cnic"], ntn(c), c["strn"], c["it_name"] or c["st_name"], c["st_business"] or c["it_business"],
             STATUS_TEXT[c["it_status"]], c["it_since"], STATUS_TEXT[c["st_status"]], c["st_since"],
             " / ".join(x for x in (c["it_list"] and f"IT {c['it_list']}", c["st_list"] and f"ST {c['st_list']}") if x),
             max(c["it_checked"], c["st_checked"]).replace("T", " "), c["phone"], c["email"], c["notes"]]
            for c in clients]


def export(clients: list[dict[str, Any]], path: Path | str) -> None:
    """The clients with everything FBR's lists showed: Excel (.xlsx) or CSV, by the file's extension."""
    path = Path(path)
    rows = export_rows(clients)
    if path.suffix.lower() == ".csv":
        import csv
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(EXPORT_HEADERS)
            w.writerows(rows)
        return
    from . import xlsx
    xlsx.write(path, [xlsx.Sheet("Clients", EXPORT_HEADERS, rows,
                                 widths=[34, 18, 14, 16, 30, 30, 14, 14, 14, 14, 26, 18, 16, 24, 30],
                                 text_columns=(1, 2, 3), length_check={1: CNIC_CHECK})])


# ---------------------------------------------------------------- status report (PDF)
def _day(iso: str) -> str:
    try:
        return datetime.fromisoformat(iso).strftime("%d %b %Y") if iso else ""
    except ValueError:
        return iso


def _rows(pairs: list[tuple[str, str]]) -> str:
    return "".join(f"<tr><td width='34%'><b>{html.escape(k)}</b></td><td>{v}</td></tr>" for k, v in pairs)


def status_report_html(clients: list[dict[str, Any]], history: list[dict[str, Any]], printed: datetime) -> str:
    """A status report for each client, a page each: their identifiers, and their status on FBR's income tax and
    sales tax Active Taxpayer Lists as TaxDesk last found it, with the list dates and the changes seen. It says
    plainly that it is TaxDesk's reading of FBR's public lists, not an FBR document, and where to confirm it."""
    stamp = printed.strftime("%d %b %Y, %I:%M %p")
    pages = []
    for n, c in enumerate(clients):
        ntn = c["ntn"] or c["it_ntn"] or c["st_ntn"]
        reg = [("Name", html.escape(c["name"])), ("CNIC", html.escape(c["cnic"]) or "—"),
               ("NTN", html.escape(ntn) or "—"), ("STRN", html.escape(c["strn"]) or "—"),
               ("Name on FBR's list", html.escape(c["it_name"] or c["st_name"]) or "—"),
               ("Business name on FBR's list", html.escape(c["st_business"] or c["it_business"]) or "—")]
        reg += [(LABELS[f], html.escape(c[f])) for f in ("phone", "email") if c[f]]
        out = [f"<h2 style='margin:14px 0 4px'>{html.escape(c['name'])}</h2>",
               "<table width='100%' cellpadding='4' cellspacing='0' border='1' style='border-color:#c8ccd2'>"
               + _rows(reg) + "</table>"]
        for kind, title, what in (("it", "Income Tax", "income tax"), ("st", "Sales Tax", "sales tax")):
            status = c[f"{kind}_status"]
            color = {"active": "#15803d", "inactive": "#b91c1c"}.get(status, "#6b7280")
            shown = {"active": "Active: on the list", "inactive": "Inactive: not on the list"}.get(status, "Not checked")
            rows = [("Current ATL status", f"<b style='color:{color}'>{shown}</b>")]
            if status:
                rows += [("FBR list of", _day(c[f"{kind}_list"])),
                         ("Status since the list of", _day(c[f"{kind}_since"]) or "—"),
                         ("Checked by TaxDesk on", c[f"{kind}_checked"].replace("T", " ")[:16])]
                if status == "active":
                    rows[1:1] = [("Name on the list", html.escape(c[f"{kind}_name"]) or "—"),
                                 ("Registration no. on the list", html.escape(c[f"{kind}_ntn"]) or "—")]
                    if kind == "st" and c["st_business"]:
                        rows.insert(3, ("Business name on the list", html.escape(c["st_business"])))
            elif not (c["cnic"] or c["ntn"]):
                rows.append(("Why", "No CNIC or NTN on file to check against FBR's list."))
            out.append(f"<h3 style='margin:14px 0 4px'>Active Taxpayer List ({title})</h3>"
                       "<table width='100%' cellpadding='4' cellspacing='0' border='1' style='border-color:#c8ccd2'>"
                       + _rows(rows) + "</table>")
            if status == "inactive":
                out.append("<p style='font-size:9pt; color:#374151'>"
                           + ("Not on the income tax ATL: withholding agents deduct tax at the higher rates for persons "
                              "not on the list (Tenth Schedule, ITO 2001). Filing the latest return and paying the ATL "
                              "surcharge restores the status (section 181A)." if kind == "it" else
                              "Not on the sales tax ATL: usually returns haven't been filed, or the registration is "
                              "suspended or blacklisted (sections 14 and 26, STA 1990).") + "</p>")
        changes = [h for h in history if h["client_id"] == c["id"]]
        if changes:
            out.append("<h3 style='margin:14px 0 4px'>Changes seen</h3>"
                       "<table width='100%' cellpadding='4' cellspacing='0' border='1' style='border-color:#c8ccd2'>"
                       "<tr><td><b>FBR list of</b></td><td><b>List</b></td><td><b>Change</b></td></tr>"
                       + "".join(f"<tr><td>{_day(h['list_date'])}</td><td>{'Income tax' if h['kind'] == 'IT' else 'Sales tax'}"
                                 f"</td><td>{STATUS_TEXT[h['old']]} → {STATUS_TEXT[h['new']]}</td></tr>" for h in changes)
                       + "</table>")
        out.append("<p style='font-size:8pt; color:#6b7280; margin-top:16px'>Prepared with TaxDesk from FBR's public "
                   "Active Taxpayer Lists (download.fbr.gov.pk ATL_IT.xlsx and ATL_ST.xlsx), matched by CNIC or NTN on "
                   "this computer. This is not a document issued by FBR. To confirm a status, use FBR's online "
                   "verification at iris.fbr.gov.pk or e.fbr.gov.pk, or send “ATL &lt;CNIC&gt;” by SMS to 9966.</p>")
        brk = " style='page-break-before:always'" if n else ""
        pages.append(f"<div{brk}><table width='100%' cellpadding='0' cellspacing='0'><tr>"
                     "<td><b style='font-size:15pt'>FBR status report</b><br><span style='color:#6b7280'>Income tax "
                     "and sales tax Active Taxpayer Lists</span></td>"
                     f"<td align='right' style='color:#6b7280'>TaxDesk<br>Printed {stamp}</td></tr></table>"
                     "<hr>" + "".join(out) + "</div>")
    return f"<div style='font-family:Helvetica,Arial,sans-serif; font-size:10pt'>{''.join(pages)}</div>"
