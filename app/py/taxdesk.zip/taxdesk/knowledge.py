"""Concept library: the ideas behind the return, the law they come from, and how they relate.

Every computation step carries a concept id, so "why?" on any figure opens its explanation here.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Concept:
    id: str
    title: str
    area: str  # one of AREAS
    law: str
    summary: str
    detail: str
    example: str = ""


C = Concept
CONCEPTS: list[Concept] = [
    # ------------------------------------------------------------------ basics
    C("tax_year", "Tax year", "Basics", "Section 74",
      "The 12-month period, normally 1 July to 30 June, named after the year in which it ends.",
      "Income earned from 1 July 2024 to 30 June 2025 belongs to Tax Year 2025. Each tax year has its own "
      "rates, set by the Finance Act passed in the June before it starts.",
      "Salary for March 2025 → Tax Year 2025 → return due by 30 September 2025."),
    C("ntn_registration", "NTN registration", "Basics", "Section 181; rule 80",
      "Every person required to file a return must register and get a National Tax Number (for individuals, the CNIC).",
      "Registration is done online. It doesn't create tax by itself; it identifies you so returns, withholding "
      "certificates and refunds can be matched to you."),
    C("return_obligation", "Who must file a return", "Basics", "Section 114; rule 34",
      "A return is required when taxable income exceeds the tax-free limit, and also in other cases set by law.",
      "Besides income above the exemption limit, a return is needed by every company and AOP, anyone who owns "
      "immovable property or a motor vehicle above prescribed limits, holds certain commercial or industrial "
      "electricity connections, or is notified by the Commissioner. Filing puts you on the Active Taxpayers List.",
      "Taxable income Rs 550,000 but owns a car above 1000cc → must still file."),
    C("atl", "Active Taxpayers List (ATL)", "Basics", "Section 181A; rule 81B; Tenth Schedule",
      "People who filed their return for the latest tax year. Being on it roughly halves many withholding rates.",
      "Withholding agents check the ATL before deducting tax. A person not on it pays higher rates (often double) "
      "on bank profit, dividends, property transfers, vehicles and more. Late filers can join the ATL by paying a "
      "surcharge."),
    C("residency", "Residence", "Basics", "Sections 81–82",
      "Residents are taxed on worldwide income; non-residents only on income from Pakistan.",
      "An individual is resident if present in Pakistan for 183 days or more in the tax year (or 120 days and "
      "365 days over the previous four years), or is a federal/provincial employee posted abroad."),
    C("heads_of_income", "Heads of income", "Income tax", "Section 11",
      "Income is grouped under five heads: salary, property, business, capital gains and other sources.",
      "Each head has its own rules for what counts and what can be deducted. The head decides the regime: "
      "salary, business and other sources are added together (normal regime); property, capital gains, "
      "dividend and bank profit are mostly taxed separately."),
    # ------------------------------------------------------------------ income
    C("salary_income", "Income from salary", "Income tax", "Section 12",
      "Everything received from employment: basic pay, allowances, bonuses and benefits (perquisites).",
      "Salary is taxed when received. The employer deducts tax every month under section 149 using the "
      "employee's expected yearly income; that tax is adjustable in the return.",
      "Basic 1,800,000 + allowances 600,000 + medical 180,000 = gross salary 2,580,000."),
    C("perquisites", "Perquisites", "Income tax", "Section 13; rules 3–5",
      "Benefits from the employer valued as salary: car, accommodation, utilities, loans at low interest.",
      "Section 13 sets the value: e.g. a car partly for private use counts as a percentage of its cost; "
      "accommodation counts at the higher of the rent paid by the employer and 45% of the basic salary minimum."),
    C("exemptions", "Exemptions", "Income tax", "Second Schedule, Part I",
      "Income the law excludes from tax, e.g. medical allowance up to 10% of basic, pension, certain scholarships.",
      "Exempt amounts are not taxable income, but they still explain wealth, so they appear in the wealth "
      "reconciliation as inflows.", "Basic 1,200,000; medical allowance 150,000 → 120,000 exempt, 30,000 taxable."),
    C("agricultural_income", "Agricultural income", "Income tax", "Section 41; provincial laws",
      "Exempt from federal income tax; taxed by the province under its agricultural income tax law.",
      "Declare it in the return as exempt income and keep the provincial tax receipts. It explains wealth like "
      "any other income."),
    C("business_income", "Income from business", "Income tax", "Section 18",
      "Profit from trade, profession or vocation: turnover less cost of sales and admissible expenses.",
      "Computed from accounts, then adjusted for tax rules: inadmissible expenses are added back and tax "
      "depreciation replaces accounting depreciation."),
    C("admissible_expenses", "Admissible expenses", "Income tax", "Section 20",
      "Expenses incurred wholly and exclusively to earn business income are deductible.",
      "Rent of business premises, salaries, utilities, repairs, advertising and so on. They must be real, "
      "documented and paid through proper channels."),
    C("inadmissible_expenses", "Inadmissible expenses", "Income tax", "Section 21",
      "Expenses the law refuses, even if spent in the business.",
      "Personal expenses; tax itself; cash payments above the prescribed limit; payments on which tax should "
      "have been withheld but wasn't; fines; capital expenditure (claimed through depreciation instead).",
      "Supplier paid 500,000 without deducting s.153 tax → 500,000 disallowed."),
    C("depreciation", "Tax depreciation", "Income tax", "Sections 22–23; Third Schedule; rule 12",
      "Wear and tear on business assets claimed at rates set by law, plus an initial allowance on new assets.",
      "Accounting depreciation is added back and replaced by tax depreciation at Third Schedule rates."),
    C("loss_setoff", "Losses: set-off and carry-forward", "Income tax", "Sections 56–59",
      "A business loss can't reduce salary or property income; it is carried forward for six years.",
      "Losses under one head can be set off against income under another head except salary and property. "
      "Unabsorbed business losses carry forward six tax years (depreciation losses without limit). Capital "
      "losses only against capital gains."),
    C("other_sources", "Income from other sources", "Income tax", "Section 39",
      "Income not under any other head: e.g. profit on debt, dividends, prizes, certain gifts.",
      "Some of it is taxed separately (dividend, bank profit up to the limit); the rest joins normal income."),
    C("property_income", "Income from property", "Income tax", "Sections 15, 15A",
      "Rent from land and buildings, less the section 15A allowances, added to other income.",
      "Rent received or receivable is reduced by a repairs allowance of one-fifth of the rent and the other section "
      "15A deductions (insurance, property tax, profit on money borrowed for the property, collection charges up to "
      "4%). The result joins salary, business and other income in taxable income; the separate property rates were "
      "omitted by the Finance Act 2021. Tax deducted by tenants under section 155 is adjustable. Co-owners are taxed "
      "on their own shares.",
      "Rent 1,200,000 − repairs allowance 240,000 = 960,000 added to taxable income."),
    C("co_ownership", "Co-ownership", "Planning", "Section 66",
      "Income from jointly owned property is divided between the owners in their ownership shares.",
      "Each co-owner is taxed on their own share, on their own slabs. Real joint ownership (registered "
      "documents, own funds) can lower the total tax lawfully."),
    C("capital_gains", "Capital gains", "Income tax", "Sections 37, 37A; rule 13C",
      "Gain on selling property or securities, taxed separately at rates that depend on when the asset was bought.",
      "For assets acquired from 1 July 2024, active taxpayers pay a flat 15%. Older assets follow a holding-period "
      "table, reaching 0% after enough years. A capital loss only offsets capital gains.",
      "Plot bought 2019 for 10m, sold 2025 for 16m → held 6+ years → 0% under the old table."),
    C("profit_on_debt", "Profit on debt", "Income tax", "Section 7B; section 151",
      "Interest/profit from bank deposits and savings, taxed separately at a fixed rate up to the limit.",
      "The bank deducts tax under section 151. Within the limit this is the final tax on that profit; above it "
      "the profit is taxed with normal income."),
    C("dividend", "Dividend", "Income tax", "Section 5; section 150",
      "Dividends are taxed separately at fixed rates; the company deducts the tax when paying.",
      "Rates differ by source (e.g. higher for funds earning mostly interest, lower for IPPs). The deduction is a "
      "final tax."),
    C("normal_tax_regime", "Normal tax regime (NTR)", "Income tax", "Sections 4, 9, 10",
      "Salary, business and other income added together and taxed at the slab rates.",
      "Taxable income = total income − deductible allowances. Tax = slab rates, less reductions and credits, "
      "less adjustable tax paid."),
    C("separate_block", "Separate block of income", "Income tax", "Section 4(5A)–(6)",
      "Income taxed on its own at its own rates, not added to normal income.",
      "Capital gains on property and securities, dividends and profit on debt within the limit. Keeping them separate "
      "stops them pushing other income into higher slabs."),
    C("taxable_income", "Taxable income", "Income tax", "Section 9",
      "Total income less deductible allowances. The figure the slab rates apply to.", ""),
    C("deductible_allowances", "Deductible allowances", "Income tax", "Sections 60, 60D",
      "Amounts deducted from income before tax: Zakat, education expenses (for lower incomes).",
      "An allowance reduces taxable income, so it saves tax at your top slab rate, unlike a credit, which "
      "saves at your average rate.", "Zakat 50,000 at a 25% top rate saves 12,500."),
    C("slab_rates", "Slab rates", "Income tax", "First Schedule, Part I, Division I",
      "Tax is a fixed amount plus a percentage of income above the slab's lower limit.",
      "Only the part of income inside each slab is taxed at that slab's rate, so moving into a higher slab never "
      "makes total tax jump on all income."),
    C("salaried_test", "Salaried individual (75% test)", "Income tax", "First Schedule, Part I, Div. I, para (1A)",
      "If salary is more than 75% of taxable income, the lower salaried rates apply to all of it.",
      "Otherwise the non-salaried (business) rates apply, which are much higher. A small salary with a large "
      "business income is taxed at business rates.",
      "Salary 3m, other income 0.5m → salary 86% → salaried table."),
    C("tax_reductions", "Tax reductions", "Income tax", "Second Schedule, Part III",
      "Reductions in tax for particular persons, e.g. senior citizens with lower incomes.",
      "A reduction cuts the tax itself by a percentage, after the slab computation."),
    C("tax_credits", "Tax credits", "Income tax", "Sections 61–65; rule 211",
      "Tax reduced by the average rate × the eligible amount: donations (up to 30%), pension (up to 20%).",
      "Average rate = tax on taxable income ÷ taxable income. A credit can't make tax negative.",
      "Tax 300,000 on 2,000,000 (avg 15%); donation 100,000 → credit 15,000."),
    C("average_rate", "Average rate of tax", "Income tax", "Section 61(2)",
      "Tax on taxable income divided by taxable income, used for every tax credit.", ""),
    C("surcharge", "Surcharge", "Income tax", "Section 4AB",
      "An extra percentage of tax for individuals and AOPs with taxable income above Rs 10 million.", ""),
    C("minimum_tax", "Minimum tax", "Income tax", "Sections 148, 153, 233, 113",
      "Tax deducted on certain receipts that is the least tax payable on that income, even if the computed tax is lower.",
      "If the tax worked out on income is higher, you pay the higher amount; if lower, the minimum stands and "
      "isn't refunded.", "Supplier: 5.5% deducted on 10m sales = 550,000; computed tax 300,000 → liability 550,000."),
    C("final_tax", "Final tax regime (FTR)", "Withholding", "Section 8; various",
      "Tax deducted at source that settles the tax on that income completely.",
      "The income isn't added to normal income and the tax isn't refundable. Examples: dividend, profit on debt "
      "within the limit, certain contract receipts."),
    C("adjustable_tax", "Adjustable (advance) tax", "Withholding", "Sections 147, 149, 231B, 235, 236, 236K...",
      "Tax collected in advance and credited against your total tax in the return.",
      "If adjustable tax is more than your total tax, the difference is refundable. Keep every certificate: "
      "salary, vehicle, electricity, phone, property purchase."),
    C("withholding_agent", "Withholding agent", "Withholding", "Sections 158, 160, 161, 164, 165; rules 42–44",
      "A person who must deduct tax from payments and deposit it with the government.",
      "Employers, companies, banks and government bodies deduct tax, deposit it within the time allowed and "
      "report it in statements under section 165. Not deducting makes the agent personally liable (s.161) and "
      "the expense inadmissible (s.21)."),
    C("withholding_statement", "Withholding statement (s.165)", "Withholding", "Section 165; rule 44",
      "The periodic statement in which an agent lists every payee, payment and tax deducted.",
      "FBR matches these statements with payees' returns. Mismatches lead to notices for both sides."),
    C("tax_chargeable", "Tax chargeable", "Income tax", "Section 4",
      "Total tax for the year: normal tax after credits, plus surcharge, plus separate-block taxes.", ""),
    C("tax_payable_refund", "Tax payable or refundable", "Income tax", "Sections 137, 170; rule 210IC",
      "Tax chargeable minus tax paid/deducted. Payable is paid with the return; an excess of adjustable tax is refundable.",
      "Final and minimum tax aren't refundable."),
    # ------------------------------------------------------------------ wealth
    C("wealth_statement", "Wealth statement", "Wealth", "Section 116; rule 36",
      "A list of assets and liabilities at the end of the tax year, filed with the return.",
      "Assets are shown at cost, with those held in the names of spouse and minor children. Personal expenses "
      "for the year are declared too."),
    C("wealth_reconciliation", "Wealth reconciliation", "Wealth", "Section 116(2)",
      "Increase in net assets must equal inflows (income, exempt income, gifts...) minus outflows (expenses, taxes...).",
      "Net assets closing − opening = income declared + exempt income + other inflows − personal expenses − "
      "taxes − other outflows. Any difference is 'unreconciled'.",
      "Net assets up 2.0m; income after tax 1.6m; expenses 0.9m → 1.3m unexplained."),
    C("unexplained_income", "Unexplained income or assets", "Wealth", "Section 111",
      "Money or assets whose source isn't satisfactorily explained can be added to income.",
      "This is how wealth not matching declared income gets taxed. Foreign remittances through banks within the "
      "law's conditions are protected (s.111(4))."),
    C("personal_expenses", "Personal expenses", "Wealth", "Section 116",
      "Household spending declared each year; too low a figure makes the reconciliation fail.",
      "Rent, utilities, education, travel, vehicles, functions. FBR compares them with bills and lifestyle data."),
    C("foreign_remittance", "Foreign remittance", "Planning", "Section 111(4)",
      "Money remitted from abroad through banking channels is protected from being treated as unexplained income.",
      "Conditions and limits apply; keep the bank's encashment certificate."),
    # ------------------------------------------------------------------ sales tax
    C("st_registration", "Sales tax registration", "Sales tax", "Sections 2(5AB), 2(43A), 14; rules 5, 6, 11",
      "Manufacturers above the cottage threshold, importers, wholesalers and Tier-1 retailers must register.",
      "Registration gives an STRN. Registered persons charge output tax, claim input tax and file monthly returns."),
    C("output_tax", "Output tax", "Sales tax", "Section 3",
      "Sales tax charged on taxable supplies, 18% unless another rate applies.", ""),
    C("further_tax", "Further tax", "Sales tax", "Section 3(1A)",
      "An extra percentage on supplies to unregistered buyers; input tax can't be set against it.", ""),
    C("exempt_supplies", "Exempt and zero-rated supplies", "Sales tax", "Sections 4, 13; Fifth and Sixth Schedules",
      "Exempt: no tax and no input claim. Zero-rated (e.g. exports): 0% tax but input can be claimed.", ""),
    C("input_tax", "Input tax", "Sales tax", "Section 7; rule 22",
      "Sales tax paid on purchases used for taxable supplies, set off against output tax.",
      "Claim it within the allowed number of tax periods, and only if the supplier has declared the sale."),
    C("inadmissible_input", "Inadmissible input tax", "Sales tax", "Section 8; rule 25",
      "Input tax the law blocks: e.g. vehicles, entertainment, goods for exempt supplies, fake invoices.", ""),
    C("input_cap", "90% input limit", "Sales tax", "Section 8B",
      "Input tax can be adjusted only up to 90% of output tax each month; the rest carries forward.",
      "So at least 10% of output tax is paid in cash every month, with exceptions for some sectors."),
    C("carry_forward", "Carry-forward of excess input", "Sales tax", "Section 10; rule 34",
      "Input tax not adjusted this month is carried to the next; refunds only in specific cases (e.g. exports).", ""),
    C("st_payable", "Sales tax payable", "Sales tax", "Sections 6, 26; rules 14, 18",
      "Output tax − input tax adjusted + further tax; paid by the 15th, return by the 18th of the next month.", ""),
    C("provincial_services", "Sales tax on services", "Sales tax", "Provincial sales tax laws",
      "Services are taxed by the provinces (PRA, SRB, KPRA, BRA), with their own registration and returns.", ""),

    # ------------------------------------------------------------------ preliminary and charge of tax
    C("definitions", "Definitions and the Ordinance's reach", "Basics", "Sections 1–3",
      "Section 2 defines the terms used throughout the law; section 3 makes the Ordinance prevail over other laws.",
      "Many disputes turn on a definition in section 2: 'person', 'income', 'business', 'non-profit organisation' "
      "(s.2(36)), 'associate' and so on. Read the definition before the operative section. Section 3 says the "
      "Ordinance overrides anything inconsistent in other laws."),
    C("super_tax", "Super tax and other charging provisions", "Income tax", "Sections 4B, 4C, 5A, 6, 7",
      "Besides normal tax, the Ordinance charges super tax on high earners and separate taxes on particular receipts.",
      "Section 4C charges super tax on persons whose income exceeds the thresholds in Division IIB of the First "
      "Schedule. Other charging sections tax undistributed profits of companies (s.5A), certain payments to "
      "non-residents (s.6) and shipping or air transport income of non-residents (s.7). Each is computed on its own."),
    C("employee_share_schemes", "Employee share schemes", "Income tax", "Section 14",
      "Shares or options given to employees are taxed as salary when the employee gets them or can dispose of them.",
      "The taxable amount is broadly the market value of the shares less what the employee paid. A later sale is "
      "then a capital gain, with the cost including the amount already taxed as salary."),
    C("property_adjustments", "Property income: deductions and advances", "Income tax", "Sections 15A, 16",
      "Rent is reduced by the section 15A allowances; non-adjustable amounts from tenants are taxed over ten years (s.16).",
      "Section 15A allows a repairs allowance of one-fifth of the rent, insurance, local taxes, ground rent, profit "
      "on money borrowed for the property, collection charges up to 4% of rent, legal costs and irrecoverable rent. "
      "An amount received from a tenant that isn't adjustable against rent (such as a non-refundable advance) is "
      "taxed as rent in equal parts over the year received and the next nine (section 16)."),
    C("exemption_provisions", "Exemptions and concessions (Part VII)", "Income tax", "Sections 41–55",
      "Part VII lists income that is exempt or taxed at concessional rates, with the Second Schedule holding the details.",
      "Examples: agricultural income (s.41), income of diplomats and foreign officials (ss.42–44), the President's "
      "honours (s.45), scholarships (s.47) and the exemptions in the Second Schedule (s.53). Exempt income is still "
      "declared and explains wealth."),
    C("group_taxation", "Group taxation and group relief", "Income tax", "Sections 59AA, 59B",
      "Companies in a wholly owned group may be taxed as one unit or surrender losses to each other, if they qualify.",
      "Group taxation (s.59AA) lets a holding company and its wholly owned subsidiaries file as one fiscal unit; group "
      "relief (s.59B) lets a loss-making subsidiary pass its loss to a profitable group company. Conditions and "
      "approvals apply."),
    C("other_tax_credits", "Other tax credits", "Income tax", "Sections 63A, 65B, 65E–65G",
      "Further credits exist, e.g. for interest on a low-cost housing loan (s.63A), investment (s.65B) and certain industrial undertakings (ss.65E–65G).",
      "Each credit has its own conditions and limit and is usually valued at the average rate, like the donation and "
      "pension credits."),
    # ------------------------------------------------------------------ Part III: assets (sections 75–79)
    C("asset_disposal", "Disposal and acquisition of assets", "Income tax", "Section 75",
      "Defines when an asset is disposed of (sold, exchanged, transferred, cancelled...) and when it is acquired.",
      "Timing matters: a disposal fixes the year in which the gain or loss arises and starts the holding period of "
      "the person who acquires the asset. Section 75 also covers part disposals and assets that are lost or destroyed."),
    C("banking_channel_assets", "Purchase of assets through banking channel", "Income tax", "Section 75A",
      "Assets above the prescribed value must be paid for through the banking channel, or the payment isn't recognised.",
      "Paying cash for a high-value asset (such as property) risks the cost not being accepted and the money being "
      "questioned as unexplained under section 111. Keep the bank record of every large purchase.",
      "Plot bought for Rs 12m: pay by crossed cheque, pay order or bank transfer, and keep the record."),
    C("asset_cost", "Cost of an asset", "Income tax", "Section 76",
      "Cost is the price paid plus incidental expenses of acquiring, improving and disposing of the asset.",
      "Cost includes the purchase price, transfer fees and stamp duty, and capital improvements. Some items are "
      "excluded or adjusted, e.g. amounts already deducted, and the cost of assets received free or at less than "
      "market value follows special rules. A higher documented cost means a lower capital gain.",
      "Plot: price 8,000,000 + transfer costs 400,000 + boundary wall 600,000 → cost 9,000,000."),
    C("consideration_received", "Consideration received", "Income tax", "Section 77",
      "What is received on disposing of an asset: money plus the market value of anything else received.",
      "If an asset is exchanged, the market value of what is received counts. Where the law requires, the value "
      "notified for the area (e.g. FBR property valuation) is used instead of a lower declared price."),
    C("non_arms_length", "Non-arm's length transactions", "Income tax", "Section 78",
      "Between associates or not at arm's length, an asset's disposal and acquisition use fair market value.",
      "This stops gains being shifted by selling an asset to a relative or related company at an artificially low "
      "price. The buyer's cost is the same fair market value.", "Selling a plot worth 20m to your brother for 5m: "
      "taxed as if sold for 20m."),
    C("non_recognition", "Non-recognition of gains and losses", "Income tax", "Section 79",
      "Certain disposals are treated as giving rise to no gain or loss, so tax is deferred to a later real sale.",
      "Examples include transfers between spouses in specified circumstances, transfers on death, gift, bequest or "
      "will, and replacement of assets compulsorily acquired, subject to the section's conditions. The receiver "
      "generally takes over the transferor's cost."),
    # ------------------------------------------------------------------ persons
    C("persons", "Persons: individuals, AOPs and companies", "Persons and international", "Sections 80–84",
      "The Ordinance taxes three kinds of person: individuals, associations of persons and companies.",
      "The kind of person decides the rates (individuals and AOPs on slabs, companies at a flat rate), the return "
      "form and many withholding rules. Each kind has its own residence test (ss.81–84)."),
    C("associates", "Associates", "Persons and international", "Section 85",
      "People and entities whose relationship means one may act in the other's interest, e.g. relatives, partners, related companies.",
      "Associate status matters for non-arm's length rules (s.78), transfer pricing (s.108) and several anti-avoidance "
      "provisions."),
    C("individual_rules", "Individuals: deceased persons, minors and transfers", "Persons and international",
      "Sections 86–91",
      "Special rules cover income of deceased individuals, income of minor children and income from assets transferred to others.",
      "A deceased person's legal representative files for them (s.87). Income of a minor child can be taxed with a "
      "parent's income (s.91), and income from assets transferred without real change of ownership can be taxed in "
      "the transferor's hands (s.90)."),
    C("aop_taxation", "Associations of persons (AOPs)", "Persons and international", "Sections 88, 92",
      "A firm or other AOP is taxed as a person in its own right; the members' share of its after-tax profit is exempt.",
      "An individual member's share can still count when working out the rate on their other income (s.88). "
      "Partnerships and other AOPs use the AOP rate tables."),
    C("companies", "Companies and business reorganisations", "Persons and international", "Sections 94–98C",
      "Companies are taxed separately from their shareholders; transfers of a business into a company can be tax-neutral.",
      "A company pays tax on its own income and shareholders pay tax on dividends. Transfers of a business by an "
      "individual or AOP to a wholly owned company (ss.95–96), within a wholly owned group (s.97) or under a court "
      "scheme of arrangement (s.97A) can be made without gain or loss, if conditions are met. Changes in control "
      "affect losses (s.98)."),
    C("special_industries", "Special industries", "Persons and international",
      "Sections 99–100E; Fourth and Fifth Schedules",
      "Insurance, oil and gas and minerals, banking, builders and developers, and small and medium enterprises have special rules.",
      "Insurance (s.99, Fourth Schedule) and oil, gas and minerals (s.100, Fifth Schedule) compute income under their "
      "schedules; banking (s.100A), builders and developers (s.100D) and small and medium enterprises (s.100E) have their "
      "own provisions."),
    # ------------------------------------------------------------------ international
    C("source_rules", "Source of income", "Persons and international", "Sections 101–101A",
      "Rules deciding whether income comes from Pakistan, e.g. by where the work is done or the asset is.",
      "Non-residents are taxed only on Pakistan-source income, so the source rules decide what they pay. Residents "
      "are taxed on income from everywhere."),
    C("foreign_income", "Foreign-source income and foreign tax credit", "Persons and international", "Sections 102–104",
      "Residents are taxed on foreign income but get credit for foreign tax paid on it, up to the Pakistan tax on that income.",
      "Foreign losses are ring-fenced (s.104), and foreign tax credit (s.103) avoids paying full tax twice on the "
      "same income. Some foreign-source salary is exempt if tax is paid abroad (s.102)."),
    C("non_residents", "Taxation of non-residents", "Persons and international", "Sections 6, 105–106A",
      "Non-residents are taxed on Pakistan-source income, often by withholding; a permanent establishment is taxed on its profits.",
      "Royalties, fees for technical services and similar payments to non-residents are taxed under section 6, "
      "subject to any tax treaty. A non-resident's permanent establishment in Pakistan is taxed like a business "
      "(s.105). Thin capitalisation (s.106) and the limit on profit on debt paid to associated enterprises (s.106A) "
      "stop profits being shifted out as interest."),
    C("tax_treaties", "Tax treaties", "Persons and international", "Section 107",
      "Agreements with other countries to avoid double taxation; where they apply, they can override the Ordinance.",
      "A treaty may reduce withholding rates, allocate taxing rights or give relief; check residence certificates "
      "and the specific treaty."),
    # ------------------------------------------------------------------ procedure and administration
    C("assessments", "Assessments", "Procedure", "Sections 120–126",
      "A filed return is treated as an assessment order (deemed assessment); it can later be amended within time limits.",
      "Under section 120 the return becomes the assessment. The Commissioner can amend it (s.122) where income was "
      "understated, or make a best judgment assessment (s.121) where no return was filed. Provisional assessments "
      "(s.123) and time limits apply."),
    C("appeals", "Appeals", "Procedure", "Sections 127–136",
      "Orders can be challenged before the Commissioner (Appeals), then the Appellate Tribunal, then the High Court.",
      "Each level has filing deadlines and fees. Alternative dispute resolution (s.134A) is another route. Tax demanded "
      "may need to be paid or stayed while the appeal is decided."),
    C("representatives", "Representatives", "Procedure", "Sections 172–173",
      "People responsible for the tax obligations of another, e.g. guardians of minors or agents of non-residents.",
      "A representative files returns and pays tax on the other person's behalf and can be held liable."),
    C("records_audit", "Records, information and audit", "Procedure", "Sections 174–180",
      "Taxpayers must keep records; the department can call for information, inspect premises and audit.",
      "Records are kept for the period the law sets (s.174). Audit (s.177) selects cases by criteria or randomly; "
      "information can be gathered from third parties (ss.175–176)."),
    C("circulars", "Circulars", "Procedure", "Section 206",
      "FBR issues circulars to explain the law; they guide officers but can't override the Ordinance.",
      "Useful to understand FBR's view; courts decide the law."),
    C("administration", "Tax administration", "Procedure", "Sections 207–230K",
      "FBR and its Inland Revenue officers, their powers and the specialised directorates-general.",
      "Commissioners and other officers exercise powers delegated under the Ordinance; directorates-general handle "
      "intelligence, audit, broadening the tax base and other functions."),
    C("rules_power", "Power to make rules", "Basics", "Section 237",
      "FBR makes the Income Tax Rules 2002 under section 237: procedures, forms and valuations the Ordinance leaves to rules.",
      "The Rules fill in detail the Ordinance leaves out: return and wealth statement forms (rules 34, 36), "
      "certificates and statements of tax deducted (rules 42–44), valuation of perquisites (rules 3–5) and more. "
      "Rules can't go beyond the Ordinance."),
    C("prosecution", "Offences and prosecution", "Procedure", "Sections 191–204",
      "Serious defaults, false statements and concealment are offences that can lead to fines and imprisonment.",
      "These are separate from monetary penalties under section 182. Concealment of income and false statements "
      "in returns are among the offences (e.g. s.192)."),
    # ------------------------------------------------------------------ sales tax: remaining chapters
    C("st_definitions", "Sales tax definitions", "Sales tax", "Section 2",
      "Key definitions, e.g. cottage industry (s.2(5AB)) and Tier-1 retailer (s.2(43A)), decide who must register.",
      "Cottage industry: no industrial gas or electricity connection, in a residential area, ten workers or fewer, "
      "and turnover within the limit. Tier-1 retailer: a chain store, shop in an air-conditioned mall, high electricity "
      "bill, card point of sale, wholesaler-cum-retailer and other categories in the definition."),
    C("st_records_invoices", "Records and tax invoices", "Sales tax", "Sections 22–25AA",
      "Registered persons keep prescribed records and issue tax invoices for taxable supplies.",
      "A proper tax invoice (s.23) is what lets the buyer claim input tax. Records are kept for the period the law "
      "sets (s.24) and can be accessed and audited (s.25)."),
    C("st_officers", "Sales tax officers and their powers", "Sales tax", "Sections 30–32A",
      "Officers of Inland Revenue are appointed with powers to administer sales tax.", ""),
    C("st_penalties", "Sales tax offences and penalties", "Sales tax", "Sections 33–40E",
      "Late returns, late payment, fake invoices and other defaults carry penalties; default surcharge applies to late tax.",
      "Section 33 tabulates offences and penalties; section 34 charges default surcharge on unpaid tax."),
    C("st_appeals", "Sales tax appeals", "Sales tax", "Sections 45B–47A",
      "Orders can be appealed to the Commissioner (Appeals), the Appellate Tribunal and the High Court.", ""),
    C("st_recovery", "Recovery of sales tax arrears", "Sales tax", "Section 48",
      "Unpaid sales tax can be recovered by attachment of bank accounts and property and other means.", ""),
    C("st_banking_channel", "Payments through banking channel", "Sales tax", "Section 73",
      "Supplies above the prescribed value must be paid through the banking channel, or input tax can be refused.",
      "Paying a supplier in cash above the limit can cost the buyer the input tax on that invoice."),
    # ------------------------------------------------------------------ planning and compliance
    C("avoidance_vs_evasion", "Tax planning vs evasion", "Planning", "Sections 109, 111, 192",
      "Planning uses what the law allows; evasion hides or falsifies facts and is a crime.",
      "Using allowances, credits, exemptions, the right regime and real co-ownership is lawful planning. "
      "Understating income, fake expenses or invoices, or hiding assets is evasion, punishable with penalties and "
      "prosecution. Arrangements whose only purpose is avoiding tax can be disregarded (s.109)."),
    C("anti_avoidance", "Anti-avoidance (recharacterisation)", "Planning", "Section 109",
      "The Commissioner can disregard or recharacterise a transaction that lacks substance or is meant to avoid tax.",
      "So planning must be real: genuine ownership, real payments, proper documents."),
    C("penalties", "Penalties and default surcharge", "Basics", "Sections 182, 205",
      "Late filing, late payment and failures carry penalties; unpaid tax attracts default surcharge.",
      "Filing late also keeps you off the ATL, raising withholding on everyday transactions."),
]

# (from, to, how they relate)
RELATIONS: list[tuple[str, str, str]] = [
    ("tax_year", "return_obligation", "sets the period for"), ("return_obligation", "atl", "filing puts you on"),
    ("ntn_registration", "return_obligation", "comes before"), ("residency", "heads_of_income", "decides scope of"),
    ("atl", "adjustable_tax", "lowers rates of"), ("atl", "final_tax", "lowers rates of"),
    ("atl", "capital_gains", "changes rates of"),
    ("heads_of_income", "salary_income", "includes"), ("heads_of_income", "property_income", "includes"),
    ("heads_of_income", "business_income", "includes"), ("heads_of_income", "capital_gains", "includes"),
    ("heads_of_income", "other_sources", "includes"),
    ("salary_income", "perquisites", "includes"), ("salary_income", "exemptions", "reduced by"),
    ("salary_income", "normal_tax_regime", "taxed under"), ("salary_income", "salaried_test", "decides"),
    ("salary_income", "adjustable_tax", "tax deducted under s.149 is"),
    ("business_income", "admissible_expenses", "reduced by"), ("business_income", "inadmissible_expenses", "not reduced by"),
    ("business_income", "depreciation", "reduced by"), ("business_income", "loss_setoff", "losses follow"),
    ("business_income", "normal_tax_regime", "taxed under"), ("business_income", "minimum_tax", "may be subject to"),
    ("other_sources", "profit_on_debt", "includes"), ("other_sources", "dividend", "includes"),
    ("other_sources", "normal_tax_regime", "remainder taxed under"),
("capital_gains", "separate_block", "is a"),
    ("profit_on_debt", "separate_block", "within limit is a"), ("dividend", "separate_block", "is a"),
    ("profit_on_debt", "final_tax", "deduction is"), ("dividend", "final_tax", "deduction is"),
    ("property_income", "co_ownership", "split by"), ("property_income", "adjustable_tax", "s.155 deduction is"),
    ("normal_tax_regime", "taxable_income", "produces"), ("deductible_allowances", "taxable_income", "reduce"),
    ("taxable_income", "slab_rates", "taxed at"), ("salaried_test", "slab_rates", "chooses table of"),
    ("slab_rates", "average_rate", "gives"), ("average_rate", "tax_credits", "values"),
    ("tax_reductions", "tax_chargeable", "reduce"), ("tax_credits", "tax_chargeable", "reduce"),
    ("surcharge", "tax_chargeable", "adds to"), ("separate_block", "tax_chargeable", "adds to"),
    ("minimum_tax", "tax_chargeable", "sets a floor for"),
    ("tax_chargeable", "tax_payable_refund", "minus taxes paid gives"),
    ("adjustable_tax", "tax_payable_refund", "credited in"), ("final_tax", "tax_payable_refund", "not refundable in"),
    ("withholding_agent", "withholding_statement", "files"), ("withholding_statement", "adjustable_tax", "reports"),
    ("withholding_statement", "final_tax", "reports"), ("withholding_agent", "inadmissible_expenses", "failure makes"),
    ("tax_payable_refund", "wealth_reconciliation", "taxes are an outflow in"),
    ("taxable_income", "wealth_reconciliation", "is an inflow in"), ("exemptions", "wealth_reconciliation", "inflow in"),
    ("agricultural_income", "exemptions", "is federally"), ("agricultural_income", "wealth_reconciliation", "inflow in"),
    ("wealth_statement", "wealth_reconciliation", "is checked by"),
    ("personal_expenses", "wealth_reconciliation", "outflow in"),
    ("wealth_reconciliation", "unexplained_income", "a gap leads to"),
    ("foreign_remittance", "unexplained_income", "protected from"),
    ("st_registration", "output_tax", "requires charging"), ("output_tax", "input_cap", "limits input via"),
    ("input_tax", "input_cap", "limited by"), ("inadmissible_input", "input_tax", "excluded from"),
    ("input_cap", "carry_forward", "excess goes to"), ("output_tax", "st_payable", "minus input gives"),
    ("further_tax", "st_payable", "adds to"), ("exempt_supplies", "input_tax", "blocks"),
    ("provincial_services", "st_registration", "separate from"),
    ("avoidance_vs_evasion", "anti_avoidance", "limited by"), ("anti_avoidance", "co_ownership", "requires substance in"),
    ("avoidance_vs_evasion", "tax_credits", "lawful use of"), ("avoidance_vs_evasion", "deductible_allowances", "lawful use of"),
    ("avoidance_vs_evasion", "unexplained_income", "evasion detected by"), ("penalties", "atl", "late filing removes"),
    ("definitions", "heads_of_income", "defines terms for"), ("super_tax", "tax_chargeable", "adds to"),
    ("employee_share_schemes", "salary_income", "is part of"), ("property_adjustments", "property_income", "adjusts"),
    ("exemption_provisions", "exemptions", "contains"), ("exemption_provisions", "agricultural_income", "includes"),
    ("group_taxation", "loss_setoff", "extends"), ("other_tax_credits", "tax_credits", "adds to"),
    ("asset_disposal", "capital_gains", "decides timing of"), ("asset_cost", "capital_gains", "is deducted in"),
    ("consideration_received", "capital_gains", "is the proceeds in"), ("non_arms_length", "consideration_received", "replaces with market value"),
    ("non_recognition", "capital_gains", "defers"), ("banking_channel_assets", "asset_cost", "is a condition for"),
    ("banking_channel_assets", "unexplained_income", "cash purchases risk"), ("asset_disposal", "depreciation", "ends"),
    ("associates", "non_arms_length", "triggers"), ("persons", "slab_rates", "decides the table of"),
    ("persons", "aop_taxation", "includes"), ("persons", "companies", "includes"), ("residency", "persons", "applies to"),
    ("individual_rules", "co_ownership", "limits"), ("individual_rules", "anti_avoidance", "is a form of"),
    ("companies", "dividend", "pays"), ("special_industries", "business_income", "modifies"),
    ("source_rules", "non_residents", "decides tax of"), ("residency", "foreign_income", "makes taxable"),
    ("foreign_income", "tax_credits", "gives a credit like"), ("tax_treaties", "non_residents", "can reduce tax of"),
    ("tax_treaties", "foreign_income", "relieves"), ("return_obligation", "assessments", "filing becomes"),
    ("assessments", "unexplained_income", "can add"), ("assessments", "appeals", "can be challenged by"),
    ("records_audit", "assessments", "leads to amended"), ("circulars", "administration", "issued by"),
    ("administration", "records_audit", "conducts"), ("rules_power", "withholding_statement", "prescribes form of"),
    ("rules_power", "wealth_statement", "prescribes form of"), ("rules_power", "perquisites", "values"),
    ("prosecution", "avoidance_vs_evasion", "punishes evasion in"), ("representatives", "return_obligation", "carries out"),
    ("st_definitions", "st_registration", "decides"), ("st_records_invoices", "input_tax", "a tax invoice allows"),
    ("st_banking_channel", "input_tax", "cash payments lose"), ("st_penalties", "st_payable", "late payment adds to"),
    ("st_officers", "st_records_invoices", "audit"), ("st_appeals", "st_penalties", "challenge"),
    ("st_recovery", "st_payable", "collects unpaid"),
]

BY_ID = {c.id: c for c in CONCEPTS}
AREAS = ["Basics", "Income tax", "Persons and international", "Withholding", "Wealth", "Procedure", "Sales tax",
         "Planning"]


def related(concept_id: str) -> list[tuple[str, str, str]]:
    """[(direction, label, other id)] for a concept: outgoing then incoming relations."""
    out = [("→", label, b) for a, b, label in RELATIONS if a == concept_id]
    out += [("←", label, a) for a, b, label in RELATIONS if b == concept_id]
    return out


def search(text: str) -> list[Concept]:
    t = text.strip().lower()
    if not t:
        return list(CONCEPTS)
    return [c for c in CONCEPTS if t in f"{c.title} {c.law} {c.summary} {c.detail}".lower()]
