"""The law's wording and index: the copy built into TaxDesk, or a newer edition the owner has published since.

The owner publishes a law update from TaxDesk Admin (Law tab) to the downloads repository: a folder law/<version>/
with the data files (law_text.json.gz, law_text_previous.json.gz, law_index.json) and manifest.json, which names the
editions and each file's SHA-256 and is signed with the owner's key. control.json points to the newest manifest
({"law": {"version", "manifest"}}). TaxDesk offers it on the Law changes page; installing it downloads the files,
checks the signature and every checksum, and keeps them in the user's data folder (law/). An installed update is used
while it is newer than the copy built into the app, so a later app version with newer law brings its own.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import urllib.request
from pathlib import Path
from typing import Callable

from . import __version__, licence

BUNDLED = Path(__file__).resolve().parent / "data"
FILES = ("law_text.json.gz", "law_text_previous.json.gz", "law_index.json")
MANIFEST = "law_manifest.json"  # the built-in copy's manifest (an installed update keeps its own as manifest.json)
_update_dir: Path | None = None


def set_update_dir(path: Path | str | None) -> None:
    """Where installed law updates are kept (the app sets this to its data folder's law/ at start)."""
    global _update_dir
    _update_dir = Path(path) if path else None
    reload()


def _read(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def bundled_manifest() -> dict:
    return _read(BUNDLED / MANIFEST) or {"version": "0"}


def installed_manifest() -> dict | None:
    """The installed update's manifest, if one is installed and all its files are there."""
    if not _update_dir:
        return None
    m = _read(_update_dir / "manifest.json")
    return m if m and all((_update_dir / f).exists() for f in m.get("files", {})) else None


def manifest() -> dict:
    """The manifest of the copy in use: an installed update newer than the built-in copy, or the built-in copy."""
    inst, built = installed_manifest(), bundled_manifest()
    return inst if inst and inst.get("version", "") > built.get("version", "") else built


def path(name: str) -> Path:
    """A law data file of the copy in use."""
    inst = installed_manifest()
    if inst and _update_dir and name in inst.get("files", {}) \
            and inst.get("version", "") > bundled_manifest().get("version", ""):
        return _update_dir / name
    return BUNDLED / name


def version() -> str:
    return manifest().get("version", "0")


def reload() -> None:
    """Forget the cached law, so the next look reads the copy now in use."""
    from . import changes, law
    for f in (law._texts, law._index, changes._previous, changes.changes):
        f.cache_clear()


# ---------------------------------------------------------------- updates
def available(control: dict | None) -> dict | None:
    """The law update control.json offers ({"version", "manifest", "editions"?}), when it is newer than the law in
    use."""
    info = (control or {}).get("law")
    return info if isinstance(info, dict) and info.get("manifest") and str(info.get("version", "")) > version() else None


def _fetch(url: str, timeout: float = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": f"TaxDesk/{__version__}", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 - the owner's https URLs
        return r.read()


def install(info: dict, fetch: Callable[[str], bytes] = _fetch, progress: Callable[[str], None] | None = None,
            public_key: str = licence.PUBLIC_KEY) -> dict:
    """Download a law update, check the owner's signature and every file's checksum, and install it. Returns its
    manifest. Nothing in use changes unless every file checks out."""
    if not _update_dir:
        raise RuntimeError("TaxDesk has no folder for law updates.")
    say = progress or (lambda _: None)
    say("Checking the update…")
    m = licence.verify_data(json.loads(fetch(info["manifest"]).decode("utf-8")), public_key)
    if str(m.get("version")) != str(info.get("version")):
        raise ValueError("The update doesn't match the version announced. Try again in a few minutes.")
    staging = _update_dir.with_name(_update_dir.name + ".new")
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True)
    try:
        for name, f in m["files"].items():
            if name not in FILES:
                raise ValueError(f"Unexpected file in the update: {name}")
            say(f"Downloading {name} ({f['size'] / 1e6:.1f} MB)…")
            data = fetch(f["url"])
            if hashlib.sha256(data).hexdigest() != f["sha256"]:
                raise ValueError(f"{name} didn't download correctly. Try again in a few minutes.")
            (staging / name).write_bytes(data)
        (staging / "manifest.json").write_text(json.dumps(m, indent=1, ensure_ascii=False), encoding="utf-8")
        old = _update_dir.with_name(_update_dir.name + ".old")
        shutil.rmtree(old, ignore_errors=True)
        if _update_dir.exists():
            _update_dir.rename(old)
        staging.rename(_update_dir)
        shutil.rmtree(old, ignore_errors=True)
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    reload()
    return m


def editions_text(m: dict | None = None) -> str:
    """'ITO amended up to 30 June 2027 · …' from a manifest's sources."""
    from . import law
    sources = (m or manifest()).get("sources", {})
    return " · ".join(f"{law.ABBR[a]} {s['edition']}" for a, s in sources.items() if a in law.ABBR and s.get("edition"))
