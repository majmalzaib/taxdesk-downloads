"""The documents and forms the Income Tax Rules 2002 and the Sales Tax Rules 2006 prescribe: data/forms.json, built by
tools/build_forms.py from FBR's consolidated PDFs, with a picture of each form's first page in data/forms/."""
from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

DATA = Path(__file__).resolve().parent / "data"


@dataclass(frozen=True)
class Form:
    act: str
    index: int
    group: str
    name: str  # "STR-1", "Part VII"
    title: str
    pages: tuple[int, int]  # in FBR's consolidated PDF
    rules: tuple[str, ...]  # the rules that prescribe it
    image: str

    @property
    def picture(self) -> Path:
        return DATA / "forms" / self.image

    @property
    def page_count(self) -> int:
        return self.pages[1] - self.pages[0] + 1


@lru_cache(maxsize=1)
def _data() -> dict:
    try:
        return json.loads((DATA / "forms.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def forms(act: str) -> list[Form]:
    return [Form(act, i, f["group"], f["name"], f["title"], tuple(f["pages"]), tuple(f["rules"]), f["image"])
            for i, f in enumerate(_data().get(act, {}).get("forms", []))]


def groups(act: str) -> list[str]:
    return list(dict.fromkeys(f.group for f in forms(act)))


def source(act: str) -> tuple[str, str]:
    """(FBR's PDF the pages are in, its edition)."""
    d = _data().get(act, {})
    return d.get("source", ""), d.get("edition", "")


def pdf_link(form: Form) -> str:
    """FBR's PDF, opening at the form's first page."""
    return f"{source(form.act)[0]}#page={form.pages[0]}"


def prescribed_by(act: str, rule: str) -> list[Form]:
    """The forms a rule prescribes, for its card."""
    return [f for f in forms(act) if rule in f.rules]
