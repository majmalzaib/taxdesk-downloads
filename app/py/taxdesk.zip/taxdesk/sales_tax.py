"""Monthly sales tax return under the Sales Tax Act 1990 (goods).

Output tax on taxable supplies (Annex C), further tax on supplies to unregistered buyers, input tax
on purchases (Annex A) limited by section 8 (inadmissible) and section 8B (up to 90% of output tax),
and excess input carried forward to the next month (section 10).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .rules import Rules, load, money


def blank_return(year: int) -> dict[str, Any]:
    return {"kind": "str", "tax_year": year, "period": "", "business": {"name": "", "strn": ""},
            "sales": [], "purchases": [], "carry_forward_in": 0}


@dataclass
class Line:
    label: str
    amount: float
    law: str = ""
    note: str = ""
    concept: str = ""
    total: bool = False


@dataclass
class STResult:
    lines: list[Line] = field(default_factory=list)
    figures: dict[str, float] = field(default_factory=dict)

    def add(self, label: str, amount: float, law: str = "", note: str = "", concept: str = "", total: bool = False,
            key: str = "") -> float:
        amount = round(amount, 2)
        self.lines.append(Line(label, amount, law, note, concept, total))
        if key:
            self.figures[key] = amount
        return amount


def _n(v: Any) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def compute(ret: dict[str, Any], rules: Rules | None = None) -> STResult:
    rules = rules or load(int(ret.get("tax_year") or 2025))
    st = rules["sales_tax"]
    r = STResult()
    taxable = unregistered = exempt = 0.0
    output = 0.0
    for s in ret.get("sales", []):
        value = _n(s.get("value"))
        kind = s.get("type", "taxable")
        if kind == "exempt":
            exempt += value
            continue
        rate = _n(s.get("rate")) / 100 if s.get("rate") not in (None, "") else st["standard_rate"]
        if kind == "zero":
            rate = 0.0
        taxable += value
        output += value * rate
        if kind != "zero" and not s.get("buyer_registered", True):
            unregistered += value
    r.add("Value of taxable supplies (Annex C)", taxable, "Section 3", concept="output_tax")
    if exempt:
        r.add("Exempt supplies", exempt, "Section 13, Sixth Schedule",
              "No output tax, and input tax on these supplies can't be claimed.", "exempt_supplies")
    output = r.add("Output tax", output, "Section 3(1)",
                   f"Standard rate {st['standard_rate']:.0%} unless a different rate applies.", "output_tax", key="output")
    further = r.add("Further tax on supplies to unregistered buyers", unregistered * st["further_tax"], "Section 3(1A)",
                    f"{st['further_tax']:.0%} on {money(unregistered)} sold to unregistered persons. Input tax can't be "
                    "set against it.", "further_tax", key="further")

    claimed = inadmissible = capital = 0.0
    for p in ret.get("purchases", []):
        tax = _n(p.get("sales_tax"))
        if not p.get("admissible", True):
            inadmissible += tax
        elif p.get("capital") in (True, "yes"):
            capital += tax
        else:
            claimed += tax
    r.add("Input tax on purchases (Annex A)", claimed + capital + inadmissible, "Section 7", concept="input_tax")
    if inadmissible:
        r.add("Less: inadmissible input tax", -inadmissible, "Section 8",
              "e.g. vehicles, entertainment, goods not used for taxable supplies, or invoices not in the "
              "supplier's return.", "inadmissible_input")
    cf_in = _n(ret.get("carry_forward_in"))
    if cf_in:
        r.add("Add: input tax brought forward", cf_in, "Section 10", concept="carry_forward")
    available = claimed + cf_in
    cap = output * st["input_cap"]
    adjusted = min(available, cap)
    capital_adjusted = min(capital, max(0.0, output - adjusted))  # the 90% limit doesn't apply to capital goods
    if capital:
        r.add("Input tax on fixed assets / capital goods", capital, "Section 8B",
              "The 90% limit doesn't apply to fixed assets or capital goods (first proviso to section 8B(1)); "
              "they can be set off up to the full output tax.", "input_cap")
    r.add("Input tax adjusted", adjusted + capital_adjusted, "Section 8B",
          (f"Other input tax can be set off only up to {st['input_cap']:.0%} of output tax ({money(cap)})."
           if available > cap else "Within the 90% limit.")
          + (f" Capital goods adjusted: {money(capital_adjusted)}." if capital else ""), "input_cap", key="input_adjusted")
    available += capital
    adjusted += capital_adjusted
    carry = r.add("Excess input tax carried forward", available - adjusted, "Section 10",
                  "Claimed in following months.", "carry_forward", key="carry_forward")
    payable = r.add("Sales tax payable", output - adjusted + further, "Section 6",
                    "Output tax − input tax adjusted + further tax. Paid by the 15th; the return is filed by the 18th "
                    "of the next month.", "st_payable", total=True, key="payable")
    r.figures.update(taxable=taxable, unregistered=unregistered, available=available, carry=carry, payable=payable)
    return r


def registration_check(kind: str, turnover: float, *, electricity: float = 0, chain: bool = False,
                       ac_mall: bool = False, card_pos: bool = False, wholesale_retail: bool = False,
                       industrial_connection: bool = False, residential: bool = True, workers: int = 0,
                       rules: Rules | None = None) -> tuple[bool, str]:
    """Whether a business must register for sales tax (section 14), with the reason."""
    st = (rules or load(2025))["sales_tax"]
    if kind == "manufacturer":
        fails = [why for why, bad in (
            (f"turnover above {money(st['cottage_turnover'])}", turnover > st["cottage_turnover"]),
            ("an industrial gas or electricity connection", industrial_connection),
            ("located outside a residential area", not residential),
            ("more than ten workers", workers > 10)) if bad]
        if fails:
            return True, ("Not a cottage industry (section 2(5AB)) because of " + ", ".join(fails)
                          + ": a manufacturer must register (section 14).")
        return False, (f"Cottage industry under section 2(5AB): turnover up to {money(st['cottage_turnover'])}, no industrial "
                       "connection, residential area, ten workers or fewer. Not required to register. Registering "
                       "voluntarily lets you claim input tax.")
    if kind == "retailer":
        reasons = [t for t, ok in (
            ("part of a national or international chain of stores", chain),
            ("in an air-conditioned shopping mall, plaza or centre (not a kiosk)", ac_mall),
            (f"electricity bill over the last 12 months above {money(st['retailer_electricity'])}",
             electricity > st["retailer_electricity"]),
            ("accepts card payments through a bank's or payment provider's point of sale", card_pos),
            ("wholesaler-cum-retailer importing and supplying consumer goods", wholesale_retail)) if ok]
        if reasons:
            return True, ("Tier-1 retailer under section 2(43A) (" + "; ".join(reasons) + "): must register and "
                          "integrate with FBR's point-of-sale system.")
        return False, ("Not a Tier-1 retailer under section 2(43A): sales tax is collected through the electricity bill "
                       "instead of registration. Check also the section 236G/236H withholding threshold notified by FBR.")
    if kind == "importer":
        return True, "Importers of taxable goods must register (section 14)."
    if kind == "service":
        return False, ("Services are taxed by the provinces (PRA, SRB, KPRA, BRA) under their own laws, "
                       "not by FBR under the Sales Tax Act.")
    return True, "Wholesalers and distributors of taxable goods must register (section 14)."
