"""Lawful tax planning: options the law itself provides, with conditions, cautions and a what-if calculator.

Planning means arranging real affairs within the law (allowances, credits, exemptions, regimes,
thresholds). It never means hiding income or inventing expenses: that is evasion (section 192)
and arrangements without substance can be disregarded (section 109).
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any

from .income_tax import compute, merged
from .rules import money


@dataclass(frozen=True)
class Option:
    id: str
    category: str  # Registration | Income thresholds | Expenses and allowances | Exemptions and immunities
    title: str
    law: str
    how: str
    effect: str
    conditions: str
    caution: str
    concept: str = ""
    lever: str = ""  # what the calculator changes, if anything


O = Option
OPTIONS: list[Option] = [
    # ---------------------------------------------------------------- registration
    O("file_for_atl", "Registration", "File on time to stay on the Active Taxpayers List", "Section 181A; Tenth Schedule",
      "Register for NTN and file the return by the due date every year.",
      "Withholding on bank profit, dividends, property, vehicles and more is charged at the lower ATL rates.",
      "Return filed for the latest tax year; ATL is updated periodically.",
      "Filing late keeps you off the list until you pay the ATL surcharge.", "atl", "atl"),
    O("st_threshold", "Registration", "Stay within the cottage-industry limit, or register voluntarily", "Sales Tax Act 1990, section 14; Sales Tax Rules 2006, rules 5–6",
      "A small manufacturer below the turnover limit isn't required to register for sales tax.",
      "No output tax to charge, but no input tax to claim. Registering voluntarily lets you claim input tax and "
      "avoid further tax on sales to you.",
      "Turnover and utility bills within the prescribed limits.",
      "Splitting one business into several to stay under the limit is disregarded under section 109.",
      "st_registration"),
    O("services_province", "Registration", "Register services with the right province", "Provincial sales tax laws",
      "Services are taxed by the province where they are rendered, not by FBR.",
      "Avoids double charging and penalties for wrong registration.", "Check the province's thresholds and rates.",
      "Each province has its own return and due dates.", "provincial_services"),
    # ---------------------------------------------------------------- thresholds
    O("salaried_share", "Income thresholds", "Keep the salaried 75% test in mind", "First Schedule, Div. I, para (1A)",
      "If salary is more than 75% of taxable income, the much lower salaried rates apply to all income.",
      "A small extra non-salary income, rent included, can tip a salaried person onto business rates; dividends and "
      "bank profit within the limit are separate blocks and don't count against the test.",
      "Real employment income; separate-block income is outside the test.",
      "Disguising business receipts as salary from your own company is recharacterised (s.109).", "salaried_test"),
    O("exemption_limit", "Income thresholds", "Use the tax-free limit", "First Schedule, Part I",
      "The first Rs 600,000 of taxable income is at 0%.",
      "Income genuinely belonging to different family members (own salary, own business, own property) is taxed "
      "separately, each with its own tax-free slab.", "Income must really belong to that person.",
      "Income of a minor child from your assets is clubbed with yours (s.90).", "slab_rates"),
    O("surcharge_limit", "Income thresholds", "Watch the surcharge threshold", "Section 4AB",
      "Surcharge applies only when taxable income exceeds Rs 10 million.",
      "Deductions, credits and real timing of income around the threshold can avoid the surcharge.",
      "Timing must follow genuine contracts and accounting.", "", "surcharge"),
    O("pod_limit", "Income thresholds", "Profit on debt within the separate-block limit", "Section 7B",
      "Bank profit within the limit is taxed separately at a fixed rate instead of your top slab.",
      "For high earners the fixed rate can be lower than their marginal rate.", "", "", "profit_on_debt"),
    O("cg_holding", "Income thresholds", "Holding period on older assets", "Sections 37(1A), 37A",
      "Property and shares bought before 1 July 2024 are taxed by holding period, down to 0%.",
      "Selling after the next holding-period step can reduce or remove capital gains tax.",
      "Applies to assets acquired before the cut-off date.", "", "capital_gains"),
    O("co_ownership", "Income thresholds", "Real co-ownership of rented property", "Section 66",
      "Rental income is divided among co-owners in their registered shares.",
      "Each owner's share joins their own income, often in lower slabs.",
      "Ownership registered in each name, bought with each owner's own funds.",
      "Paper transfers without real ownership are disregarded (s.109) and gifts must be shown in wealth statements.",
      "co_ownership", "co_owner"),
    # ---------------------------------------------------------------- expenses and allowances
    O("zakat", "Expenses and allowances", "Deduct Zakat paid", "Section 60",
      "Zakat paid under the Zakat and Ushr Ordinance is deducted from taxable income.",
      "Saves tax at your top slab rate.", "Keep the deduction certificate or receipt.", "",
      "deductible_allowances", "zakat"),
    O("education", "Expenses and allowances", "Education expense allowance", "Section 60D",
      "Fees paid for children's education are partly deductible for taxable income below the limit.",
      "Lower of 5% of fees, 25% of taxable income and the per-child amount.",
      "Taxable income below the limit; NTN of the school on the fee voucher.", "", "deductible_allowances", "education"),
    O("business_expenses", "Expenses and allowances", "Claim every admissible business expense", "Sections 20–23",
      "All real business expenses and tax depreciation reduce business income.",
      "Lower taxable income at business rates (up to 45%).",
      "Wholly and exclusively for business, documented, paid through banking channels above the cash limit, "
      "with tax withheld where required.",
      "Fake or personal expenses are disallowed and penalised; unwithheld payments are disallowed (s.21).",
      "admissible_expenses"),
    O("withhold_properly", "Expenses and allowances", "Withhold tax on payments you make", "Sections 21(c), 161",
      "Deduct and deposit tax on payments to suppliers, contractors and landlords where the law requires.",
      "Keeps the expense deductible and avoids personal liability for the tax.", "", "", "withholding_agent"),
    # ---------------------------------------------------------------- exemptions and immunities
    O("donations", "Exemptions and immunities", "Donations to approved institutions", "Section 61",
      "Donations to approved non-profits earn a tax credit at your average rate.",
      "Credit on up to 30% of taxable income.", "Institution approved under s.2(36); paid by crossed cheque/bank.",
      "", "tax_credits", "donations"),
    O("pension", "Exemptions and immunities", "Voluntary pension contributions", "Section 63",
      "Contributions to an approved pension fund earn a tax credit and build savings.",
      "Credit on up to 20% of taxable income.", "Approved pension fund under the VPS rules.",
      "Early withdrawal is taxed.", "tax_credits", "pension"),
    O("medical_allowance", "Exemptions and immunities", "Structure pay with exempt medical allowance", "Second Schedule, clause (139)",
      "Medical allowance up to 10% of basic salary is exempt where free treatment isn't provided.",
      "Part of the package becomes tax-free.", "Agreed in the employment terms.", "", "exemptions", "medical"),
    O("agriculture", "Exemptions and immunities", "Agricultural income", "Section 41",
      "Agricultural income is exempt from federal income tax.",
      "Taxed by the province instead, often at different rates.",
      "Income genuinely from agricultural land; declare it and keep provincial receipts.",
      "Business income shown as agricultural is a common audit target.", "agricultural_income"),
    O("remittance", "Exemptions and immunities", "Foreign remittance through banks", "Section 111(4)",
      "Money remitted from abroad through banking channels is protected from being treated as unexplained income.",
      "Explains wealth growth safely.", "Encashment certificate; within the law's conditions and limits.", "",
      "foreign_remittance"),
    O("gifts_documented", "Exemptions and immunities", "Document gifts and inheritance", "Section 116",
      "Gifts and inheritance are not income, but must be shown in the wealth statements of both sides.",
      "Explains increases in wealth.", "Gift deed, bank transfer, and the giver's wealth statement showing it.",
      "Undocumented 'gifts' are treated as unexplained income (s.111).", "wealth_reconciliation"),
]

CATEGORIES = ["Registration", "Income thresholds", "Expenses and allowances", "Exemptions and immunities"]
BY_ID = {o.id: o for o in OPTIONS}


@dataclass
class WhatIf:
    before: float
    after: float
    note: str

    @property
    def saving(self) -> float:
        return round(self.before - self.after, 2)


def what_if(ret: dict[str, Any], lever: str, value: float) -> WhatIf:
    """Tax chargeable before and after applying a planning lever to the return."""
    base = merged(ret)
    alt = copy.deepcopy(base)
    note = ""
    if lever == "donations":
        alt["credits"]["donations"] = value
        note = f"Donation of {money(value)} to an approved institution."
    elif lever == "pension":
        alt["credits"]["pension"] = value
        note = f"Pension contribution of {money(value)}."
    elif lever == "zakat":
        alt["deductions"]["zakat"] = value
        note = f"Zakat of {money(value)} deducted."
    elif lever == "education":
        alt["deductions"]["education_fee"] = value
        alt["deductions"]["children"] = max(1, int(alt["deductions"].get("children") or 0))
        note = f"School fees of {money(value)}."
    elif lever == "co_owner":
        alt["property"]["co_owner_share"] = value
        note = (f"You own {value:.0f}% of the property; the co-owner pays tax on the rest separately (their tax is "
                "not included here).")
    elif lever == "medical":
        basic = float(alt["salary"]["basic"] or 0)
        moved = min(value, 0.10 * basic)
        alt["salary"]["allowances"] = max(0.0, float(alt["salary"]["allowances"] or 0) - moved)
        alt["salary"]["medical_allowance"] = float(alt["salary"]["medical_allowance"] or 0) + moved
        note = f"{money(moved)} of taxable allowances paid as medical allowance instead (same total pay)."
    elif lever == "atl":
        alt["taxpayer"]["atl"] = bool(value)
        base["taxpayer"]["atl"] = not bool(value)
        note = "Separate-block taxes at ATL rates instead of non-ATL rates."
    else:
        raise ValueError(f"Unknown lever {lever!r}")
    before = compute(base).figures["tax_chargeable"]
    after = compute(alt).figures["tax_chargeable"]
    return WhatIf(before, after, note)
