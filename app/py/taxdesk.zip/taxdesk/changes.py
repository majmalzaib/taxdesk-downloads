"""Law changes: what changed in each law between last year's consolidated text and the current one.

data/law_text_previous.json.gz holds last year's editions, built from FBR's earlier PDFs by
tools/build_law_text.py --out law_text_previous.json.gz, in the same form as law_text.json.gz (or a newer pair the
owner has published since: see lawdata). Each section, rule,
schedule and division is compared word by word once the differences that come from the PDFs rather than the law are set
aside: amendment brackets and footnote markers (and a footnote number read as a word), quote marks, doubled
punctuation, spacing around dashes and within words ("S.No", "S. No"), a chapter heading caught at a section's end, table
cells read in another order, and a drop capital read apart from its word ("orm" for "Form").
"""
from __future__ import annotations

import difflib
import gzip
import html
import json
import re
from dataclasses import dataclass
from functools import lru_cache

from . import law, lawdata

KINDS = {"new": "New", "changed": "Changed", "omitted": "Omitted"}
_MARK = re.compile("⟦\\d+⟧")
_PUNCT = re.compile(r"^[\W_]*$")


@dataclass(frozen=True)
class Change:
    act: str
    key: str
    kind: str  # new, changed or omitted
    size: int  # words added or removed


@lru_cache(maxsize=1)
def _previous() -> dict:
    try:
        return json.loads(gzip.decompress(lawdata.path("law_text_previous.json.gz").read_bytes()))
    except OSError:
        return {}


def previous(act: str, key: str) -> dict | None:
    """Last year's wording of a section, rule, schedule or division: {"paras", "notes"}, or None."""
    return _previous().get(act, {}).get("sections", {}).get(key)


def previous_source(act: str) -> str:
    return _previous().get(act, {}).get("source", "")


def edition(source: str) -> str:
    """'Income Tax Ordinance 2001, FBR consolidated text amended up to 30 June 2026' -> 'amended up to 30 June 2026'."""
    return source.split("FBR consolidated text", 1)[-1].strip() or source


def _key(word: str) -> str:
    """A word as compared: without quote marks, with one kind of dash and no doubled punctuation."""
    word = word.replace("“", "").replace("”", "").replace('"', "").replace("’", "").replace("‘", "").replace("'", "")
    return re.sub(r"([;:,.])\1+", r"\1", re.sub(r"[―—–‒-]+", "-", word))


def _words(t: dict | None) -> list[str]:
    """The wording as display words, paragraphs separated by "¶"; amendment brackets, footnote markers and chapter
    headings caught at the end are left out."""
    out: list[str] = []
    for p in (t or {}).get("paras", []):
        text = _MARK.sub(" ", p[1]).replace("[", " ").replace("]", " ")
        text = re.sub(r"\s*([―—–‒-])\s*", r"\1", text)  # "sub- section" and "Persons. -" as one word
        text = re.sub(r"\bCHAPTER\b[ \-A-Z]*", " ", text)
        words = [w for w in text.split() if _key(w)]
        if words:
            out += (["¶"] if out else []) + words
    return out


def in_force(t: dict | None) -> bool:
    """Whether a text is the law, not just its number with "Omitted" or "***"."""
    words = [w for w in _words(t)[1:] if w != "¶"]
    return bool(words) and not all(_PUNCT.match(w) or w.strip("[].*").lower() == "omitted" for w in words)


def _noise(old: list[str], new: list[str], at_end: bool = False) -> bool:
    """A difference that comes from reading the PDF, not from the law: the same words in another order (table cells)
    or spaced differently ("S.No", "S. No"), punctuation alone, a drop capital read apart from its word, a footnote
    number read as a word (a lone figure of 100 or more: amounts in the law have commas, rates a %), or, at the end, the
    next chapter's heading in capitals, or anywhere a chapter's title in capitals on its own."""
    old, new = [w for w in old if w != "¶"], [w for w in new if w != "¶"]
    if sorted(map(_key, old)) == sorted(map(_key, new)) or "".join(map(_key, old)) == "".join(map(_key, new)):
        return True
    if all(_PUNCT.match(w) for w in old + new):
        return True
    if len(old) <= 1 and len(new) <= 1 and all(re.fullmatch(r"\d{3,}", w) for w in old + new):
        return True
    if at_end and not new and old and old[0].isupper():
        return True
    if not (old and new) and all(re.fullmatch(r"[A-Z]{4,}", w) for w in old + new):
        return True  # a chapter's title heading the page, as "REGISTRATION"
    return len(old) == len(new) and all(a[1:] == b or b[1:] == a for a, b in zip(old, new))


def _ops(old: list[str], new: list[str]) -> list[tuple[str, int, int, int, int]]:
    """The differences between two texts, noise counted as equal."""
    sm = difflib.SequenceMatcher(None, [_key(w) for w in old], [_key(w) for w in new], autojunk=False)
    return [("equal", i1, i2, j1, j2)
            if tag == "equal" or _noise(old[i1:i2], new[j1:j2], i2 == len(old) and j2 == len(new))
            else (tag, i1, i2, j1, j2) for tag, i1, i2, j1, j2 in sm.get_opcodes()]


@lru_cache(maxsize=None)
def changes(act: str) -> tuple[Change, ...]:
    """Every provision of a law that is new, changed or omitted since last year's edition, in the order of the law."""
    if act not in _previous():
        return ()
    return compare(act, law._texts().get(act, {}).get("sections", {}), _previous()[act]["sections"])


def compare(act: str, now: dict, then: dict) -> tuple[Change, ...]:
    """The provisions new, changed or omitted between two editions' sections ({key: {"paras", "notes"}})."""
    out = []
    for key in dict.fromkeys([*now, *then]):
        n, o = now.get(key), then.get(key)
        if in_force(n) and not in_force(o):
            out.append(Change(act, key, "new", len(_words(n))))
        elif in_force(o) and not in_force(n):
            out.append(Change(act, key, "omitted", len(_words(o))))
        elif in_force(n):
            old, new = _words(o), _words(n)
            if [_key(w) for w in old] == [_key(w) for w in new]:
                continue
            size = sum(i2 - i1 + j2 - j1 for tag, i1, i2, j1, j2 in _ops(old, new) if tag != "equal")
            if size:
                out.append(Change(act, key, "changed", size))
    return tuple(out)


def all_changes() -> list[Change]:
    return [c for act in law.ACTS for c in changes(act)]


def new_notes(act: str, key: str) -> list[str]:
    """The amendment notes in the current text that last year's didn't have: they name the Finance Act or
    notification behind each change."""
    def plain(note: str) -> str:
        return re.sub(r"[^a-z0-9]+", " ", note.lower()).strip()
    old = {plain(n) for n in (previous(act, key) or {}).get("notes", [])}
    return [n for n in (law.text(act, key) or {}).get("notes", []) if plain(n) not in old]


INS = "background:#dcfce7; color:#14532d"
DEL = "background:#fee2e2; color:#7f1d1d; text-decoration:line-through"


def diff_html(act: str, key: str, context: int = 1) -> str:
    """Last year's wording against the current one, as one text with the words removed struck through in red and the
    words added in green. Unchanged paragraphs more than context away from a change are folded away."""
    old, new = _words(previous(act, key)), _words(law.text(act, key))
    paras: list[list[str]] = [[]]
    changed: list[bool] = [False]

    def put(words: list[str], style: str | None) -> None:
        run: list[str] = []

        def close() -> None:
            if run:
                text = html.escape(" ".join(run))
                paras[-1].append(f"<span style='{style}'>{text}</span>" if style else text)
                changed[-1] = changed[-1] or bool(style)
                run.clear()
        for w in words:
            if w == "¶":
                close()
                if style != DEL:  # a paragraph break that was removed leaves the paragraphs joined
                    paras.append([])
                    changed.append(False)
            else:
                run.append(w)
        close()
    for tag, i1, i2, j1, j2 in _ops(old, new):
        if tag == "equal":
            put(new[j1:j2], None)
        else:
            put(old[i1:i2], DEL)
            put(new[j1:j2], INS)
    near = {i for i, c in enumerate(changed) if c}
    keep = {j for i in near for j in range(i - context, i + context + 1)} if near else set(range(len(paras)))
    out, folded = [], 0
    for i, p in enumerate(paras):
        if not p:
            continue
        if i in keep:
            if folded:
                out.append(f"<p style='color:gray'>… {folded} unchanged paragraph{'s' if folded > 1 else ''} …</p>")
                folded = 0
            out.append(f"<p style='margin:0 0 6px 0'>{' '.join(p)}</p>")
        else:
            folded += 1
    if folded:
        out.append(f"<p style='color:gray'>… {folded} unchanged paragraph{'s' if folded > 1 else ''} …</p>")
    return "".join(out)
