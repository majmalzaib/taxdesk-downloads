"""Saved returns and statements, kept as JSON documents in a local SQLite file, with the user's clients and their own
practice points."""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator

KIND_LABELS = {"itr": "Income tax return", "str": "Sales tax return", "wht": "Withholding statement"}


@dataclass
class Document:
    id: int
    kind: str
    title: str
    tax_year: int
    case_id: str
    data: dict[str, Any]
    updated_at: str

    @property
    def kind_label(self) -> str:
        return KIND_LABELS.get(self.kind, self.kind)


class Store:
    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL, tax_year INTEGER NOT NULL,
                case_id TEXT NOT NULL DEFAULT '', data TEXT NOT NULL, updated_at TEXT NOT NULL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS attempts (
                id INTEGER PRIMARY KEY, case_id TEXT NOT NULL, score REAL NOT NULL, taken_at TEXT NOT NULL,
                data TEXT NOT NULL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY, name TEXT NOT NULL, cnic TEXT NOT NULL DEFAULT '', ntn TEXT NOT NULL DEFAULT '',
                strn TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '',
                notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS client_status (
                client_id INTEGER NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL, fbr_name TEXT NOT NULL DEFAULT '',
                since TEXT NOT NULL DEFAULT '', list_date TEXT NOT NULL DEFAULT '', checked_at TEXT NOT NULL,
                PRIMARY KEY (client_id, kind))""")
            have = {r["name"] for r in c.execute("PRAGMA table_info(client_status)")}
            for col in ("fbr_ntn", "business"):  # added after the first release of client checks
                if col not in have:
                    c.execute(f"ALTER TABLE client_status ADD COLUMN {col} TEXT NOT NULL DEFAULT ''")
            c.execute("""CREATE TABLE IF NOT EXISTS status_changes (
                id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL, kind TEXT NOT NULL, old TEXT NOT NULL,
                new TEXT NOT NULL, list_date TEXT NOT NULL, at TEXT NOT NULL, seen INTEGER NOT NULL DEFAULT 0)""")
            c.execute("""CREATE TABLE IF NOT EXISTS practice_points (
                id INTEGER PRIMARY KEY, topic TEXT NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL,
                body TEXT NOT NULL DEFAULT '', law TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL, tested INTEGER NOT NULL DEFAULT 0, knew INTEGER NOT NULL DEFAULT 0,
                last TEXT NOT NULL DEFAULT '')""")
            if "ink" not in {r["name"] for r in c.execute("PRAGMA table_info(practice_points)")}:  # added in 1.8.0
                c.execute("ALTER TABLE practice_points ADD COLUMN ink TEXT NOT NULL DEFAULT ''")

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        """Commit on success and always close: an open connection keeps the file locked on Windows."""
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def list(self, kind: str | None = None) -> list[Document]:
        with self._conn() as c:
            rows = c.execute("SELECT * FROM documents" + (" WHERE kind = ?" if kind else "") +
                             " ORDER BY updated_at DESC", (kind,) if kind else ()).fetchall()
        return [self._doc(r) for r in rows]

    def get(self, doc_id: int) -> Document | None:
        with self._conn() as c:
            row = c.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
        return self._doc(row) if row else None

    def save(self, data: dict[str, Any], title: str, doc_id: int | None = None, case_id: str = "") -> int:
        now = datetime.now().isoformat(timespec="seconds")
        blob = json.dumps(data)
        with self._conn() as c:
            if doc_id:
                c.execute("UPDATE documents SET title = ?, tax_year = ?, data = ?, updated_at = ? WHERE id = ?",
                          (title, int(data.get("tax_year", 2025)), blob, now, doc_id))
                return doc_id
            cur = c.execute("INSERT INTO documents (kind, title, tax_year, case_id, data, updated_at) "
                            "VALUES (?, ?, ?, ?, ?, ?)",
                            (data.get("kind", "itr"), title, int(data.get("tax_year", 2025)), case_id, blob, now))
            return int(cur.lastrowid)

    def delete(self, ids: list[int]) -> None:
        with self._conn() as c:
            c.executemany("DELETE FROM documents WHERE id = ?", [(i,) for i in ids])

    def for_case(self, case_id: str) -> Document | None:
        with self._conn() as c:
            row = c.execute("SELECT * FROM documents WHERE case_id = ? ORDER BY updated_at DESC LIMIT 1",
                            (case_id,)).fetchone()
        return self._doc(row) if row else None

    # ---------------------------------------------------------------- mock-return attempts
    def add_attempt(self, marked: dict[str, Any]) -> int:
        """Keep a marked mock return (exam.Marked.to_dict())."""
        with self._conn() as c:
            cur = c.execute("INSERT INTO attempts (case_id, score, taken_at, data) VALUES (?, ?, ?, ?)",
                            (marked["case_id"], marked["score"], marked["taken_at"], json.dumps(marked)))
            return int(cur.lastrowid)

    def attempts(self, case_id: str | None = None) -> list[tuple[int, dict[str, Any]]]:
        """[(id, marked dict)], newest first."""
        with self._conn() as c:
            rows = c.execute("SELECT id, data FROM attempts" + (" WHERE case_id = ?" if case_id else "") +
                             " ORDER BY taken_at DESC, id DESC", (case_id,) if case_id else ()).fetchall()
        return [(r["id"], json.loads(r["data"])) for r in rows]

    def delete_attempts(self, ids: list[int]) -> None:
        with self._conn() as c:
            c.executemany("DELETE FROM attempts WHERE id = ?", [(i,) for i in ids])

    # ---------------------------------------------------------------- the user's own practice points
    # For each practice guide topic: notes to read (kind "note": title and body) and cards to test their understanding
    # (kind "card": a question as title, its answer as body), each with the law it rests on. A note may also be written
    # by hand: its ink (views.ink's JSON). A card keeps how often it was tested, how often the user knew it, and the
    # last result ("knew" or "again").
    POINT_FIELDS = ("topic", "kind", "title", "body", "law", "ink")

    def points(self, topic: str | None = None, kind: str | None = None) -> list[dict[str, Any]]:
        """Points, oldest first."""
        where = [w for w, v in (("topic = ?", topic), ("kind = ?", kind)) if v]
        with self._conn() as c:
            rows = c.execute("SELECT * FROM practice_points" + (" WHERE " + " AND ".join(where) if where else "")
                             + " ORDER BY id", [v for v in (topic, kind) if v]).fetchall()
        return [dict(r) for r in rows]

    def save_point(self, data: dict[str, Any], point_id: int | None = None) -> int:
        now = datetime.now().isoformat(timespec="seconds")
        values = [str(data.get(f, "")).strip() for f in self.POINT_FIELDS]
        with self._conn() as c:
            if point_id:
                c.execute(f"UPDATE practice_points SET {', '.join(f + ' = ?' for f in self.POINT_FIELDS)}, "
                          "updated_at = ? WHERE id = ?", [*values, now, point_id])
                return point_id
            cur = c.execute(f"INSERT INTO practice_points ({', '.join(self.POINT_FIELDS)}, created_at, updated_at) "
                            f"VALUES ({', '.join('?' * len(self.POINT_FIELDS))}, ?, ?)", [*values, now, now])
            return int(cur.lastrowid)

    def delete_point(self, point_id: int) -> None:
        with self._conn() as c:
            c.execute("DELETE FROM practice_points WHERE id = ?", (point_id,))

    def record_test(self, point_id: int, knew: bool) -> None:
        with self._conn() as c:
            c.execute("UPDATE practice_points SET tested = tested + 1, knew = knew + ?, last = ? WHERE id = ?",
                      (int(knew), "knew" if knew else "again", point_id))

    # ---------------------------------------------------------------- clients and their FBR status
    CLIENT_FIELDS = ("name", "cnic", "ntn", "strn", "phone", "email", "notes")

    def clients(self) -> list[dict[str, Any]]:
        """Every client with its latest income tax (it_*) and sales tax (st_*) status."""
        with self._conn() as c:
            rows = [dict(r) for r in c.execute("SELECT * FROM clients ORDER BY name COLLATE NOCASE")]
            status = c.execute("SELECT * FROM client_status").fetchall()
        by_id = {r["id"]: r for r in rows}
        for r in rows:
            for k in ("it", "st"):
                r.update({f"{k}_{f}": "" for f in ("status", "name", "since", "list", "checked", "ntn", "business")})
        for s in status:
            r = by_id.get(s["client_id"])
            if r:
                k = s["kind"].lower()
                r.update({f"{k}_status": s["status"], f"{k}_name": s["fbr_name"], f"{k}_since": s["since"],
                          f"{k}_list": s["list_date"], f"{k}_checked": s["checked_at"], f"{k}_ntn": s["fbr_ntn"],
                          f"{k}_business": s["business"]})
        return rows

    def save_client(self, data: dict[str, Any], client_id: int | None = None) -> int:
        values = [str(data.get(f) or "").strip() for f in self.CLIENT_FIELDS]
        with self._conn() as c:
            if client_id:
                c.execute("UPDATE clients SET " + ", ".join(f"{f} = ?" for f in self.CLIENT_FIELDS) + " WHERE id = ?",
                          (*values, client_id))
                c.execute("DELETE FROM client_status WHERE client_id = ?", (client_id,))  # identifiers may have changed
                return client_id
            cur = c.execute("INSERT INTO clients (" + ", ".join(self.CLIENT_FIELDS) + ", created_at) VALUES ("
                            + ", ".join("?" * (len(self.CLIENT_FIELDS) + 1)) + ")",
                            (*values, datetime.now().isoformat(timespec="seconds")))
            return int(cur.lastrowid)

    def delete_clients(self, ids: list[int]) -> None:
        with self._conn() as c:
            for table, col in (("clients", "id"), ("client_status", "client_id"), ("status_changes", "client_id")):
                c.executemany(f"DELETE FROM {table} WHERE {col} = ?", [(i,) for i in ids])

    def record_status(self, kind: str, results: dict[int, tuple[str, ...]], list_date: str) -> list[dict[str, Any]]:
        """Store each client's status on one list ({client id: (status, name, NTN, business name on the list)})
        and return the changes from the previous check, which are also kept for the alerts. A client with no NTN
        on file gets the NTN the list shows."""
        now = datetime.now().isoformat(timespec="seconds")
        changes = []
        with self._conn() as c:
            old = {r["client_id"]: r for r in c.execute("SELECT * FROM client_status WHERE kind = ?", (kind,))}
            for cid, (status, fbr_name, *more) in results.items():
                fbr_ntn, business = (list(more) + ["", ""])[:2]
                prev = old.get(cid)
                since = prev["since"] if prev and prev["status"] == status else list_date
                if prev and prev["status"] != status:
                    c.execute("INSERT INTO status_changes (client_id, kind, old, new, list_date, at) "
                              "VALUES (?, ?, ?, ?, ?, ?)", (cid, kind, prev["status"], status, list_date, now))
                    changes.append({"client_id": cid, "kind": kind, "old": prev["status"], "new": status,
                                    "list_date": list_date})
                c.execute("INSERT OR REPLACE INTO client_status (client_id, kind, status, fbr_name, since, list_date, "
                          "checked_at, fbr_ntn, business) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                          (cid, kind, status, fbr_name, since, list_date, now, fbr_ntn, business))
                if fbr_ntn:
                    c.execute("UPDATE clients SET ntn = ? WHERE id = ? AND ntn = ''", (fbr_ntn, cid))
        return changes

    def status_changes(self, unseen_only: bool = False) -> list[dict[str, Any]]:
        with self._conn() as c:
            rows = c.execute("SELECT s.*, c.name FROM status_changes s JOIN clients c ON c.id = s.client_id"
                             + (" WHERE s.seen = 0" if unseen_only else "") + " ORDER BY s.at DESC, s.id DESC").fetchall()
        return [dict(r) for r in rows]

    def mark_changes_seen(self) -> None:
        with self._conn() as c:
            c.execute("UPDATE status_changes SET seen = 1")

    @staticmethod
    def _doc(r: sqlite3.Row) -> Document:
        return Document(r["id"], r["kind"], r["title"], r["tax_year"], r["case_id"], json.loads(r["data"]),
                        r["updated_at"])
