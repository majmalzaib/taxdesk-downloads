"""Writing simple Excel workbooks (.xlsx) without extra packages: the client upload template and status exports.

Each sheet has a bold header row frozen at the top, column widths, and optionally columns kept as text (so Excel
leaves CNICs and NTNs alone instead of turning them into numbers like 3.52E+12) with a length check on entry.
"""
from __future__ import annotations

import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from xml.sax.saxutils import escape


@dataclass
class Sheet:
    name: str
    headers: list[str]
    rows: list[list[object]] = field(default_factory=list)
    widths: list[float] = field(default_factory=list)
    text_columns: tuple[int, ...] = ()  # 0-based columns formatted as text, including rows not yet typed
    length_check: dict[int, tuple[int, int, str]] = field(default_factory=dict)  # col → (min, max, message)
    wrap: bool = False  # wrap long text (for an instructions sheet)


def _col(i: int) -> str:
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


# style ids in STYLES below: 0 normal, 1 header, 2 text, 3 wrapped text
STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts>
<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF0F766E"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="4">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="49" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyNumberFormat="1"/>
<xf numFmtId="49" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""


def _sheet_xml(sh: Sheet) -> str:
    n = len(sh.headers)
    cols = "".join(
        f'<col min="{i + 1}" max="{i + 1}" width="{sh.widths[i] if i < len(sh.widths) else 18}" customWidth="1"'
        + (' style="2"' if i in sh.text_columns else ' style="3"' if sh.wrap else "") + "/>" for i in range(n))

    def cell(r: int, c: int, v: object, style: int) -> str:
        ref = f"{_col(c)}{r}"
        st = f' s="{style}"' if style else ""
        if v is None or v == "":
            return f'<c r="{ref}"{st}/>' if style else ""
        if isinstance(v, (int, float)) and not isinstance(v, bool) and c not in sh.text_columns:
            return f'<c r="{ref}"{st}><v>{v}</v></c>'
        return f'<c r="{ref}" t="inlineStr"{st}><is><t xml:space="preserve">{escape(str(v))}</t></is></c>'
    rows = ['<row r="1">' + "".join(cell(1, c, h, 1) for c, h in enumerate(sh.headers)) + "</row>"]
    for r, values in enumerate(sh.rows, start=2):
        rows.append(f'<row r="{r}">' + "".join(
            cell(r, c, v, 2 if c in sh.text_columns else 3 if sh.wrap else 0) for c, v in enumerate(values)) + "</row>")
    checks = "".join(
        f'<dataValidation type="textLength" operator="between" allowBlank="1" showErrorMessage="1" '
        f'errorTitle="Check the value" error="{escape(msg)}" sqref="{_col(c)}2:{_col(c)}5000">'
        f"<formula1>{lo}</formula1><formula2>{hi}</formula2></dataValidation>"
        for c, (lo, hi, msg) in sh.length_check.items())
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<sheetViews><sheetView workbookViewId="0">'
            + ('<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>' if not sh.wrap else "")
            + f"</sheetView></sheetViews><cols>{cols}</cols><sheetData>{''.join(rows)}</sheetData>"
            + (f'<dataValidations count="{len(sh.length_check)}">{checks}</dataValidations>' if checks else "")
            + "</worksheet>")


def write(path: Path | str, sheets: list[Sheet]) -> Path:
    """Write a workbook; the first sheet is the one TaxDesk reads back on upload."""
    path = Path(path)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" '
                   'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/styles.xml" '
                   'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                   + "".join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" '
                             'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                             for i in range(1, len(sheets) + 1)) + "</Types>")
        z.writestr("_rels/.rels",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/'
                   'officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                   'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
                   + "".join(f'<sheet name="{escape(s.name[:31])}" sheetId="{i}" r:id="rId{i}"/>'
                             for i, s in enumerate(sheets, start=1)) + "</sheets></workbook>")
        z.writestr("xl/_rels/workbook.xml.rels",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + "".join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                             f'relationships/worksheet" Target="worksheets/sheet{i}.xml"/>'
                             for i in range(1, len(sheets) + 1))
                   + f'<Relationship Id="rId{len(sheets) + 1}" Type="http://schemas.openxmlformats.org/officeDocument/'
                     '2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr("xl/styles.xml", STYLES)
        for i, s in enumerate(sheets, start=1):
            z.writestr(f"xl/worksheets/sheet{i}.xml", _sheet_xml(s))
    return path
