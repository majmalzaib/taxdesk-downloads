"""Mock returns: a practice case filed like an exam, with no hints, then marked line by line against the model return.

Every mistake carries the section that decides it and the concept that explains it, so the marked script links
straight into the law. Attempts are kept (see Store.add_attempt) to show progress by topic, and a result sheet can be
printed for each attempt.
"""
from __future__ import annotations

import hashlib
import html
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any

from . import cases as cases_mod
from . import knowledge, law
from .rules import money

ENTRY_PENALTY = 5  # marks lost for each entry that differs from the model return
GRADES = ((90, "Distinction"), (70, "Merit"), (50, "Pass"), (0, "Not yet"))

# figure checked → (the law that decides it, the concept that explains it)
RESULT_LAW: dict[str, tuple[str, str]] = {
    "salary": ("Section 12", "salary_income"),
    "business": ("Sections 18, 20 and 21", "business_income"),
    "taxable_income": ("Section 9", "taxable_income"),
    "tax_on_income": ("First Schedule, Part I, Division I", "slab_rates"),
    "tax_chargeable": ("Section 4", "tax_chargeable"),
    "tax_paid": ("Section 168", "adjustable_tax"),
    "balance": ("Sections 137 and 170", "tax_payable_refund"),
    "property": ("Sections 15 and 15A", "property_income"),
    "surcharge": ("Section 4AB", "surcharge"),
    "credits": ("Sections 61 and 63", "tax_credits"),
    "cg_tax": ("Sections 37 and 37A", "capital_gains"),
    "pod_tax": ("Section 7B", "profit_on_debt"),
    "dividend_tax": ("Section 5", "dividend"),
    "unreconciled": ("Section 116(2); section 111", "wealth_reconciliation"),
    "expected": ("Sections 153 and 165", "withholding_statement"),
    "output": ("Section 3", "output_tax"),
    "further": ("Section 3(1A)", "further_tax"),
    "input_adjusted": ("Sections 7, 8 and 8B", "input_cap"),
    "carry_forward": ("Section 10", "carry_forward"),
    "payable": ("Sections 6 and 26", "st_payable"),
}
# entry path prefix → (law, concept); the first match wins, so specific paths come first
ENTRY_LAW: list[tuple[str, str, str]] = [
    ("salary.medical_allowance", "Second Schedule, Part I, clause (139)", "exemptions"),
    ("salary.perquisites", "Section 13", "perquisites"),
    ("salary", "Section 12", "salary_income"),
    ("business.inadmissible", "Section 21", "inadmissible_expenses"),
    ("business.depreciation", "Sections 22 and 23", "depreciation"),
    ("business", "Sections 18 and 20", "business_income"),
    ("property.co_owner_share", "Section 66", "co_ownership"),
    ("property", "Sections 15, 15A and 16", "property_adjustments"),
    ("capital_gains", "Sections 37 and 37A", "capital_gains"),
    ("other_sources.profit_on_debt", "Section 7B", "profit_on_debt"),
    ("other_sources.dividend", "Section 5", "dividend"),
    ("other_sources", "Section 39", "other_sources"),
    ("exempt_income", "Section 41", "agricultural_income"),
    ("deductions", "Sections 60 and 60D", "deductible_allowances"),
    ("credits", "Sections 61 and 63", "tax_credits"),
    ("withholding", "Section 168", "adjustable_tax"),
    ("wealth.inflows", "Section 116(2)", "wealth_reconciliation"),
    ("wealth.outflows", "Section 116(2)", "personal_expenses"),
    ("wealth", "Section 116", "wealth_statement"),
    ("sales", "Section 3", "output_tax"),
    ("purchases", "Sections 7 and 8", "input_tax"),
    ("carry_forward_in", "Section 10", "carry_forward"),
    ("rows", "Section 153", "withholding_agent"),
]


@dataclass
class Item:
    kind: str  # result | entry
    label: str
    ok: bool
    yours: Any
    correct: Any
    hint: str = ""
    law: str = ""
    concept: str = ""


@dataclass
class Marked:
    case_id: str
    items: list[Item]
    seconds: int
    score: float = 0.0
    taken_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    @property
    def grade(self) -> str:
        return next(name for floor, name in GRADES if self.score >= floor)

    @property
    def time_text(self) -> str:
        m, s = divmod(int(self.seconds), 60)
        return f"{m} min {s:02d} s" if m < 60 else f"{m // 60} h {m % 60:02d} min"

    @property
    def results(self) -> list[Item]:
        return [i for i in self.items if i.kind == "result"]

    @property
    def wrong_entries(self) -> list[Item]:
        return [i for i in self.items if i.kind == "entry" and not i.ok]

    def to_dict(self) -> dict:
        return {"case_id": self.case_id, "seconds": self.seconds, "score": self.score, "taken_at": self.taken_at,
                "items": [asdict(i) for i in self.items]}

    @classmethod
    def from_dict(cls, d: dict) -> "Marked":
        return cls(d["case_id"], [Item(**i) for i in d.get("items", [])], int(d.get("seconds", 0)),
                   float(d.get("score", 0)), d.get("taken_at", ""))


def _entry_law(path: str) -> tuple[str, str]:
    for prefix, text, concept in ENTRY_LAW:
        if path.startswith(prefix):
            return text, concept
    return "", ""


def mark(case: cases_mod.Case, doc: dict, seconds: int) -> Marked:
    """Mark a mock return. Results share 100 marks equally; each entry that differs from the model return costs
    ENTRY_PENALTY marks. Every item carries its law and concept."""
    items: list[Item] = []
    keys = {label: key for key, label in case.checks}
    for f in cases_mod.check(case, doc):
        if f.label.startswith("Entry: "):
            path = f.label[len("Entry: "):]
            text, concept = _entry_law(path)
            items.append(Item("entry", f"Entry: {path}", f.ok, f.yours, f.correct, f.hint, text, concept))
        elif f.label in keys:
            text, concept = RESULT_LAW.get(keys[f.label], ("", ""))
            items.append(Item("result", f.label, f.ok, f.yours, f.correct, f.hint, text, concept))
        else:  # a withholding payee line: "Steel Traders: tax to deduct (s.153(1)(a))"
            ref = law.first_ref(f.label)
            items.append(Item("result", f.label, f.ok, f.yours, f.correct, f.hint,
                              f"Section {ref[1]}" if ref else "Section 153", "withholding_agent"))
    results = [i for i in items if i.kind == "result"]
    share = 100 / len(results) if results else 0
    score = sum(share for i in results if i.ok) - ENTRY_PENALTY * sum(1 for i in items if i.kind == "entry")
    return Marked(case.id, items, int(seconds), round(max(0.0, min(100.0, score)), 1))


# ---------------------------------------------------------------- progress
def progress(attempts: list[Marked]) -> dict[str, dict]:
    """Best score per case, and the average of best scores per topic (the areas of the concepts each case practises)."""
    best: dict[str, Marked] = {}
    count: dict[str, int] = {}
    for a in attempts:
        count[a.case_id] = count.get(a.case_id, 0) + 1
        if a.case_id not in best or a.score > best[a.case_id].score:
            best[a.case_id] = a
    topics: dict[str, list[float]] = {}
    for cid, a in best.items():
        case = cases_mod.BY_ID.get(cid)
        if not case:
            continue
        for area in {knowledge.BY_ID[c].area for c in case.concepts if c in knowledge.BY_ID}:
            topics.setdefault(area, []).append(a.score)
    return {"cases": {cid: {"best": a.score, "grade": a.grade, "attempts": count[cid]} for cid, a in best.items()},
            "topics": {t: round(sum(v) / len(v), 1) for t, v in sorted(topics.items())}}


def weakest_concepts(attempts: list[Marked], limit: int = 5) -> list[tuple[str, int]]:
    """Concepts behind the most mistakes, most frequent first."""
    tally: dict[str, int] = {}
    for a in attempts:
        for i in a.items:
            if not i.ok and i.concept:
                tally[i.concept] = tally.get(i.concept, 0) + 1
    return sorted(tally.items(), key=lambda kv: -kv[1])[:limit]


# ---------------------------------------------------------------- result sheet
def reference(name: str, marked: Marked) -> str:
    """A short reference code for a result sheet, so a copy can be matched against the attempt it came from."""
    raw = f"{name}|{marked.case_id}|{marked.score}|{marked.seconds}|{marked.taken_at}"
    return hashlib.sha256(raw.encode()).hexdigest()[:12].upper()


def result_sheet_html(case: cases_mod.Case, marked: Marked, name: str) -> str:
    """A printable result sheet: who, which case, score and grade, and every item with its law."""
    act = "STA" if case.kind == "str" else "ITO"
    when = marked.taken_at.replace("T", " ")
    rows = "".join(
        f"<tr><td>{'✓' if i.ok else '✗'}</td><td>{html.escape(i.label)}</td>"
        f"<td align='right'>{html.escape(_fmt(i.yours))}</td><td align='right'>{html.escape(_fmt(i.correct))}</td>"
        f"<td>{html.escape(law.cite_text(i.law, act))}</td></tr>" for i in marked.items)
    return (
        "<div style='font-family:sans-serif; font-size:11pt'>"
        "<h1 style='margin-bottom:0'>TaxDesk · Mock return result</h1>"
        f"<p style='color:gray; margin-top:2px'>IRIS-style practice under the {law.ACTS[act]}</p>"
        f"<table cellpadding=4><tr><td><b>Candidate</b></td><td>{html.escape(name or '—')}</td></tr>"
        f"<tr><td><b>Case</b></td><td>{html.escape(case.title)} ({case.level}, Tax Year {case.tax_year})</td></tr>"
        f"<tr><td><b>Date</b></td><td>{when}</td></tr><tr><td><b>Time taken</b></td><td>{marked.time_text}</td></tr>"
        f"<tr><td><b>Score</b></td><td><b>{marked.score:.0f}%</b> · {marked.grade}</td></tr>"
        f"<tr><td><b>Reference</b></td><td>{reference(name, marked)}</td></tr></table>"
        "<h3>Marked items</h3><table border=1 cellspacing=0 cellpadding=4 width='100%'>"
        "<tr><th></th><th>Item</th><th>Yours</th><th>Correct</th><th>Law</th></tr>"
        f"{rows}</table>"
        f"<p style='color:gray; font-size:9pt'>Results share 100 marks equally; each entry that differs from the model "
        f"return costs {ENTRY_PENALTY} marks. A practice result from TaxDesk, not an FBR document or a professional "
        "qualification.</p></div>")


def _fmt(v: Any) -> str:
    if v is None:
        return "—"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return money(v)
    return str(v)
