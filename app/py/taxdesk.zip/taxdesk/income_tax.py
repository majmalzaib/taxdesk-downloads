"""Income tax return of an individual, computed head by head the way the return is built.

Every figure is recorded as a Step with the law it comes from and a plain explanation, so the
computation can be read like a worked solution. Concept ids link each step to the concept library.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
from datetime import date
from typing import Any

from .rules import Rules, load, money

HEADS = ("salary", "property", "business", "capital_gains", "other_sources")


def blank_return(year: int) -> dict[str, Any]:
    return {
        "kind": "itr", "tax_year": year,
        "taxpayer": {"name": "", "cnic": "", "atl": True, "age": 35, "resident": True},
        "salary": {"basic": 0, "allowances": 0, "medical_allowance": 0, "perquisites": 0, "other_exempt": 0},
        "property": {"rent_received": 0, "non_adjustable": 0, "co_owner_share": 100, "insurance": 0, "local_taxes": 0,
                     "interest": 0, "collection_charges": 0, "other_deductions": 0},
        "business": {"turnover": 0, "cost_of_sales": 0, "expenses": 0, "inadmissible": 0, "depreciation": 0},
        "capital_gains": [],  # {"asset": "property"/"securities", "kind", "acquired", "disposed", "cost", "sale"}
        "other_sources": {"profit_on_debt": 0, "dividend": 0, "dividend_kind": "general", "other": 0},
        "exempt_income": {"agricultural": 0, "other": 0},
        "deductions": {"zakat": 0, "education_fee": 0, "children": 0},
        "credits": {"donations": 0, "pension": 0},
        "withholding": [],  # {"section", "amount", "agent", "certificate"}
        "wealth": {"assets": {}, "liabilities": {}, "inflows": {}, "outflows": {}},
    }


def merged(ret: dict[str, Any]) -> dict[str, Any]:
    """The return with any missing parts filled with blanks, so older or partial returns still compute."""
    out = blank_return(int(ret.get("tax_year") or 2025))
    for key, value in ret.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key].update(value)
        else:
            out[key] = copy.deepcopy(value)
    return out


@dataclass
class Step:
    part: str  # e.g. "Salary", "Tax chargeable"
    label: str
    amount: float
    law: str = ""
    note: str = ""
    concept: str = ""
    total: bool = False


@dataclass
class Result:
    year: int
    steps: list[Step] = field(default_factory=list)
    figures: dict[str, float] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

    def add(self, part: str, label: str, amount: float, law: str = "", note: str = "", concept: str = "",
            total: bool = False, key: str = "") -> float:
        amount = round(float(amount), 2)
        self.steps.append(Step(part, label, amount, law, note, concept, total))
        if key:
            self.figures[key] = amount
        return amount

    def part(self, name: str) -> list[Step]:
        return [s for s in self.steps if s.part == name]


def _n(v: Any) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _date(v: Any) -> date | None:
    if isinstance(v, date):
        return v
    try:
        return date.fromisoformat(str(v))
    except ValueError:
        return None


def compute(ret: dict[str, Any], rules: Rules | None = None) -> Result:
    ret = merged(ret)
    rules = rules or load(int(ret["tax_year"]))
    r = Result(rules.year)
    tp = ret["taxpayer"]
    atl = bool(tp.get("atl", True))

    # ---------------------------------------------------------------- salary (s.12)
    sal = ret["salary"]
    basic = _n(sal["basic"])
    medical = _n(sal["medical_allowance"])
    med_limit = rules["medical_exempt_share"]["value"] * basic
    med_exempt = min(medical, med_limit)
    gross_salary = basic + _n(sal["allowances"]) + medical + _n(sal["perquisites"])
    salary_exempt = med_exempt + _n(sal["other_exempt"])
    if gross_salary:
        r.add("Salary", "Basic salary", basic, "Section 12(2)(a)", concept="salary_income")
        r.add("Salary", "Allowances", _n(sal["allowances"]), "Section 12(2)(b)", concept="salary_income")
        r.add("Salary", "Medical allowance", medical, "Section 12(2)(b)", concept="salary_income")
        r.add("Salary", "Perquisites (car, accommodation, etc.)", _n(sal["perquisites"]), "Section 13; rules 3–5",
              "Benefits provided by the employer are valued under section 13 and are part of salary.", "perquisites")
        r.add("Salary", "Less: exempt medical allowance", -med_exempt, rules["medical_exempt_share"]["law"],
              f"Medical allowance is exempt up to {rules['medical_exempt_share']['value']:.0%} of basic salary "
              f"({money(med_limit)}) where free treatment is not provided. Exempt: {money(med_exempt)}.",
              "exemptions")
        if _n(sal["other_exempt"]):
            r.add("Salary", "Less: other exempt amounts", -_n(sal["other_exempt"]), "Second Schedule",
                  concept="exemptions")
    salary = r.add("Salary", "Income from salary", gross_salary - salary_exempt, "Section 12", total=True,
                   key="salary", concept="salary_income")

    # ---------------------------------------------------------------- property (s.15, 15A, 16)
    prop = ret["property"]
    pr = rules["property_income"]
    own = _n(prop.get("co_owner_share", 100)) / 100
    rent_year = _n(prop["rent_received"])
    advance = _n(prop.get("non_adjustable")) / pr["non_adjustable_years"]
    property_income, rent = 0.0, 0.0
    if rent_year or advance:
        rent = r.add("Property", "Rent chargeable", (rent_year + advance) * own, "Section 15",
                     (f"Rent {money(rent_year)}" + (f" + one-tenth of the non-adjustable amount, {money(advance)} "
                                                   "(section 16)" if advance else "")
                      + (f", × your {own:.0%} share (section 66)" if own != 1 else "") + "."),
                     "property_income")
        repairs = r.add("Property", "Less: repairs allowance (one-fifth of rent)", -rent * pr["repairs_share"],
                        "Section 15A(1)(a)", "A fixed allowance in place of actual repairs.", "property_adjustments")
        collection = min(_n(prop.get("collection_charges")) * own, rent * pr["collection_share"])
        deductions = [("Insurance of the building", "insurance", "Section 15A(1)(b)"),
                      ("Property tax and local rates", "local_taxes", "Section 15A(1)(c)"),
                      ("Profit on money borrowed for the property", "interest", "Section 15A(1)(e) and (g)"),
                      ("Ground rent, legal costs and irrecoverable rent", "other_deductions", "Section 15A(1)(d), (i), (j)")]
        other = 0.0
        for label, key, law in deductions:
            if _n(prop.get(key)):
                other += -r.add("Property", f"Less: {label.lower()}", -_n(prop[key]) * own, law,
                                concept="property_adjustments")
        if _n(prop.get("collection_charges")):
            r.add("Property", "Less: administration and collection charges", -collection, "Section 15A(1)(h)",
                  f"Allowed up to {pr['collection_share']:.0%} of rent ({money(rent * pr['collection_share'])}).",
                  "property_adjustments")
        property_income = rent + repairs - other - collection
        r.add("Property", "Income from property", property_income, "Section 15", total=True, concept="property_income")
    r.figures["property"] = round(property_income, 2)

    # ---------------------------------------------------------------- business (s.18)
    bus = ret["business"]
    turnover = _n(bus["turnover"])
    business = 0.0
    if turnover or _n(bus["expenses"]):
        gross_profit = r.add("Business", "Gross profit (turnover − cost of sales)", turnover - _n(bus["cost_of_sales"]),
                             "Section 18", concept="business_income")
        admissible = _n(bus["expenses"]) - _n(bus["inadmissible"])
        r.add("Business", "Less: admissible expenses", -admissible, "Section 20",
              "Expenses incurred wholly and exclusively for the business are deductible.", "admissible_expenses")
        if _n(bus["inadmissible"]):
            r.add("Business", "Inadmissible expenses added back (shown for reference)", _n(bus["inadmissible"]),
                  "Section 21", "Personal expenses, cash payments above the limit, payments without required "
                  "withholding, etc. are not deductible, so they stay in income.", "inadmissible_expenses")
        r.add("Business", "Less: tax depreciation", -_n(bus["depreciation"]), "Sections 22–23; rule 12", concept="depreciation")
        business = gross_profit - admissible - _n(bus["depreciation"])
        if business < 0:
            r.add("Business", "Business loss carried forward", business, "Sections 56–57",
                  "A business loss can't be set off against salary or property income. It is carried forward "
                  "for up to six tax years against business income.", "loss_setoff")
            r.warnings.append(f"Business loss of {money(-business)} is carried forward, not set off.")
            business = 0.0
        r.add("Business", "Income from business", business, "Section 18", total=True, concept="business_income")
    r.figures["business"] = round(business, 2)

    # ---------------------------------------------------------------- other sources (s.39) and profit on debt (s.7B)
    oth = ret["other_sources"]
    pod = _n(oth["profit_on_debt"])
    pod_rules = rules["profit_on_debt"]
    pod_separate = pod if pod <= pod_rules["limit"] else 0.0
    other_normal = _n(oth["other"]) + (pod - pod_separate)
    if pod > pod_rules["limit"]:
        r.warnings.append(f"Profit on debt above {money(pod_rules['limit'])} is taxed with normal income here.")
    if other_normal:
        r.add("Other sources", "Other income taxed at normal rates", other_normal, "Section 39",
              concept="other_sources", key="other_normal")
    r.figures.setdefault("other_normal", 0.0)

    # ---------------------------------------------------------------- total income and deductible allowances
    if property_income < 0:  # a property loss: against business and other sources, never salary (s.56)
        used = min(-property_income, business + other_normal)
        if used < -property_income:
            r.warnings.append(f"Property loss of {money(-property_income - used)} can't be set off against salary and "
                              "lapses (section 56).")
        r.add("Taxable income", "Property loss set off against business and other income", -used, "Section 56",
              concept="loss_setoff")
        property_income = 0.0
        business_and_other = business + other_normal - used
    else:
        business_and_other = business + other_normal
    total_income = r.add("Taxable income", "Total income under normal tax regime",
                         salary + property_income + business_and_other, "Section 10",
                         "Income under salary, property, business and other sources is added together and taxed at "
                         "the slab rates.", "normal_tax_regime", key="total_income")
    zakat = min(_n(ret["deductions"]["zakat"]), total_income)
    if zakat:
        r.add("Taxable income", "Less: Zakat paid", -zakat, rules["deductions"]["zakat"]["law"],
              "Zakat paid under the Zakat and Ushr Ordinance is deducted from taxable income.", "deductible_allowances")
    edu_rules = rules["deductions"]["education"]
    edu = 0.0
    fee, kids = _n(ret["deductions"]["education_fee"]), int(_n(ret["deductions"]["children"]))
    if fee:
        base = total_income - zakat
        if base < edu_rules["income_limit"]:
            edu = min(fee * edu_rules["fee_share"], base * edu_rules["income_share"], edu_rules["per_child"] * kids)
            r.add("Taxable income", "Less: education expense allowance", -edu, edu_rules["law"],
                  f"Lower of {edu_rules['fee_share']:.0%} of fees, {edu_rules['income_share']:.0%} of taxable income "
                  f"and {money(edu_rules['per_child'])} per child.", "deductible_allowances")
        else:
            r.add("Taxable income", "Education allowance not available", 0, edu_rules["law"],
                  f"Only for taxable income below {money(edu_rules['income_limit'])}.", "deductible_allowances")
    taxable = r.add("Taxable income", "Taxable income (normal regime)", max(0.0, total_income - zakat - edu),
                    "Section 9", total=True, key="taxable_income", concept="taxable_income")

    # ---------------------------------------------------------------- which slab table
    share = rules["salaried_share"]["value"]
    salaried = taxable > 0 and salary > share * taxable
    table = "salaried" if salaried else "non_salaried"
    r.figures["salaried"] = 1.0 if salaried else 0.0
    r.add("Tax on income", f"Rate table: {'salaried' if salaried else 'non-salaried'} individual", 0,
          rules["salaried_share"]["law"],
          (f"Salary is {salary / taxable:.0%} of taxable income; the salaried table applies only when salary "
           f"is more than {share:.0%}." if taxable else "No taxable income."), "salaried_test")

    slab = rules.slab(table, taxable)
    tax_normal = r.add("Tax on income", "Tax on taxable income", slab.tax, rules["slabs"][table]["law"],
                       slab.explain(taxable), "slab_rates", key="tax_on_income")

    sc = rules["senior_citizen"]
    if int(_n(tp.get("age"))) >= sc["age"] and taxable <= sc["income_limit"] and tax_normal:
        cut = tax_normal * sc["reduction"]
        tax_normal = r.add("Tax on income", "Less: senior citizen reduction", -cut, sc["law"],
                           f"Aged {sc['age']}+ with taxable income up to {money(sc['income_limit'])}: tax reduced by "
                           f"{sc['reduction']:.0%}.", "tax_reductions") + tax_normal

    # ---------------------------------------------------------------- tax credits (average rate)
    avg = tax_normal / taxable if taxable else 0.0
    r.figures["average_rate"] = round(avg, 6)
    credits = 0.0
    cr = rules["credits"]
    for key, label, limit, law, concept in (("donations", "donations to approved institutions", cr["donation_share"],
                                             cr["donation_law"], "tax_credits"),
                                            ("pension", "contribution to approved pension fund", cr["pension_share"],
                                             cr["pension_law"], "tax_credits")):
        paid = _n(ret["credits"][key])
        if not paid:
            continue
        eligible = min(paid, limit * taxable)
        credit = avg * eligible
        credits += credit
        r.add("Tax credits", f"Credit for {label}", -credit, law,
              f"Average rate {avg:.2%} × eligible amount {money(eligible)} (lower of {money(paid)} paid and "
              f"{limit:.0%} of taxable income).", concept)
    credits = min(credits, tax_normal)
    tax_after_credits = tax_normal - credits

    # ---------------------------------------------------------------- withholding: classify by nature
    wh = [w for w in ret["withholding"] if _n(w.get("amount"))]
    by_nature = {"adjustable": 0.0, "final": 0.0, "minimum": 0.0}
    for w in wh:
        info = rules.withholding(str(w.get("section")))
        by_nature[info["nature"]] = by_nature.get(info["nature"], 0.0) + _n(w["amount"])
    minimum = by_nature["minimum"]
    if minimum > tax_after_credits:
        r.add("Tax chargeable", "Minimum tax applies", minimum - tax_after_credits, "Sections 148, 153, 233",
              f"Tax deducted as minimum tax ({money(minimum)}) is more than the tax worked out on income "
              f"({money(tax_after_credits)}), so the minimum tax is the liability.", "minimum_tax")
        tax_after_credits = minimum
    normal_liability = r.add("Tax chargeable", "Tax on normal income after credits", tax_after_credits,
                             total=True, key="normal_tax")

    # ---------------------------------------------------------------- separate blocks
    r.figures["property_income"] = round(rent, 2)

    pod_tax = 0.0
    if pod_separate:
        rate = pod_rules["rate"] if atl else pod_rules["rate_non_atl"]
        pod_tax = r.add("Separate block", "Tax on profit on debt", pod_separate * rate, pod_rules["law"],
                        f"{money(pod_separate)} × {rate:.0%}. Final tax: deducted at source by the bank and not "
                        "added to other income.", "profit_on_debt")
    div = _n(oth["dividend"])
    div_tax = 0.0
    if div:
        dr = rules["dividend"]
        rate = dr.get(oth.get("dividend_kind") or "general", dr["general"]) * (1 if atl else dr["non_atl_factor"])
        div_tax = r.add("Separate block", "Tax on dividend", div * rate, dr["law"],
                        f"{money(div)} × {rate:.1%}. Final tax deducted by the company.", "dividend")

    cg_tax, cg_total = 0.0, 0.0
    for i, cg in enumerate(ret["capital_gains"], start=1):
        tax, gain, note, law = _capital_gain(cg, rules, atl)
        cg_total += max(gain, 0)
        if gain < 0:
            r.warnings.append(f"Capital loss on asset {i} ({money(-gain)}) can only be set off against capital gains.")
        cg_tax += r.add("Separate block", f"Capital gain {i}: {cg.get('asset', 'asset')} ({money(max(gain, 0))})",
                        tax, law, note, "capital_gains")
    r.figures["capital_gains"] = round(cg_total, 2)

    # ---------------------------------------------------------------- surcharge (s.4AB)
    s4 = rules["surcharge"]
    surcharge = 0.0
    if taxable > s4["threshold"]:
        rate = s4["salaried"] if salaried else s4["non_salaried"]
        surcharge = r.add("Tax chargeable", "Surcharge", normal_liability * rate, s4["law"],
                          f"Taxable income above {money(s4['threshold'])}: {rate:.0%} of the tax on income.", "surcharge")

    chargeable = r.add("Tax chargeable", "Total tax chargeable",
                       normal_liability + surcharge + pod_tax + div_tax + cg_tax, "Section 4",
                       total=True, key="tax_chargeable", concept="tax_chargeable")

    # ---------------------------------------------------------------- taxes paid and balance
    for w in wh:
        info = rules.withholding(str(w.get("section")))
        r.add("Tax paid", f"s.{info['section']} {info['title']}", _n(w["amount"]), f"Section {info['section']}",
              {"adjustable": "Adjustable: credited against the total tax chargeable.",
               "final": "Final: it is the tax on that income, so it settles it and can't be refunded.",
               "minimum": "Minimum: the tax on that income can't be lower than this."}[info["nature"]],
              {"adjustable": "adjustable_tax", "final": "final_tax", "minimum": "minimum_tax"}[info["nature"]])
    paid = r.add("Tax paid", "Total tax paid / deducted", sum(_n(w["amount"]) for w in wh), total=True, key="tax_paid")
    balance = chargeable - paid
    final_liab = pod_tax + div_tax
    excess_final = max(0.0, by_nature["final"] - final_liab)
    if balance < 0 and excess_final:
        not_refundable = min(excess_final, -balance)
        balance += not_refundable
        r.warnings.append(f"{money(not_refundable)} of final tax deducted is more than the tax on that income but "
                          "isn't refundable (final tax).")
    r.figures["balance"] = round(balance, 2)
    r.add("Balance", "Tax payable" if balance >= 0 else "Tax refundable", abs(balance),
          "Sections 137 / 170; rule 210IC", "Pay with the return (CPR / PSID) by the due date." if balance >= 0
          else "Claim the refund in the return; it is verified before being paid.",
          "tax_payable_refund", total=True)
    r.figures.update(pod_separate=round(pod_separate, 2), dividend=round(div, 2), pod_tax=round(pod_tax, 2), dividend_tax=round(div_tax, 2),
                     cg_tax=round(cg_tax, 2), surcharge=round(surcharge, 2), credits=round(credits, 2))
    return r


def _capital_gain(cg: dict, rules: Rules, atl: bool) -> tuple[float, float, str, str]:
    asset = cg.get("asset", "property")
    rules_cg = rules["capital_gains"]["securities" if asset == "securities" else "property"]
    gain = _n(cg.get("sale")) - _n(cg.get("cost"))
    acquired, disposed = _date(cg.get("acquired")), _date(cg.get("disposed"))
    if gain <= 0:
        return 0.0, gain, "No gain, no tax.", rules_cg["law"]
    if acquired and acquired >= date.fromisoformat(rules_cg["new_from"]):
        if atl:
            rate = rules_cg["rate_atl"]
            return gain * rate, gain, (f"Acquired on or after {rules_cg['new_from']}: flat {rate:.0%} for an active "
                                       "taxpayer, whatever the holding period."), rules_cg["law"]
        tax = rules.slab("non_salaried", gain).tax
        return max(tax, gain * rules_cg["rate_atl"]), gain, ("Not on the Active Taxpayers List: taxed at the "
                                                            "higher progressive rates."), rules_cg["law"]
    years = ((disposed or date.today()) - acquired).days / 365.25 if acquired else 0.0
    table = rules_cg["old"] if asset == "securities" else rules_cg["old"].get(cg.get("kind") or "open_plot",
                                                                             rules_cg["old"]["open_plot"])
    rate = rules.holding_rate(table, years)
    return gain * rate, gain, (f"Acquired before {rules_cg['new_from']} and held {years:.1f} years: "
                               f"{rate:.1%} under the holding-period table."
                               + (" Held long enough to be tax-free." if rate == 0 else "")), rules_cg["law"]
