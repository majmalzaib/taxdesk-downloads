"""Section index: what each section referred to in the app is about, and links to it.

linkify() turns references like "Section 12(2)(b)", "Sections 56–59", "s.149" or "Second Schedule"
into links of the form law:ITO:12 (Income Tax Ordinance 2001) or law:STA:8B (Sales Tax Act 1990).
"""
from __future__ import annotations

import gzip
import html
import json
import re
from functools import lru_cache
from urllib.parse import quote_plus

from . import lawdata

ACTS = {"ITO": "Income Tax Ordinance 2001", "STA": "Sales Tax Act 1990",
        "ITR": "Income Tax Rules 2002", "STR": "Sales Tax Rules 2006"}
ABBR = {"ITO": "ITO 2001", "STA": "STA 1990", "ITR": "IT Rules 2002", "STR": "ST Rules 2006"}
RULES_OF = {"ITO": "ITR", "STA": "STR"}  # the rules made under each law
# FBR's pages listing the latest consolidated text of each law
OFFICIAL = {
    "ITO": "https://www.fbr.gov.pk/categ/income-tax-ordinance/326",
    "ITR": "https://www.fbr.gov.pk/categ/income-tax-rules-2002/335",
    "STA": "https://www.fbr.gov.pk/categ/sales-tax-act/301",
    "STR": "https://www.fbr.gov.pk/categ/sales-tax-rules-2006/302",
}

SECTIONS: dict[tuple[str, str], str] = {
    ("ITO", "2"): "Definitions, e.g. s.2(36) non-profit organisation.",
    ("ITO", "4"): "Tax on taxable income: the charge of income tax.",
    ("ITO", "4AB"): "Surcharge on high-income individuals and AOPs.",
    ("ITO", "5"): "Tax on dividends, as a separate block.",
    ("ITO", "7B"): "Tax on profit on debt, as a separate block.",
    ("ITO", "8"): "General provisions for taxes imposed as separate blocks / final taxes.",
    ("ITO", "9"): "Taxable income: total income less deductible allowances.",
    ("ITO", "10"): "Total income: income under all heads.",
    ("ITO", "11"): "Heads of income.",
    ("ITO", "12"): "Income from salary.",
    ("ITO", "13"): "Value of perquisites provided by the employer.",
    ("ITO", "15"): "Income from property (rent).",
    ("ITO", "18"): "Income from business.",
    ("ITO", "20"): "Deductions allowed in computing business income.",
    ("ITO", "21"): "Deductions not allowed (inadmissible expenses).",
    ("ITO", "22"): "Depreciation.",
    ("ITO", "23"): "Initial allowance on new assets.",
    ("ITO", "37"): "Capital gains, including on immovable property (s.37(1A)).",
    ("ITO", "37A"): "Capital gain on disposal of securities.",
    ("ITO", "39"): "Income from other sources.",
    ("ITO", "41"): "Agricultural income (exempt from federal income tax).",
    ("ITO", "56"): "Set-off of losses.",
    ("ITO", "57"): "Carry-forward of business losses.",
    ("ITO", "58"): "Carry-forward of speculation business losses.",
    ("ITO", "59"): "Losses: miscellaneous provisions.",
    ("ITO", "60"): "Zakat as a deductible allowance.",
    ("ITO", "60D"): "Deductible allowance for education expenses.",
    ("ITO", "61"): "Tax credit for charitable donations.",
    ("ITO", "62"): "Tax credit for investment in shares and insurance.",
    ("ITO", "63"): "Tax credit for contributions to an approved pension fund.",
    ("ITO", "64"): "Tax credits: further provisions.",
    ("ITO", "65"): "Tax credits: further provisions.",
    ("ITO", "66"): "Income of joint owners (co-ownership).",
    ("ITO", "74"): "Tax year.",
    ("ITO", "81"): "Resident and non-resident persons.",
    ("ITO", "82"): "Resident individual.",
    ("ITO", "90"): "Transfers of assets (income clubbed with the transferor).",
    ("ITO", "109"): "Recharacterisation of income and deductions (anti-avoidance).",
    ("ITO", "111"): "Unexplained income or assets.",
    ("ITO", "113"): "Minimum tax on turnover of certain persons.",
    ("ITO", "114"): "Return of income: who must file.",
    ("ITO", "116"): "Wealth statement.",
    ("ITO", "118"): "Method and time of furnishing returns.",
    ("ITO", "122"): "Amendment of assessments.",
    ("ITO", "137"): "Due date for payment of tax.",
    ("ITO", "147"): "Advance tax paid by the taxpayer.",
    ("ITO", "148"): "Tax collected on imports.",
    ("ITO", "149"): "Tax deducted from salary.",
    ("ITO", "150"): "Tax deducted from dividends.",
    ("ITO", "151"): "Tax deducted from profit on debt.",
    ("ITO", "153"): "Tax deducted on payments for goods, services and contracts.",
    ("ITO", "155"): "Tax deducted from rent of immovable property.",
    ("ITO", "158"): "Time of deduction of tax.",
    ("ITO", "160"): "Payment of tax collected or deducted.",
    ("ITO", "161"): "Failure to pay tax collected or deducted: the agent becomes liable.",
    ("ITO", "165"): "Statements by withholding agents.",
    ("ITO", "170"): "Refunds.",
    ("ITO", "181"): "Taxpayer registration (NTN).",
    ("ITO", "181A"): "Active Taxpayers List.",
    ("ITO", "182"): "Offences and penalties.",
    ("ITO", "192"): "Prosecution for false statements (evasion).",
    ("ITO", "205"): "Default surcharge on late payment.",
    ("ITO", "231B"): "Advance tax on motor vehicles.",
    ("ITO", "233"): "Tax deducted on brokerage and commission.",
    ("ITO", "235"): "Advance tax collected through electricity bills.",
    ("ITO", "236"): "Advance tax on telephone, mobile and internet.",
    ("ITO", "236C"): "Advance tax on sale or transfer of immovable property.",
    ("ITO", "236G"): "Advance tax on sales to distributors, dealers and wholesalers.",
    ("ITO", "236H"): "Advance tax on sales to retailers.",
    ("ITO", "236K"): "Advance tax on purchase of immovable property.",
    ("ITO", "236Y"): "Advance tax on remittances abroad through cards.",
    ("ITO", "First Schedule"): "Rates of tax: slab tables, separate-block and withholding rates.",
    ("ITO", "First Schedule, Part I, Division I"): "Slab rates for individuals and AOPs, salaried and non-salaried (s.4).",
    ("ITO", "First Schedule, Part I, Division IIB"): "Super tax on high earning persons (s.4C).",
    ("ITO", "First Schedule, Part I, Division III"): "Rate of tax on dividends (s.5).",
    ("ITO", "First Schedule, Part I, Division IIIA"): "Rate of tax on profit on debt (s.7B).",
    ("ITO", "First Schedule, Part I, Division VIA"): "Rates on income from property (s.15); omitted by the Finance Act 2021.",
    ("ITO", "First Schedule, Part I, Division VII"): "Capital gains on disposal of securities (s.37A).",
    ("ITO", "First Schedule, Part I, Division VIII"): "Capital gains on disposal of immovable property (s.37(1A)).",
    ("ITO", "First Schedule, Part I, Division IX"): "Minimum tax as a percentage of turnover (s.113).",
    ("ITO", "First Schedule, Part III, Division III"): "Tax deducted from payments for goods, services and contracts (s.153).",
    ("ITO", "First Schedule, Part III, Division V"): "Tax deducted from rent of property (s.155).",
    ("ITO", "164"): "Certificates of tax collected or deducted.",
    ("ITO", "Second Schedule"): "Exemptions and tax concessions (Part I exemptions, Part III reductions).",
    ("ITO", "Third Schedule"): "Depreciation rates.",
    ("ITO", "Fourth Schedule"): "Computation of profits of insurance business.",
    ("ITO", "Fifth Schedule"): "Computation of profits from petroleum and mineral exploration and production.",
    ("ITO", "Sixth Schedule"): "Recognised provident funds, and approved superannuation and gratuity funds.",
    ("ITO", "Ninth Schedule"): "Traders' option to be taxed under this Schedule instead of the normal provisions (s.99A).",
    ("ITO", "Tenth Schedule"): "Higher rates for persons not on the Active Taxpayers List.",
    ("ITO", "Twelfth Schedule"): "Goods imported under section 148, listed by PCT code.",
    ("ITO", "Thirteenth Schedule"): "Institutions donations to which qualify under section 61.",
    ("ITO", "First Schedule, Part II"): "Rates of advance tax collected on imports (s.148).",
    ("STA", "2"): "Definitions, e.g. 2(5AB) cottage industry, 2(43A) Tier-1 retailer.",
    ("STA", "3"): "Scope of tax: sales tax on taxable supplies and imports; s.3(1A) further tax.",
    ("STA", "4"): "Zero rating.",
    ("STA", "6"): "Time and manner of payment.",
    ("STA", "7"): "Determination of tax liability: input tax adjustment.",
    ("STA", "8"): "Input tax not allowed (inadmissible).",
    ("STA", "8B"): "Limit on adjustable input tax (90% of output tax).",
    ("STA", "10"): "Excess input tax carried forward or refunded.",
    ("STA", "13"): "Exemptions.",
    ("STA", "14"): "Registration.",
    ("STA", "26"): "Return: monthly sales tax return by registered persons.",
    ("STA", "First Schedule"): "Omitted in 1997.",
    ("STA", "Second Schedule"): "Omitted.",
    ("STA", "Third Schedule"): "Goods taxed on their retail price (s.3(2)(a)).",
    ("STA", "Fourth Schedule"): "Omitted.",
    ("STA", "Fifth Schedule"): "Zero-rated supplies.",
    ("STA", "Seventh Schedule"): "Omitted.",
    ("STA", "Eighth Schedule"): "Reduced rates of sales tax, with their conditions (s.3(2)(aa)).",
    ("STA", "Ninth Schedule"): "Cellular mobile phones and SIM cards: tax on import and supply (s.3(3B)).",
    ("STA", "Tenth Schedule"): "Tax paid on a fixed basis, e.g. on bricks (s.3(1B)).",
    ("STA", "Eleventh Schedule"): "Withholding of sales tax by withholding agents (s.3(7) and (7A)).",
    ("STA", "Twelfth Schedule"): "Value addition tax on imported goods (s.7A).",
    # Income Tax Rules 2002 (checked against FBR's consolidated text amended up to 15 September 2026)
    ("ITR", "3"): "Valuation of perquisites, allowances and benefits.",
    ("ITR", "4"): "Valuation of accommodation provided by the employer.",
    ("ITR", "5"): "Valuation of conveyance (motor vehicle) provided by the employer.",
    ("ITR", "12"): "Particulars to furnish when claiming depreciation or initial allowance.",
    ("ITR", "13C"): "Holding period of securities.",
    ("ITR", "34"): "Return of income: the prescribed form.",
    ("ITR", "36"): "Wealth statement: the prescribed form.",
    ("ITR", "42"): "Certificate of collection or deduction of tax (other than salary).",
    ("ITR", "43"): "Payment of tax collected or deducted to the government.",
    ("ITR", "44"): "Statement of tax collected or deducted (withholding statements).",
    ("ITR", "80"): "Registration (NTN).",
    ("ITR", "81B"): "Active Taxpayers List.",
    ("ITR", "210IC"): "Sanction and payment of refund.",
    ("ITR", "211"): "Procedure for approval of a non-profit organisation (for donation credits).",
    # Sales Tax Rules 2006 (checked against FBR's consolidated text updated up to 31 July 2026)
    ("STR", "5"): "Application for registration.",
    ("STR", "6"): "Compulsory registration.",
    ("STR", "11"): "De-registration.",
    ("STR", "14"): "Filing of returns.",
    ("STR", "18"): "Electronic filing of sales tax return.",
    ("STR", "22"): "Adjustment of input and output tax.",
    ("STR", "25"): "Determination (apportionment) of input tax between taxable and exempt supplies.",
    ("STR", "34"): "Refund of excess input tax not relating to zero-rated supplies.",
    ("STA", "Sixth Schedule"): "Exempt supplies.",
}

_NUM = r"\d+[A-Z]{0,5}(?:\(\w+\))*"
_REF = re.compile(rf"\b(?P<word>[Ss]ections?|[Ss]\.)\s*(?P<list>{_NUM}(?:\s*(?:,|and|/|–|-|to)\s*{_NUM})*)")
_RULE = re.compile(rf"\b(?P<word>[Rr]ules?)\s*(?P<list>(?!\d{{4}}\b){_NUM}(?:\s*(?:,|and|/|–|-|to)\s*{_NUM})*)")
_SCHED = re.compile(r"\b(First|Second|Third|Fourth|Fifth|Sixth|Seventh|Eighth|Ninth|Tenth|Eleventh|Twelfth|Thirteenth|"
                    r"Fourteenth) Schedule\b")
# Divisions of the First Schedule ("Division VIII of Part I of the First Schedule", "First Schedule, Part III,
# Division V", or "Division VIII" alone, which in TaxDesk is always Part I) and of the Ordinance's chapters
# ("Division II or III of Part V of Chapter X")
_DIV_NUM = r"[IVX]+[A-Z]{0,2}(?![A-Za-z])"
_DIV = re.compile(rf"\bDivisions? (?P<list>{_DIV_NUM}(?: (?:or|and|to) {_DIV_NUM})*)(?:,? (?:of )?Part (?P<part>[IVX]+)\b)?"
                  rf"(?: of Chapter (?P<chapter>[IVX]+[A-Z]?)\b| of the First Schedule\b)?")
_SCHED_DIV = re.compile(rf"\bFirst Schedule, Part (?P<part>[IVX]+), Division (?P<list>{_DIV_NUM})")
_ONE = re.compile(_NUM)
_NAMED_ACT = {"ito": "ITO", "income tax ordinance": "ITO", "sta": "STA", "sales tax act": "STA", "it rules": "ITR",
              "income tax rules": "ITR", "st rules": "STR", "sales tax rules": "STR"}
_NAMED = re.compile(r"\s*(?:of|under)\s+the\s+(ITO|Income Tax Ordinance|STA|Sales Tax Act|IT Rules|Income Tax Rules|"
                    r"ST Rules|Sales Tax Rules)\b", re.I)


def base(num: str) -> str:
    """'153(1)(a)' -> '153'."""
    return num.split("(")[0]


def act_for(text: str, default: str = "ITO") -> str:
    t = text or ""
    if "Sales Tax Act" in t or "Sales Tax Rules" in t:
        return "STA"
    return default


def names_a_law(text: str) -> bool:
    return any(n in (text or "") for n in ("Ordinance", "Act", "Rules", "provincial", "Provincial"))


def _acts_linked(linked: str) -> list[str]:
    return list(dict.fromkeys(re.findall(r"href='law:(\w+):", linked)))


def cite(text: str, act: str = "ITO") -> str:
    """Linked reference that always names its law(s), e.g. 'Section 165; rule 44 · ITO 2001, IT Rules 2002'."""
    if not text:
        return ""
    linked = linkify(text, act)
    acts = _acts_linked(linked)
    if acts and not names_a_law(text):
        linked += " <span title='" + "; ".join(ACTS[a] for a in acts) + "'>· " + ", ".join(ABBR[a] for a in acts) + "</span>"
    return linked


def cite_text(text: str, act: str = "ITO") -> str:
    """The plain-text version of cite(), for table cells."""
    acts = _acts_linked(linkify(text or "", act))
    if not acts or names_a_law(text):
        return text or ""
    return f"{text} · {', '.join(ABBR[a] for a in acts)}"


def related_rules(act: str, key: str) -> list[tuple[str, str]]:
    return [r for r in SECTION_RULES.get((act, key), ()) if r in SECTIONS]


@lru_cache(maxsize=1)
def _index() -> dict:
    """Official arrangement of sections/rules (number, heading, chapter, part, division) from FBR's texts."""
    data = json.loads(lawdata.path("law_index.json").read_text(encoding="utf-8"))
    return {act: {"source": v["source"], "items": v["items"], "by_num": {i["num"]: i for i in v["items"]}}
            for act, v in data.items()}


def index_items(act: str) -> list[dict]:
    return _index().get(act, {}).get("items", [])


def index_source(act: str) -> str:
    return _index().get(act, {}).get("source", "")


def official(act: str, key: str) -> dict | None:
    """The official entry for a section or rule, if it is in the index."""
    return _index().get(act, {}).get("by_num", {}).get(key)


def heading(act: str, key: str) -> str:
    entry = official(act, key)
    if entry:
        return entry["title"]
    if division_sections(act, key):
        return division_sections(act, key)[0].get("division_title", "")
    return (text(act, key) or {}).get("title", "")


def division_key(chapter: str | None, part: str | None, division: str) -> str:
    """'Chapter X, Part V, Division III' for a division of the Ordinance's chapters, or else a division of the First
    Schedule: 'First Schedule, Part I, Division VIII' (Part I when no part is named)."""
    if chapter:
        return f"Chapter {chapter}, Part {part}, Division {division}"
    return f"First Schedule, Part {part or 'I'}, Division {division}"


def division_sections(act: str, key: str) -> list[dict]:
    """The sections in a division of a chapter ('Chapter X, Part V, Division III'), in order; [] for anything else."""
    m = re.fullmatch(r"Chapter (\w+), Part (\w+), Division (\w+)", key)
    if not m:
        return []
    return [e for e in index_items(act) if (e.get("chapter"), e.get("part"), e.get("division")) == m.groups()]


def schedules(act: str) -> list[str]:
    """The schedules of a law TaxDesk has, 'First Schedule' to the last, in order."""
    return [k for k in _texts().get(act, {}).get("sections", {}) if k.endswith(" Schedule")]


def schedule_divisions(act: str = "ITO") -> list[str]:
    """The divisions of the First Schedule TaxDesk has the wording of, in the order of the Schedule, and its Part II,
    which has no divisions."""
    return [k for k in _texts().get(act, {}).get("sections", {}) if k.startswith("First Schedule, ")]


def location(act: str, key: str) -> str:
    """'Chapter IV Common Rules › Part III Assets' for a section."""
    if key.startswith("First Schedule, "):
        return " › ".join(key.split(", ")[:2])
    e = official(act, key) or next(iter(division_sections(act, key)), None)
    if not e:
        return ""
    parts = []
    if e.get("chapter"):
        parts.append(f"Chapter {e['chapter']} {e.get('chapter_title', '').title()}".strip())
    if e.get("part"):
        parts.append(f"Part {e['part']} {e.get('part_title', '').title()}".strip())
    if e.get("division_title") and not division_sections(act, key):  # a division's card has its title as heading
        parts.append(f"Division {e.get('division', '')} {e['division_title']}".replace("  ", " ").strip())
    return " › ".join(parts)


def describe(act: str, key: str) -> str:
    """TaxDesk's note on a section, or else its official heading."""
    return SECTIONS.get((act, key)) or heading(act, key)


def search(text: str, limit: int = 40) -> list[tuple[str, str, str]]:
    """[(act, number, heading)] whose number or heading matches; omitted sections are left out."""
    t = text.strip().lower()
    if not t:
        return []
    num = re.sub(r"^(section|sec\.?|s\.|rule|r\.)\s*", "", t).upper()
    out = []
    for act in ACTS:
        for e in index_items(act):
            if e.get("omitted"):
                continue
            if e["num"] == num or t in e["title"].lower() or t in (SECTIONS.get((act, e["num"])) or "").lower():
                out.append((act, e["num"], e["title"]))
    out.sort(key=lambda r: (r[1] != num, list(ACTS).index(r[0])))
    return out[:limit]


# Rules made under a section, shown on its card
SECTION_RULES: dict[tuple[str, str], list[tuple[str, str]]] = {
    ("ITO", "13"): [("ITR", "3"), ("ITR", "4"), ("ITR", "5")], ("ITO", "22"): [("ITR", "12")],
    ("ITO", "23"): [("ITR", "12")], ("ITO", "37A"): [("ITR", "13C")], ("ITO", "114"): [("ITR", "34")],
    ("ITO", "116"): [("ITR", "36")], ("ITO", "164"): [("ITR", "42")], ("ITO", "160"): [("ITR", "43")],
    ("ITO", "161"): [("ITR", "43")], ("ITO", "165"): [("ITR", "44")], ("ITO", "181"): [("ITR", "80")],
    ("ITO", "181A"): [("ITR", "81B")], ("ITO", "170"): [("ITR", "210IC")], ("ITO", "61"): [("ITR", "211")],
    ("ITO", "153"): [("ITR", "42"), ("ITR", "43")], ("ITO", "149"): [("ITR", "43")],
    ("ITO", "151"): [("ITR", "42"), ("ITR", "43")], ("ITO", "150"): [("ITR", "42"), ("ITR", "43")],
    ("ITO", "155"): [("ITR", "42"), ("ITR", "43")],
    ("STA", "14"): [("STR", "5"), ("STR", "6"), ("STR", "11")], ("STA", "26"): [("STR", "14"), ("STR", "18")],
    ("STA", "6"): [("STR", "14")], ("STA", "7"): [("STR", "22")], ("STA", "8"): [("STR", "25")],
    ("STA", "10"): [("STR", "34")],
}


# ---------------------------------------------------------------- the wording of the law
# data/law_text.json.gz (or a newer edition the owner has published: see lawdata) holds the text of each
# section and rule, cut from FBR's consolidated PDFs by
# tools/build_law_text.py: {act: {"source", "sections": {num: {"paras": [[level, text] or [level, text, "row"]],
# "notes": [footnote, …], "cut"?}}}}. A schedule (or a division of the First Schedule) is keyed by its name, e.g.
# "Second Schedule", and also has a "title", a "see" (the section it serves) and [0, text, "head"] for each of its
# parts' headings. In the text, ⟦n⟧ marks footnote n, the amendment that changed the words after it.
_MARK = re.compile("\u27e6(\\d+)\u27e7")


@lru_cache(maxsize=1)
def _texts() -> dict:
    try:
        return json.loads(gzip.decompress(lawdata.path("law_text.json.gz").read_bytes()))
    except OSError:
        return {}


def text(act: str, key: str) -> dict | None:
    """The wording of a section or rule: {"paras", "notes", "cut"?}, or None when TaxDesk doesn't have it."""
    return _texts().get(act, {}).get("sections", {}).get(key)


def text_source(act: str) -> str:
    return _texts().get(act, {}).get("source", "")


def plain_text(act: str, key: str, limit: int | None = None) -> str:
    """The wording as plain text, paragraphs on their own lines, footnote markers raised as ⁽n⁾ (for the assistant)."""
    t = text(act, key)
    if not t:
        return ""
    out = "\n".join(_MARK.sub(lambda m: f"⁽{m.group(1)}⁾", p[1]) for p in t["paras"])
    return out if limit is None or len(out) <= limit else out[:limit].rsplit(" ", 1)[0] + " …"


def text_html(act: str, key: str, highlight: str = "") -> str:
    """The wording as HTML: each paragraph indented by its level (sub-section, clause, sub-clause…), table rows
    kept in columns, footnote markers raised, and the amendment notes after it. Words matching highlight are marked,
    the first with the anchor "hit"."""
    t = text(act, key)
    if not t:
        return ""
    hit = None
    if re.search("[A-Za-z]{3}", highlight):  # the words searched for: as a phrase where it occurs, or else each word
        body = _MARK.sub("", " ".join(p[1] for p in t["paras"]))
        phrase = re.escape(highlight.strip())
        words = search_words(highlight)
        hit = re.compile(re.escape(html.escape(highlight.strip())) if re.search(phrase, body, re.I) or not words
                         else "|".join(re.escape(html.escape(w)) for w in words), re.I)
    first = [True]

    def mark(escaped: str) -> str:
        escaped = _MARK.sub(lambda m: f"<sup style='color:gray'>{m.group(1)}</sup>", escaped)
        if not hit:
            return escaped

        def wrap(m: re.Match) -> str:
            anchor = "<a name='hit'></a>" if first[0] else ""
            first[0] = False
            return f"{anchor}<span style='background:#fde68a; color:#1f2937'>{m.group(0)}</span>"
        # only outside tags, so a marker's <sup style=…> is never touched
        return "".join(part if part.startswith("<") else hit.sub(wrap, part) for part in re.split(r"(<[^>]+>)", escaped))

    out, rows = [], []

    def flush() -> None:
        if rows:
            out.append("<pre style='font-size:11px; margin:6px 0'>" + "\n".join(rows) + "</pre>")
            rows.clear()
    for p in t["paras"]:
        if p[2:] == ["row"]:
            rows.append(mark(html.escape(p[1])))
            continue
        flush()
        if p[2:] == ["head"]:  # a part of a schedule
            out.append(f"<p style='margin:14px 0 6px'><b>{mark(html.escape(p[1]))}</b></p>")
            continue
        out.append(f"<p style='margin:0 0 6px {p[0] * 22}px'>{mark(html.escape(p[1]))}</p>")
    flush()
    if t.get("cut"):
        out.append(f"<p style='color:gray'>The rest of this {'rule' if act in ('ITR', 'STR') else 'section'} "
                   f"(mostly forms and tables) is in the official text.</p>")
    if t["notes"]:
        out.append("<p style='margin-top:12px'><b>Amendment notes</b></p><ol style='color:gray; font-size:12px'>"
                   + "".join(f"<li>{mark(html.escape(n))}</li>" for n in t["notes"]) + "</ol>")
    return "".join(out)


STOP_WORDS = {"the", "and", "for", "any", "from", "with", "that", "this", "under", "into", "are", "was", "has",
              "have", "its", "his", "her", "not", "but", "all", "who", "what", "which", "how", "when", "where", "does"}


def search_words(text: str) -> list[str]:
    """The words of a search that matter: three letters or more, not "the", "and"…"""
    return [w for w in dict.fromkeys(re.findall(r"[A-Za-z0-9]{3,}", text.lower())) if w not in STOP_WORDS]


def marker(query: str) -> re.Pattern:
    """Finds a search in HTML-escaped text, to mark it: the phrase where it occurs, or else each of its words."""
    parts = [re.escape(html.escape(query.strip()))] + [re.escape(html.escape(w)) for w in search_words(query)]
    return re.compile("|".join(p for p in parts if p), re.I)


def search_all_words(text: str, limit: int = 60) -> list[tuple[str, str, str, str]]:
    """[(act, key, heading, snippet)] of provisions whose wording has every word of the search, in any order and
    anywhere ("foreign remittance" finds "foreign exchange remitted"). The snippet is around the first word."""
    words = search_words(text)
    if len(words) < 2:
        return []
    out = []
    for act in ACTS:
        for key, t in _texts().get(act, {}).get("sections", {}).items():
            body = _MARK.sub("", " ".join(p[1] for p in t["paras"]))
            low = body.lower()
            if all(w in low for w in words):
                at = low.index(words[0])
                a, b = max(0, at - 60), min(len(body), at + 120)
                snippet = ("…" if a else "") + body[a:b].strip() + ("…" if b < len(body) else "")
                out.append((act, key, heading(act, key), re.sub(r"\s+", " ", snippet)))
                if len(out) >= limit:
                    return out
    return out


def search_text(phrase: str, limit: int = 30) -> list[tuple[str, str, str, str]]:
    """[(act, number, heading, snippet)] of sections and rules whose wording contains the phrase (3+ letters),
    laws in their usual order. The snippet is the phrase with some words either side."""
    q = phrase.strip()
    if not re.search("[A-Za-z]{3}", q):  # words, not a section number
        return []
    pattern = re.compile(re.escape(q), re.I)
    out = []
    for act in ACTS:
        for key, t in _texts().get(act, {}).get("sections", {}).items():
            body = _MARK.sub("", " ".join(p[1] for p in t["paras"]))
            m = pattern.search(body)
            if m:
                a, b = max(0, m.start() - 60), min(len(body), m.end() + 60)
                snippet = ("…" if a else "") + body[a:b].strip() + ("…" if b < len(body) else "")
                out.append((act, key, heading(act, key), re.sub(r"\s+", " ", snippet)))
                if len(out) >= limit:
                    return out
    return out


def exists(act: str, key: str) -> bool:
    """Whether TaxDesk has a card for this section, rule, schedule or division."""
    return bool(official(act, key) or text(act, key) or division_sections(act, key))


def find(query: str, act: str = "", limit: int = 80) -> list[tuple[str, str, str, str, str]]:
    """[(act, key, heading, snippet, how)] for the References and Law library searches, best first: a reference
    written out ("section 37A", "s.153", "rule 44", "Second Schedule", "Division VIII of Part I"), then a number on its
    own ("153"), then words in a heading, then the words in the wording (with a snippet): as a phrase, then every word
    in any order. how is "reference", "number", "heading" or
    "wording"; act limits it to one law."""
    q = query.strip()
    if not q:
        return []
    out: list[tuple[str, str, str, str, str]] = []
    seen: set[tuple[str, str]] = set()

    def add(a: str, key: str, how: str, snippet: str = "") -> None:
        if (not act or a == act) and (a, key) not in seen and exists(a, key):
            seen.add((a, key))
            out.append((a, key, heading(a, key) or describe(a, key), snippet, how))
    sales = act in ("STA", "STR")  # "rule 44" with the Sales Tax Rules chosen is one of theirs
    written = re.sub(r"\b(\w+)\s+schedule\b", lambda m: f"{m.group(1).title()} Schedule", q, flags=re.I)  # as typed
    written = re.sub(r"\b(division|part)\s+([ivx]+[a-z]{0,2})\b", lambda m: f"{m.group(1).title()} {m.group(2).upper()}",
                     written, flags=re.I)
    for a, key in sorted(cited(written, "STA" if sales else "ITO"), key=lambda r: list(ACTS).index(r[0])):
        add(a, key, "reference")
        if key.endswith(" Schedule") and not act and not names_a_law(q):
            add("STA", key, "reference")  # "Sixth Schedule": the Act has one too
    if not out and act and re.fullmatch(r"(?:sections?|s\.|rules?|r\.)?\s*\d+[A-Z]*(?:\(\w+\))*", q, re.I):
        add(act, base(re.sub(r"^\D+", "", q).upper()), "reference")  # "37A" with a law chosen
    for a, key, _ in search(q, limit=200):
        add(a, key, "number" if key == re.sub(r"^(section|sec\.?|s\.|rule|r\.)\s*", "", q.lower()).upper() else "heading")
    words = q.lower()
    for a in ACTS:  # schedules and divisions by heading or name ("sixth schedule", "tax on builders")
        for key in schedules(a) + schedule_divisions(a):
            if words in key.lower() or words in (heading(a, key) or describe(a, key)).lower():
                add(a, key, "heading")
    for a, key, _, snippet in search_text(q, limit=limit):
        add(a, key, "wording", snippet)
    for a, key, _, snippet in search_all_words(q, limit=limit):  # every word, in any order
        add(a, key, "wording", snippet)
    return out[:limit]


def search_url(act: str, key: str) -> str:
    what = key if "Schedule" in key or "Division" in key else f"section {key}"
    return "https://www.google.com/search?q=" + quote_plus(f"{ACTS[act]} {what} FBR")


def linkify(text: str, act: str = "ITO") -> str:
    """HTML-escaped text with every section/schedule reference turned into a law: link."""
    if not text:
        return ""
    act = act_for(text, act)
    out, pos = [], 0
    spans = [(m.start("list"), m.end("list"), "list", m) for m in _REF.finditer(text)]
    spans += [(m.start("list"), m.end("list"), "rule", m) for m in _RULE.finditer(text)]
    spans += [(m.start(), m.end(), "sched", m) for m in _SCHED.finditer(text)]
    if act == "ITO":  # divisions are the Ordinance's
        spans += [(m.start(), m.end(), "div", m) for m in _DIV.finditer(text)]
        spans += [(m.start(), m.end(), "div", m) for m in _SCHED_DIV.finditer(text)]
    for start, end, kind, m in sorted(spans, key=lambda s: (s[0], -s[1])):  # the longest reference at a place wins
        if start < pos:
            continue
        named = _NAMED.match(text, end)  # "... of the STA 1990" names the law of this reference
        ref_act = _NAMED_ACT[named.group(1).lower()] if named else act
        if kind == "rule" and ref_act in RULES_OF:
            ref_act = RULES_OF[ref_act]
        out.append(html.escape(text[pos:start]))
        if kind == "div":
            chapter = m.groupdict().get("chapter")
            nums = list(re.finditer(_DIV_NUM, m.group("list")))
            if len(nums) == 1:  # the whole reference, "Division VIII of Part I of the First Schedule", is the link
                key = division_key(chapter, m.group("part"), nums[0].group(0))
                out.append(f"<a href='law:ITO:{key}'>{html.escape(m.group(0))}</a>")
            else:  # "Division II or III of Part V of Chapter X": each division is a link
                chunk, cpos, offset = m.group(0), 0, m.start("list") - m.start()
                for n in nums:
                    out.append(html.escape(chunk[cpos:offset + n.start()]))
                    key = division_key(chapter, m.group("part"), n.group(0))
                    out.append(f"<a href='law:ITO:{key}'>{html.escape(n.group(0))}</a>")
                    cpos = offset + n.end()
                out.append(html.escape(chunk[cpos:]))
        elif kind == "sched":
            out.append(f"<a href='law:{ref_act}:{m.group(0)}'>{html.escape(m.group(0))}</a>")
        else:
            chunk, cpos = text[start:end], 0
            target = ref_act if named else (RULES_OF.get(act, act) if kind == "rule" else act)
            for n in _ONE.finditer(chunk):
                out.append(html.escape(chunk[cpos:n.start()]))
                out.append(f"<a href='law:{target}:{base(n.group(0))}'>{html.escape(n.group(0))}</a>")
                cpos = n.end()
            out.append(html.escape(chunk[cpos:]))
        pos = end
    out.append(html.escape(text[pos:]))
    return "".join(out)


def cited(text: str, act: str = "ITO") -> set[tuple[str, str]]:
    """Every section/rule a text refers to, with ranges like 'Sections 75–79' expanded to all sections between
    their ends in the official arrangement."""
    linked = linkify(text or "", act)
    refs = {parse_href(h) for h in re.findall(r"href='(law:[^']+)'", linked)}
    for a, k1, k2 in re.findall(r"href='law:(\w+):([^']+)'>[^<]*</a>\s*(?:–|-|to)\s*<a href='law:\w+:([^']+)'", linked):
        order = [e["num"] for e in index_items(a)]
        if k1 in order and k2 in order and order.index(k1) <= order.index(k2):
            refs |= {(a, k) for k in order[order.index(k1):order.index(k2) + 1]}
    return refs


def parse_href(href: str) -> tuple[str, str] | None:
    if not href.startswith("law:"):
        return None
    _, act, key = href.split(":", 2)
    return act, key


def first_ref(text: str, act: str = "ITO") -> tuple[str, str] | None:
    """The first section referred to in a piece of text, e.g. a table cell."""
    m = re.search(r"href='(law:[^']+)'", linkify(text, act))
    return parse_href(m.group(1)) if m else None
