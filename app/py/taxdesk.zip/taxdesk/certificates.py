"""Certificates, registrations and approvals: how to apply, what to attach, who decides, and the law for each.

Every entry cites the section and rule it comes from; the headings were checked against the official arrangement in
law_index.json (Income Tax Rules 2002 amended up to 15 September 2026, Sales Tax Rules 2006 up to 31 July 2026).
Most applications are made online in IRIS. Document lists marked verify=True follow FBR's usual practice and the
forms in IRIS rather than a list printed in the rule itself, so they should be confirmed against the current form.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

IRIS = "https://iris.fbr.gov.pk"
AREAS = ("Registration", "Withholding", "Residence and foreign tax", "Approvals", "Sales tax")


@dataclass(frozen=True)
class Certificate:
    id: str
    area: str
    title: str
    law: str  # sections and rules, cited so the app links them
    act: str  # ITO or STA: the law a bare "section" refers to
    purpose: str
    who: str
    steps: tuple[str, ...]
    documents: tuple[str, ...]
    decided_by: str
    validity: str = ""
    caution: str = ""
    concept: str = ""
    verify: bool = False


C = Certificate
CERTIFICATES: list[Certificate] = [
    # ---------------------------------------------------------------- registration
    C("ntn", "Registration", "NTN registration and NTN certificate", "Section 181; rules 80 and 83", "ITO",
      "Registers a person for income tax. For an individual the NTN is the CNIC. The NTN certificate is printed from "
      "IRIS and, for a business, displayed at the place of business (rule 83).",
      "Every person who must file a return, or who wants to (section 181); every business before it starts trading.",
      ("Open IRIS and choose “Registration for unregistered person”.",
       "Enter the CNIC, a mobile number registered in your own name and an email address; confirm the codes sent "
       "to both.",
       "Log in with the password received and complete the registration form (Form 181): personal details, "
       "address and, for a business, its name, address and principal activity.",
       "Submit. For an individual the NTN is issued at once; companies and AOPs are registered on the details of "
       "their incorporation or formation.",
       "Print the NTN certificate from IRIS (Registration → NTN certificate) and display it at the business."),
      ("CNIC (for a company or AOP: the CNICs of its directors or members)",
       "Mobile number registered in the applicant's own name, and an email address",
       "Business name, address and principal activity",
       "Proof of the business premises: ownership document or rent agreement, and a recent utility bill",
       "Bank account details for the business",
       "Company: certificate of incorporation and memorandum; AOP: partnership deed and registration certificate"),
      "Registered automatically in IRIS; a Commissioner may verify the particulars.",
      "Permanent; changes to address, business or contact details are made in IRIS by modifying the registration.",
      "The mobile number must be in the applicant's own name: IRIS verifies it.",
      "ntn_registration", verify=True),
    C("atl", "Registration", "Getting on the Active Taxpayers List", "Section 181A; rule 81B; Tenth Schedule", "ITO",
      "Puts a person on the income tax ATL, which lowers many withholding rates.",
      "A person who filed the return for the latest tax year late, or who wants to be restored to the list.",
      ("File the return of income (and wealth statement for individuals) for the latest tax year in IRIS.",
       "If the return was filed after the due date, pay the ATL surcharge by generating a PSID in IRIS "
       "(“ATL surcharge”) and paying it at a bank or online.",
       "The name appears on the list at the next weekly update; check with the ATL search or SMS “ATL <CNIC>” "
       "to 9966."),
      ("Return of income for the latest tax year, filed in IRIS", "Wealth statement (individuals)",
       "Payment slip (CPR) of the ATL surcharge, for a late filer"),
      "Prepared by FBR from returns filed (section 181A).",
      "Until the next annual list on 1 March, if returns keep being filed on time.",
      concept="atl", verify=True),
    # ---------------------------------------------------------------- withholding
    C("s159", "Withholding", "Exemption or lower rate certificate (section 159)", "Section 159; rules 40, 40D, 40E and 40F",
      "ITO",
      "Lets a withholding agent deduct less tax, or none, from payments to you: e.g. on contract receipts, supplies, "
      "profit on debt or imports, when your income is exempt or the tax deducted would exceed your actual liability.",
      "A person whose income is exempt (e.g. under the Second Schedule, or an approved non-profit organisation), or "
      "who has paid or will pay enough tax so that full deduction would be excessive.",
      ("In IRIS, open a new form: “Application for exemption / reduced rate certificate under section 159” "
       "(for imports, the form under rules 40D or 40E).",
       "State the section the certificate is for (e.g. 151, 153, 148), the period, the reason, and the rate asked.",
       "Attach the supporting evidence and submit; the application goes to your Commissioner Inland Revenue.",
       "Answer any notice or request for documents from the Commissioner.",
       "Once issued, give the certificate to the withholding agent; agents can verify it online. The Commissioner "
       "monitors its use (rule 40F)."),
      ("Return of income and wealth statement for the latest tax year",
       "Financial statements or accounts; projections of income and tax for the period applied for",
       "Evidence of tax already paid: payment slips (CPRs), withholding certificates, advance tax",
       "The legal basis of the exemption: the Second Schedule clause, NPO approval, or a court or FBR order",
       "Details of the payers (withholding agents) and contracts or invoices the certificate will cover",
       "For imports: the import documents (bill of lading, invoice) and proof of the exemption or rate claimed"),
      "Commissioner Inland Revenue (section 159(1)).",
      "For the period and payments stated in the certificate, usually within one tax year.",
      "Without a certificate the agent must deduct at the full rate; deducting less makes the agent liable "
      "(section 161).",
      "withholding_agent", verify=True),
    C("s164", "Withholding", "Certificate of tax deducted or collected", "Section 164; rule 42", "ITO",
      "Proof of tax deducted or collected from you, needed to claim that tax in your return.",
      "Anyone from whom tax was deducted or collected; the withholding agent must issue it.",
      ("Ask the withholding agent (employer, bank, company, buyer) for the certificate for the tax year.",
       "The agent issues it in the form prescribed by rule 42, or generates it from IRIS.",
       "Check that the tax appears against your CNIC/NTN in IRIS (the agent's section 165 statement); if not, ask the "
       "agent to correct the statement."),
      ("Your CNIC/NTN as recorded with the agent", "The period and payments for which the certificate is needed"),
      "The withholding agent (section 164).",
      caution="A certificate whose tax isn't in the agent's section 165 statement may not be accepted in your return.",
      concept="withholding_statement"),
    # ---------------------------------------------------------------- residence and foreign tax
    C("residence", "Residence and foreign tax", "Certificate of residence (tax residency certificate)",
      "Sections 81, 82 and 107; rule 19A", "ITO",
      "Shows a foreign tax authority that you are resident in Pakistan, to claim the benefit of a tax treaty "
      "(lower foreign withholding, exemption).",
      "A Pakistani resident earning income from a treaty country.",
      ("Make sure the return for the relevant tax year is filed.",
       "In IRIS, open the application for a certificate of residence and choose the tax year and the country.",
       "Attach evidence of residence and submit.",
       "Download the certificate once issued and give it to the foreign payer or authority."),
      ("Return of income for the tax year concerned",
       "Evidence of days in Pakistan for an individual (passport entries / travel history), or of control and "
       "management in Pakistan for a company or AOP",
       "Details of the foreign income and the country and treaty concerned"),
      "Commissioner Inland Revenue (rule 19A).",
      "For the tax year stated.",
      concept="residency", verify=True),
    C("tax_paid_cert", "Residence and foreign tax", "Certificate of payment of tax in Pakistan", "Rules 19B and 51",
      "ITO",
      "Confirms tax paid in Pakistan on an income, e.g. for a foreign tax credit abroad.",
      "A person who needs proof of Pakistani tax for another country, or a payer that must evidence tax paid.",
      ("Apply to your Commissioner Inland Revenue in IRIS, stating the income, tax year and purpose.",
       "Attach evidence of the tax paid and submit."),
      ("Return of income for the tax year", "Payment slips (CPRs) and withholding certificates for the tax paid",
       "Details of the income and of the foreign authority asking for proof"),
      "Commissioner Inland Revenue.", verify=True),
    # ---------------------------------------------------------------- approvals
    C("npo", "Approvals", "Approval as a non-profit organisation (for donation credits and exemption)",
      "Sections 2(36) and 61; rules 211 to 219", "ITO",
      "Approval of a trust, welfare institution or other non-profit body, so that donors get a tax credit "
      "(section 61) and the organisation can claim its exemption.",
      "A non-profit organisation established for religious, educational, charitable, welfare or similar purposes.",
      ("Make sure the organisation is registered (e.g. as a trust or society) and has an NTN.",
       "Apply to the Commissioner Inland Revenue in IRIS under rule 211, attaching the documents below.",
       "The Commissioner decides the application (rule 212); a refusal must give reasons (rule 213).",
       "The approval is valid for the period in rule 214 and can be withdrawn if conditions are broken (rule 217).",
       "Against a refusal or withdrawal, appeal under rule 218."),
      ("Registration certificate and constitutive documents (trust deed, memorandum and articles, or rules)",
       "Audited accounts for the last three years, or since establishment",
       "Names, addresses, CNICs and NTNs of trustees or members of the governing body",
       "Details of the activities, projects and their beneficiaries", "Bank account details and statements",
       "Returns of income filed", "Any other documents rule 211 or the application form asks for"),
      "Commissioner Inland Revenue (rules 211–213).",
      "As set in rule 214.",
      "Donations must be paid through a banking channel to earn the credit (section 61).",
      "tax_credits", verify=True),
    C("funds", "Approvals", "Approval of a superannuation (provident or pension) or gratuity fund",
      "Rules 108 and 115", "ITO",
      "Approval of an employer's fund so that contributions and payments receive their tax treatment.",
      "Employers setting up a provident, pension or gratuity fund for employees.",
      ("Apply to the Commissioner Inland Revenue: rule 108 for a superannuation fund, rule 115 for a gratuity fund.",
       "Attach the trust deed and the rules of the fund, and the documents below.",
       "Answer any queries; approval may later be withdrawn in the circumstances in rules 113 and 120, with an "
       "appeal under rules 114 and 121."),
      ("Trust deed and rules of the fund", "Names of trustees", "Latest accounts of the fund",
       "List of employees covered and contribution details"),
      "Commissioner Inland Revenue.", verify=True),
    C("tcc", "Approvals", "Tax clearance certificate", "Section 145; rules 70, 221 and 222", "ITO",
      "Confirms there is no outstanding tax, e.g. for a person about to leave Pakistan without the intention of "
      "returning (section 145) or where a contract or authority asks for one.",
      "A person asked to produce tax clearance.",
      ("Clear any tax due and make sure all returns are filed.",
       "Apply to the Commissioner Inland Revenue in IRIS, stating why the certificate is needed.",
       "The certificate is issued in the form in rule 222 (section 145 cases: rule 70)."),
      ("Returns of income filed for the relevant years", "Evidence of payment of all tax due",
       "The request from the authority or contract that needs the certificate"),
      "Commissioner Inland Revenue.", verify=True),
    # ---------------------------------------------------------------- sales tax
    C("strn", "Sales tax", "Sales tax registration (STRN)", "Section 14 of the STA 1990; rules 5 and 6", "STA",
      "Registers a person for sales tax so they can charge tax, claim input tax and file monthly returns.",
      "Manufacturers (other than cottage industry), importers, wholesalers and distributors, Tier-1 retailers, and "
      "anyone else required by section 14; others may register voluntarily.",
      ("Have an NTN first (IRIS income tax registration).",
       "In IRIS, open the sales tax registration form (rule 5) and fill in the business, premises, bank account "
       "and, for a manufacturer, machinery and electricity details.",
       "Complete biometric verification of the applicant (or the directors / members) at a NADRA e-Sahulat centre.",
       "Upload GPS-tagged photographs of the business premises (and, for a manufacturer, of the machinery and the "
       "electricity meter).",
       "Submit. Registration may be granted after verification of the premises; the STRN appears in IRIS and the "
       "registration certificate can be printed."),
      ("CNIC of the applicant, or of every director / member", "NTN",
       "Bank account maintenance certificate in the business's name",
       "Proof of premises: ownership documents or rent agreement, and a recent utility bill",
       "GPS-tagged photographs of the premises (outside, inside, signboard)",
       "Manufacturers: list of machinery, and the industrial electricity and gas meter reference numbers",
       "Company: certificate of incorporation, memorandum and articles; AOP: partnership deed"),
      "Registration through IRIS, with verification by the Commissioner Inland Revenue where needed (rules 5–6). "
      "A person liable but not registered can be compulsorily registered (rule 6).",
      "Until de-registration (rule 11), suspension or blacklisting (rule 12).",
      "Supplies made while liable but unregistered still attract tax and penalties.",
      "st_registration", verify=True),
    C("st_change", "Sales tax", "Change in particulars of sales tax registration", "Rules 7 and 8 of the ST Rules 2006",
      "STA",
      "Updates the registration for a change of name, address, business activity, bank account or ownership, or "
      "transfers the registration (rule 8).",
      "A registered person whose particulars change.",
      ("In IRIS, open the modification of registration form and enter the changes.",
       "Attach evidence of the change and submit; some changes need biometric verification again.",
       "The change takes effect once accepted in IRIS."),
      ("Evidence of the change: new rent agreement and utility bill, bank certificate, Form 29 / partnership deed, "
       "etc.", "GPS-tagged photographs for a new address"),
      "Commissioner Inland Revenue (rule 7).",
      caution="Report changes promptly: rule 7 sets the time and manner.", concept="st_registration", verify=True),
    C("st_dereg", "Sales tax", "De-registration from sales tax", "Section 21 of the STA 1990; rule 11", "STA",
      "Cancels the sales tax registration of a person who has stopped business or is no longer required to be "
      "registered.",
      "A registered person who has closed the business, or whose supplies are no longer taxable.",
      ("File every sales tax return due up to the date of closure.",
       "Apply for de-registration in IRIS under rule 11.",
       "Pay any tax due, including on closing stock where required, and respond to the Commissioner's audit or "
       "enquiry.",
       "The registration is cancelled once the Commissioner is satisfied that all dues are cleared."),
      ("Application for de-registration", "Sales tax returns filed up to closure",
       "Statement of closing stock and tax on it", "Evidence that the business has closed or is no longer taxable"),
      "Commissioner Inland Revenue (rule 11).",
      caution="De-registration doesn't end liability for tax or penalties for earlier periods.",
      concept="st_registration", verify=True),
]
BY_ID = {c.id: c for c in CERTIFICATES}


def search(text: str) -> list[Certificate]:
    """Certificates whose title, purpose or law match all words of the query."""
    words = [w for w in re.findall(r"[a-z0-9]+", text.lower()) if len(w) > 2 and w not in
             ("the", "for", "how", "apply", "what", "certificate", "get", "and", "documents", "required", "procedure")]
    if not words:
        return []
    scored = []
    for c in CERTIFICATES:
        hay = f"{c.title} {c.title} {c.purpose} {c.law} {c.who} {c.id}".lower()
        hits = sum(w in hay for w in words)
        if hits:
            scored.append((hits + (2 if any(w in c.title.lower() for w in words) else 0), c))
    scored.sort(key=lambda x: -x[0])
    return [c for _, c in scored]
