"""FBR's Active Taxpayer Lists: download them, read them, and check clients against them.

FBR publishes two lists as Excel files and updates them weekly: income tax (persons who filed the return for the
latest tax year, section 181A) and sales tax (registered persons filing their sales tax returns). TaxDesk downloads
the official files and matches clients by CNIC or NTN on this computer, so no client's details are sent anywhere.
FBR's own one-by-one search pages use a CAPTCHA and have no public API, so they are offered as links only.

The lists are large (the income tax list is about 200 MB), so they are read as a stream, row by row.
"""
from __future__ import annotations

import re
import time
import urllib.request
import zipfile
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Callable, Iterator

LISTS = {
    "IT": {"title": "Income tax", "url": "https://download.fbr.gov.pk/IT/ATL_IT.xlsx",
           "page": "https://www.fbr.gov.pk/download-atl/132041", "law": "Section 181A; rule 81B"},
    "ST": {"title": "Sales tax", "url": "https://download.fbr.gov.pk/ST/ATL_ST.xlsx",
           "page": "https://fbr.gov.pk/atl-sales-tax/163223", "law": "Sales Tax Act 1990, section 14"},
}
# FBR's online checks for one person at a time (CAPTCHA-protected, opened in the browser)
ONLINE = {"Online verifications (IRIS): ATL and taxpayer profile inquiry":
          "https://iris.fbr.gov.pk/public/txp/onlineservices",
          "ATL search": "https://e.fbr.gov.pk/atlsearchutility.aspx?PID=BLcOS/IMzEf3Rn3kVI062g=="}
SMS = "Send “ATL <CNIC>” by SMS to 9966 to check one person's income tax status."
USER_AGENT = "TaxDesk (ATL download)"


def list_kind(path: Path | str) -> str:
    """"IT" or "ST" when a file is one of FBR's list files by its name (ATL_IT.xlsx, "ATL ST (3).xlsx"), else ""."""
    m = re.search(r"ATL[\s_-]*(IT|ST)\b", Path(path).stem, re.I)
    return m.group(1).upper() if m else ""


# ---------------------------------------------------------------- identifiers
def norm_cnic(value: object) -> str:
    """'35202-6303484-1' → '3520263034841'; anything that isn't 13 digits → ''."""
    d = re.sub(r"\D", "", str(value or ""))
    return d if len(d) == 13 else ""


def norm_ntn(value: object) -> str:
    """The NTN without its check digit, as FBR's lists print it before the dash: '92-2' → '0000092',
    '00000922' → '0000092', 'e392421' → 'E392421'. A 13-digit value is a CNIC, not an NTN → ''."""
    s = re.sub(r"[^A-Za-z0-9-]", "", str(value or "")).upper()
    if not s:
        return ""
    base = s.split("-")[0]
    if base.isdigit():
        if len(base) == 13:
            return ""
        if len(base) == 8 and "-" not in s:  # typed without the dash: the last digit is the check digit
            base = base[:7]
        return base.zfill(7) if len(base) <= 7 else base
    return base


def keys_for(cnic: str = "", ntn: str = "") -> set[str]:
    """Look-up keys for a client: 'C:<cnic>' and 'N:<ntn>'. An individual's NTN is often their CNIC. STRNs aren't
    used: FBR's sales tax list has no STRN column, and an old 13-digit STRN would be mistaken for a CNIC."""
    out = set()
    for v in (cnic, ntn):
        if norm_cnic(v):
            out.add("C:" + norm_cnic(v))
    if norm_ntn(ntn):
        out.add("N:" + norm_ntn(ntn))
    return out


# ---------------------------------------------------------------- reading xlsx as a stream
_ROW_END = re.compile(r"</(?:\w+:)?row>")
_CELL = re.compile(r"<(?:\w+:)?c\b([^>]*?)(?:/>|>(.*?)</(?:\w+:)?c>)", re.S)
_VALUE = re.compile(r"<(?:\w+:)?(?:v|t)(?:\s[^>]*)?>([^<]*)</(?:\w+:)?(?:v|t)>")
_REF = re.compile(r'\br="([A-Z]+)\d+"')
_TYPE = re.compile(r'\bt="(\w+)"')
_XML_ESC = {"&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&apos;": "'"}


def _unescape(s: str) -> str:
    return re.sub(r"&(?:amp|lt|gt|quot|apos);", lambda m: _XML_ESC[m.group(0)], s) if "&" in s else s


def _col(letters: str) -> int:
    n = 0
    for ch in letters:
        n = n * 26 + ord(ch) - 64
    return n - 1


def _shared_strings(z: zipfile.ZipFile) -> list[str]:
    if "xl/sharedStrings.xml" not in z.namelist():
        return []
    xml = z.read("xl/sharedStrings.xml").decode("utf-8", "replace")
    return [_unescape("".join(_VALUE.findall(si))) for si in re.findall(r"<(?:\w+:)?si>(.*?)</(?:\w+:)?si>", xml, re.S)]


def iter_rows(path: Path | str, progress: Callable[[float], None] | None = None,
              cancelled: Callable[[], bool] | None = None) -> Iterator[tuple[str, list[str]]]:
    """(sheet name, cell values) for every row of every sheet, read as a stream. Handles inline strings,
    shared strings and numbers; cells left out of a row are returned as ''."""
    with zipfile.ZipFile(path) as z:
        sst = _shared_strings(z)
        sheets = sorted((n for n in z.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml$", n)),
                        key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
        total = sum(z.getinfo(n).file_size for n in sheets) or 1
        done = 0
        for name in sheets:
            with z.open(name) as f:
                buf = ""
                while True:
                    chunk = f.read(4 << 20)
                    if cancelled and cancelled():
                        return
                    if not chunk:
                        break
                    done += len(chunk)
                    buf += chunk.decode("utf-8", "replace")
                    parts = _ROW_END.split(buf)
                    buf = parts.pop()
                    for part in parts:
                        yield name, _row_values(part, sst)
                    if progress:
                        progress(min(1.0, done / total))


def _row_values(xml: str, sst: list[str]) -> list[str]:
    values: list[str] = []
    for attrs, inner in _CELL.findall(xml):
        ref = _REF.search(attrs)
        if ref:
            idx = _col(ref.group(1))
            values.extend([""] * (idx - len(values)))
        found = _VALUE.findall(inner or "")
        text = _unescape("".join(found))
        kind = _TYPE.search(attrs)
        if kind and kind.group(1) == "s" and text.isdigit() and int(text) < len(sst):
            text = sst[int(text)]
        elif text.endswith(".0") and text[:-2].isdigit():
            text = text[:-2]
        values.append(text.strip())
    return values


def read_table(path: Path | str) -> list[dict[str, str]]:
    """A small spreadsheet (xlsx) or CSV as a list of {header: value} dicts, from its first sheet."""
    path = Path(path)
    rows: list[list[str]] = []
    if path.suffix.lower() == ".csv":
        import csv
        with path.open(newline="", encoding="utf-8-sig") as f:
            rows = [r for r in csv.reader(f)]
    else:
        first = None
        for sheet, values in iter_rows(path):
            if first is None:
                first = sheet
            if sheet != first:
                break
            rows.append(values)
    rows = [r for r in rows if any(c.strip() for c in r)]
    if not rows:
        return []
    head = [h.strip() for h in rows[0]]
    return [{head[i]: (r[i] if i < len(r) else "").strip() for i in range(len(head)) if head[i]} for r in rows[1:]]


# ---------------------------------------------------------------- matching
@dataclass
class Match:
    key: str
    name: str
    business: str
    ntn: str = ""  # as the list prints it, e.g. '1234567-8', 'E392421' or an individual's CNIC


def _columns(header: list[str]) -> dict[str, int]:
    cols: dict[str, int] = {}
    for i, h in enumerate(h.upper().replace(" ", "_") for h in header):
        if "CNIC" in h and "cnic" not in cols:
            cols["cnic"] = i
        elif ("NTN" in h or "REG" in h) and "ntn" not in cols:
            cols["ntn"] = i
        elif "BUSINESS" in h and "business" not in cols:
            cols["business"] = i
        elif "NAME" in h and "name" not in cols:
            cols["name"] = i
    return cols


def scan(path: Path | str, keys: set[str], progress: Callable[[float], None] | None = None,
         cancelled: Callable[[], bool] | None = None) -> tuple[dict[str, Match], int]:
    """The rows of an ATL file whose CNIC or NTN is one of keys, and how many persons the list has."""
    found: dict[str, Match] = {}
    cols: dict[str, int] = {}
    sheet_now, rows = None, 0
    for sheet, values in iter_rows(path, progress, cancelled):
        if sheet != sheet_now:  # each sheet starts with its own header row
            sheet_now, cols = sheet, _columns(values)
            continue
        rows += 1

        def cell(name: str) -> str:
            i = cols.get(name, -1)
            return values[i] if 0 <= i < len(values) else ""
        hits = []
        if "ntn" in cols:
            raw = cell("ntn")
            hits.append("C:" + norm_cnic(raw) if norm_cnic(raw) else "N:" + norm_ntn(raw))
        if "cnic" in cols and norm_cnic(cell("cnic")):
            hits.append("C:" + norm_cnic(cell("cnic")))
        for k in hits:
            if k in keys and k not in found:
                found[k] = Match(k, cell("name"), cell("business"), cell("ntn"))
    return found, rows


# ---------------------------------------------------------------- downloading
def remote_date(kind: str, timeout: int = 30) -> str:
    """When FBR last updated a list (ISO date), from the file's Last-Modified header; '' if unavailable."""
    req = urllib.request.Request(LISTS[kind]["url"], method="HEAD", headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        lm = r.headers.get("Last-Modified")
    return parsedate_to_datetime(lm).date().isoformat() if lm else ""


def drop_stale_part(dest: Path, hours: float = 12) -> None:
    """Before a fresh download: forget a partly downloaded list older than this, since FBR may have published a new
    file since, and resuming would join pieces of two different lists."""
    part = dest.with_suffix(dest.suffix + ".part")
    if part.exists() and time.time() - part.stat().st_mtime > hours * 3600:
        part.unlink()


def download(kind: str, dest: Path, progress: Callable[[int, int], None] | None = None,
             cancelled: Callable[[], bool] | None = None, attempts: int = 8) -> tuple[Path, str]:
    """Download a list to dest, resuming after a dropped connection (FBR's server is slow and drops large
    downloads). The file is written to dest.part and renamed when complete. Returns the file and the list's date
    (ISO, from the server's Last-Modified header, or '' when it doesn't say)."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    total = 0
    date = ""
    last_error: Exception | None = None
    for _ in range(attempts):
        have = part.stat().st_size if part.exists() else 0
        headers = {"User-Agent": USER_AGENT, **({"Range": f"bytes={have}-"} if have else {})}
        try:
            with urllib.request.urlopen(urllib.request.Request(LISTS[kind]["url"], headers=headers), timeout=60) as r:
                if have and r.status != 206:  # the server ignored the range: start again
                    have = 0
                length = int(r.headers.get("Content-Length") or 0)
                if r.headers.get("Last-Modified"):
                    date = parsedate_to_datetime(r.headers["Last-Modified"]).date().isoformat()
                total = have + length if length else total
                with part.open("ab" if have else "wb") as f:
                    while True:
                        if cancelled and cancelled():
                            raise InterruptedError("Download cancelled.")
                        chunk = r.read(256 << 10)
                        if not chunk:
                            break
                        f.write(chunk)
                        have += len(chunk)
                        if progress:
                            progress(have, total)
            if total and have < total:
                continue  # dropped part-way: resume
            part.replace(dest)
            return dest, date
        except InterruptedError:
            raise
        except Exception as e:  # noqa: BLE001 - retried, then reported
            last_error = e
    raise ConnectionError(f"Couldn't download the {LISTS[kind]['title'].lower()} list from FBR: {last_error}")
