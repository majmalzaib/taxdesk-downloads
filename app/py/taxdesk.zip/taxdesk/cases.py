"""Practice cases: a story with facts, the model return, and a checker that explains every difference."""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any

from . import income_tax, sales_tax, wealth, withholding
from .rules import money


@dataclass(frozen=True)
class Case:
    id: str
    title: str
    kind: str  # itr | str | wht
    level: str  # Beginner | Intermediate | Advanced
    tax_year: int
    facts: str
    task: str
    concepts: tuple[str, ...]
    solution: dict = field(hash=False, compare=False)
    checks: tuple[tuple[str, str], ...] = ()  # (figure key, label) compared after computing
    topic: str = ""  # one of TOPICS, for the Practice page's filter


def _itr(year: int, **parts: Any) -> dict:
    ret = income_tax.blank_return(year)
    for k, v in parts.items():
        if isinstance(v, dict) and isinstance(ret.get(k), dict):
            ret[k].update(v)
        else:
            ret[k] = v
    return ret


ITR_CHECKS = (("salary", "Income from salary"), ("business", "Income from business"),
              ("taxable_income", "Taxable income"), ("tax_on_income", "Tax on taxable income"),
              ("tax_chargeable", "Total tax chargeable"), ("tax_paid", "Tax paid / deducted"), ("balance", "Balance"))

CASES: list[Case] = [
    Case("salaried_basic", "Ayesha — a salaried employee", "itr", "Beginner", 2025,
         "Ayesha works for a private company. For Tax Year 2025 her salary certificate shows:\n"
         "• Basic salary Rs 1,800,000\n• House rent and utilities allowances Rs 540,000\n"
         "• Medical allowance Rs 180,000 (no free medical treatment is provided)\n"
         "• Tax deducted by the employer under section 149: Rs 120,000\n\nShe has no other income.",
         "Prepare her return: enter the salary, the tax deducted, and find the tax payable or refundable.",
         ("salary_income", "exemptions", "salaried_test", "slab_rates", "adjustable_tax"),
         _itr(2025, taxpayer={"name": "Ayesha"},
              salary={"basic": 1800000, "allowances": 540000, "medical_allowance": 180000},
              withholding=[{"section": "149", "amount": 120000}]), ITR_CHECKS, topic="Salary"),
    Case("salary_rent", "Bilal — salary and a rented flat", "itr", "Beginner", 2025,
         "Bilal earns basic salary Rs 2,400,000 and allowances Rs 600,000 (no medical allowance). His employer "
         "deducted Rs 400,000 under section 149.\n\nHe also rents out a flat for Rs 100,000 a month (Rs 1,200,000 a "
         "year). The tenant, a company, deducted Rs 75,000 under section 155.",
         "Prepare the return. Notice where the rent goes, the allowance it gets, and which rate table then applies.",
         ("property_income", "property_adjustments", "salaried_test", "adjustable_tax"),
         _itr(2025, taxpayer={"name": "Bilal"}, salary={"basic": 2400000, "allowances": 600000},
              property={"rent_received": 1200000},
              withholding=[{"section": "149", "amount": 400000}, {"section": "155", "amount": 75000}]),
         ITR_CHECKS + (("property", "Income from property"),), topic="Rental income"),
    Case("shopkeeper", "Kamran — a retail shop", "itr", "Intermediate", 2025,
         "Kamran runs a grocery shop as a sole proprietor.\n• Sales Rs 25,000,000; cost of goods sold Rs 20,000,000\n"
         "• Expenses in his accounts Rs 2,200,000, which include Rs 300,000 of household bills paid from the shop\n"
         "• Tax depreciation on shop fittings Rs 100,000\n• Tax collected by his suppliers under section 236H: "
         "Rs 50,000\n• Tax in the shop's electricity bills (section 235): Rs 30,000",
         "Work out business income (what isn't deductible?), the rate table and the tax payable.",
         ("business_income", "inadmissible_expenses", "depreciation", "salaried_test", "adjustable_tax"),
         _itr(2025, taxpayer={"name": "Kamran"},
              business={"turnover": 25000000, "cost_of_sales": 20000000, "expenses": 2200000, "inadmissible": 300000,
                        "depreciation": 100000},
              withholding=[{"section": "236H", "amount": 50000}, {"section": "235", "amount": 30000}]), ITR_CHECKS,
         topic="Business income"),
    Case("salary_75", "Sara — when salary isn't 75%", "itr", "Intermediate", 2025,
         "Sara's basic salary is Rs 2,000,000 (no allowances); her employer deducted Rs 100,000.\n"
         "She also tutors privately as a business: receipts Rs 1,150,000 and expenses Rs 150,000.",
         "Which rate table applies? Compare with what the tax would be if she only had her salary.",
         ("salaried_test", "slab_rates", "business_income"),
         _itr(2025, taxpayer={"name": "Sara"}, salary={"basic": 2000000},
              business={"turnover": 1150000, "expenses": 150000},
              withholding=[{"section": "149", "amount": 100000}]), ITR_CHECKS, topic="Salary"),
    Case("high_earner", "Dr Hamid — surcharge and tax credits", "itr", "Advanced", 2025,
         "Dr Hamid is a hospital consultant on a salary: basic Rs 9,000,000 and allowances Rs 3,000,000 "
         "(no medical allowance). Tax deducted under section 149: Rs 3,500,000.\n"
         "He donated Rs 1,000,000 to an approved hospital trust and paid Rs 500,000 into an approved voluntary "
         "pension fund.",
         "Apply the surcharge and both tax credits. How much does each credit save?",
         ("surcharge", "tax_credits", "average_rate", "salaried_test"),
         _itr(2025, taxpayer={"name": "Dr Hamid"}, salary={"basic": 9000000, "allowances": 3000000},
              credits={"donations": 1000000, "pension": 500000},
              withholding=[{"section": "149", "amount": 3500000}]), ITR_CHECKS + (("surcharge", "Surcharge"),
                                                                                 ("credits", "Tax credits")),
         topic="Salary"),
    Case("capital_gains", "Nadia — selling two plots", "itr", "Advanced", 2025,
         "Nadia (on the ATL) has basic salary Rs 1,500,000; tax deducted Rs 45,000.\n"
         "• Open plot A: bought 1 March 2020 for Rs 8,000,000, sold 10 April 2025 for Rs 14,000,000. The buyer's "
         "registrar collected Rs 420,000 under section 236C.\n"
         "• Plot B: bought 1 August 2024 for Rs 6,000,000, sold 1 May 2025 for Rs 8,000,000 (section 236C: "
         "Rs 240,000).",
         "Tax each gain correctly (holding period vs the new flat rate) and find the refund or payable.",
         ("capital_gains", "separate_block", "adjustable_tax"),
         _itr(2025, taxpayer={"name": "Nadia"}, salary={"basic": 1500000},
              capital_gains=[{"asset": "property", "kind": "open_plot", "acquired": "2020-03-01",
                              "disposed": "2025-04-10", "cost": 8000000, "sale": 14000000},
                             {"asset": "property", "kind": "open_plot", "acquired": "2024-08-01",
                              "disposed": "2025-05-01", "cost": 6000000, "sale": 8000000}],
              withholding=[{"section": "149", "amount": 45000}, {"section": "236C", "amount": 420000},
                           {"section": "236C", "amount": 240000}]), ITR_CHECKS + (("cg_tax", "Capital gains tax"),),
         topic="Capital gains"),
    Case("bank_dividend", "Usman — bank profit and dividends", "itr", "Intermediate", 2025,
         "Usman, retired, has no salary. His bank paid profit of Rs 800,000 and deducted Rs 120,000 (section 151). "
         "Listed companies paid him dividends of Rs 300,000 and deducted Rs 45,000 (section 150).",
         "Classify both deductions and work out whether anything is payable.",
         ("profit_on_debt", "dividend", "final_tax", "separate_block"),
         _itr(2025, taxpayer={"name": "Usman", "age": 66}, other_sources={"profit_on_debt": 800000, "dividend": 300000},
              withholding=[{"section": "151", "amount": 120000}, {"section": "150", "amount": 45000}]),
         ITR_CHECKS + (("pod_tax", "Tax on profit on debt"), ("dividend_tax", "Tax on dividend")), topic="Other income"),
    Case("wealth_gap", "Fatima — the wealth that didn't add up", "itr", "Advanced", 2025,
         "Fatima's basic salary is Rs 3,000,000; her employer deducted Rs 380,000, which is exactly her tax.\n"
         "Wealth on 30 June 2024: bank Rs 1,000,000, car Rs 2,500,000.\n"
         "Wealth on 30 June 2025: bank Rs 1,200,000, car Rs 2,500,000, and a plot bought for Rs 4,000,000.\n"
         "Household expenses for the year were Rs 920,000. Her father gave her Rs 2,500,000 by bank transfer "
         "towards the plot.",
         "Fill in the wealth statement and make the reconciliation balance. What happens if the gift is left out?",
         ("wealth_statement", "wealth_reconciliation", "unexplained_income", "personal_expenses"),
         _itr(2025, taxpayer={"name": "Fatima"}, salary={"basic": 3000000},
              withholding=[{"section": "149", "amount": 380000}],
              wealth={"assets": {"bank": {"open": 1000000, "close": 1200000}, "vehicles": {"open": 2500000, "close": 2500000},
                                 "property": {"open": 0, "close": 4000000}},
                      "liabilities": {}, "inflows": {"gifts_received": 2500000},
                      "outflows": {"personal_expenses": 920000}}),
         ITR_CHECKS + (("unreconciled", "Unreconciled amount"),), topic="Wealth statement"),
    Case("st_monthly", "Ali Textiles — a monthly sales tax return", "str", "Intermediate", 2025,
         "Ali Textiles (a registered manufacturer) for March 2025:\n"
         "• Sales to registered buyers Rs 10,000,000\n• Sales to unregistered buyers Rs 2,000,000\n"
         "• Input tax on yarn and dyes Rs 2,000,000 (all invoices in suppliers' returns)\n"
         "• Input tax on a new car for the director Rs 100,000\n• Excess input brought forward from February Rs 300,000",
         "Work out output tax, further tax, input tax adjusted, the carry-forward and the tax payable.",
         ("output_tax", "further_tax", "input_cap", "inadmissible_input", "carry_forward"),
         {"kind": "str", "tax_year": 2025, "period": "March 2025", "business": {"name": "Ali Textiles"},
          "sales": [{"description": "Registered buyers", "value": 10000000, "buyer_registered": True, "type": "taxable"},
                    {"description": "Unregistered buyers", "value": 2000000, "buyer_registered": False, "type": "taxable"}],
          "purchases": [{"description": "Yarn and dyes", "sales_tax": 2000000, "admissible": True},
                        {"description": "Director's car", "sales_tax": 100000, "admissible": False}],
          "carry_forward_in": 300000},
         (("output", "Output tax"), ("further", "Further tax"), ("input_adjusted", "Input tax adjusted"),
          ("carry_forward", "Carried forward"), ("payable", "Sales tax payable")), topic="Sales tax"),
    Case("wht_agent", "Rehman Builders — a withholding statement", "wht", "Intermediate", 2025,
         "Rehman Builders paid in the quarter:\n• Steel Traders (on ATL) Rs 2,000,000 for steel bars — goods\n"
         "• Khan Contractors (on ATL) Rs 1,000,000 for a construction contract\n"
         "• Ahmed Hardware (NOT on ATL) Rs 500,000 for fittings — goods\n\n"
         "Their accountant deducted Rs 110,000, Rs 50,000 and Rs 27,500.",
         "Prepare the section 165 statement with the tax that should have been deducted on each payment, and find "
         "the shortfalls.",
         ("withholding_agent", "withholding_statement", "atl", "inadmissible_expenses"),
         {"kind": "wht", "tax_year": 2025, "agent": {"name": "Rehman Builders", "period": "Quarter 1"},
          "rows": [{"payee": "Steel Traders", "payee_atl": True, "section": "153(1)(a)", "gross": 2000000, "deducted": 110000},
                   {"payee": "Khan Contractors", "payee_atl": True, "section": "153(1)(c)", "gross": 1000000, "deducted": 75000},
                   {"payee": "Ahmed Hardware", "payee_atl": False, "section": "153(1)(a)", "gross": 500000, "deducted": 55000}]},
         (("expected", "Tax that should be deducted"),), topic="Withholding"),
]
TOPICS = ("Salary", "Business income", "Rental income", "Capital gains", "Other income", "Wealth statement",
          "Sales tax", "Withholding")


from .practice_cases import CASES as _MORE  # noqa: E402 - those cases are built with Case, _itr and ITR_CHECKS above

CASES += _MORE
CASES.sort(key=lambda c: (TOPICS.index(c.topic), ("Beginner", "Intermediate", "Advanced").index(c.level)))
BY_ID = {c.id: c for c in CASES}


def figures(doc: dict) -> dict[str, float]:
    kind = doc.get("kind", "itr")
    if kind == "str":
        return sales_tax.compute(doc).figures
    if kind == "wht":
        return withholding.summary(withholding.check(doc))
    res = income_tax.compute(doc)
    f = dict(res.figures)
    f["unreconciled"] = wealth.reconcile(doc, res).unreconciled
    return f


@dataclass
class Feedback:
    ok: bool
    label: str
    yours: Any
    correct: Any
    hint: str = ""


def check(case: Case, doc: dict) -> list[Feedback]:
    """Compare the learner's document with the model solution: results first, then the inputs that differ."""
    out: list[Feedback] = []
    mine, model = figures(doc), figures(case.solution)
    for key, label in case.checks:
        a, b = round(mine.get(key, 0), 2), round(model.get(key, 0), 2)
        out.append(Feedback(abs(a - b) < 1, label, a, b))
    if case.kind == "wht":
        rows = {(r.get("payee", "").lower(), r.get("section")): r for r in doc.get("rows", [])}
        for r in withholding.check(case.solution):
            got = rows.get((r.payee.lower(), r.section))
            yours = float(got.get("deducted") or 0) if got else None
            out.append(Feedback(yours is not None and abs(yours - (r.expected or 0)) < 1,
                                f"{r.payee}: tax to deduct (s.{r.section})", yours, r.expected,
                                "Missing row." if got is None else ""))
        return out
    for path, a, b in _diff(_inputs(doc), _inputs(case.solution)):
        out.append(Feedback(False, f"Entry: {path}", a, b, _hint(path)))
    return out


def _inputs(doc: dict) -> dict:
    """The entries to compare: names, periods and the like are left out."""
    d = income_tax.merged(doc) if doc.get("kind", "itr") == "itr" else copy.deepcopy(doc)
    for k in ("taxpayer", "kind", "tax_year", "period", "agent"):
        d.pop(k, None)
    if doc.get("kind") == "str":
        d.pop("business", None)
        for row in d.get("purchases") or []:
            row["capital"] = row.get("capital") in (True, "yes")  # yes or no; left out is no (and "yes" from 1.7.0)
    for row in d.get("capital_gains") or []:
        if row.get("asset") == "securities":  # the type of property means nothing for shares
            row.pop("kind", None)
    return d


def _diff(a: Any, b: Any, path: str = "") -> list[tuple[str, Any, Any]]:
    if isinstance(a, dict) or isinstance(b, dict):
        a, b = a if isinstance(a, dict) else {}, b if isinstance(b, dict) else {}
        out = []
        for k in sorted(set(a) | set(b)):
            out += _diff(a.get(k), b.get(k), f"{path}.{k}" if path else str(k))
        return out
    if isinstance(a, list) or isinstance(b, list):
        a, b = a or [], b or []
        if path == "withholding":
            sa = sorted((str(x.get("section")), float(x.get("amount") or 0)) for x in a)
            sb = sorted((str(x.get("section")), float(x.get("amount") or 0)) for x in b)
            return [] if sa == sb else [(path, ", ".join(f"s.{s} {money(v)}" for s, v in sa) or "none",
                                         ", ".join(f"s.{s} {money(v)}" for s, v in sb))]
        if len(a) != len(b):
            return [(path, f"{len(a)} item(s)", f"{len(b)} item(s)")]
        out = []
        for i, (x, y) in enumerate(zip(a, b), start=1):
            out += _diff(x, y, f"{path}[{i}]")
        return out
    na, nb = _num(a), _num(b)
    if na is not None or nb is not None:
        return [] if abs((na or 0) - (nb or 0)) < 1 else [(path, na or 0, nb or 0)]
    return [] if (a or "") == (b or "") else [(path, a, b)]


def _num(v: Any) -> float | None:
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    return None


HINTS = {
    "salary.medical_allowance": "Medical allowance is entered in full; the app exempts up to 10% of basic itself.",
    "business.inadmissible": "Household bills paid from the business are personal: inadmissible under section 21.",
    "withholding": "Enter every certificate with its section: the section decides adjustable, final or minimum.",
    "wealth.inflows.gifts_received": "A documented gift is an inflow in the reconciliation, not income.",
    "property.rent_received": "Rent is income from property (section 15): a fifth is allowed for repairs (section "
                              "15A) and the rest joins taxable income.",
    "property.collection_charges": "Collection charges are allowed only up to 4% of the rent (section 15A(1)(h)).",
    "property.non_adjustable": "Enter a non-adjustable amount from a tenant in full; a tenth is taxed each year "
                               "(section 16).",
    "credits": "Donations and pension contributions are tax credits, not deductions.",
}


def _hint(path: str) -> str:
    for key, text in HINTS.items():
        if path.startswith(key):
            return text
    return ""
