"""Wealth statement (section 116) and its reconciliation.

The increase in net assets over the year must be explained by money that came in (income declared,
exempt income, gifts, inheritance...) less money that went out (personal expenses, taxes, gifts given).
Anything left unexplained can be treated as income under section 111.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .income_tax import Result, compute, merged
from .rules import money

ASSETS = [
    ("property", "Immovable property (at cost)"), ("business_capital", "Business capital"),
    ("vehicles", "Motor vehicles"), ("investments", "Shares, bonds, mutual funds, certificates"),
    ("bank", "Bank balances"), ("cash", "Cash in hand"), ("jewellery", "Jewellery"),
    ("receivables", "Loans and advances given"), ("other_assets", "Other assets"),
]
LIABILITIES = [("loans", "Loans and borrowings"), ("other_liabilities", "Other liabilities")]
INFLOWS = [
    ("exempt_income", "Exempt income not in the return (e.g. agricultural)"), ("gifts_received", "Gifts received"),
    ("inheritance", "Inheritance"), ("foreign_remittance", "Foreign remittance through banks"),
    ("gain_on_assets", "Gain on sale of assets not taxed"), ("other_inflows", "Other inflows"),
]
OUTFLOWS = [
    ("personal_expenses", "Personal and household expenses"), ("gifts_given", "Gifts given"),
    ("loss_on_assets", "Loss on sale of assets"), ("other_outflows", "Other outflows"),
]


@dataclass
class Reconciliation:
    net_open: float
    net_close: float
    increase: float
    inflows: list[tuple[str, float, str]] = field(default_factory=list)
    outflows: list[tuple[str, float, str]] = field(default_factory=list)

    @property
    def total_in(self) -> float:
        return sum(v for _, v, _ in self.inflows)

    @property
    def total_out(self) -> float:
        return sum(v for _, v, _ in self.outflows)

    @property
    def unreconciled(self) -> float:
        return round(self.increase - (self.total_in - self.total_out), 2)

    def verdict(self) -> str:
        u = self.unreconciled
        if abs(u) < 1:
            return "Reconciled: the increase in wealth is fully explained."
        if u > 0:
            return (f"Unexplained increase of {money(u)}. Wealth grew more than income allows: the officer can treat "
                    "it as income under section 111. Look for income, gifts or loans left out.")
        return (f"Wealth grew {money(-u)} less than income allows. Personal expenses or other outflows are probably "
                "understated, which can raise questions about lifestyle.")


def _n(v: Any) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _pair(section: dict, key: str) -> tuple[float, float]:
    v = section.get(key) or {}
    if isinstance(v, dict):
        return _n(v.get("open")), _n(v.get("close"))
    return 0.0, _n(v)


def reconcile(ret: dict[str, Any], result: Result | None = None) -> Reconciliation:
    ret = merged(ret)
    result = result or compute(ret)
    w = ret["wealth"]
    a_open = sum(_pair(w["assets"], k)[0] for k, _ in ASSETS)
    a_close = sum(_pair(w["assets"], k)[1] for k, _ in ASSETS)
    l_open = sum(_pair(w["liabilities"], k)[0] for k, _ in LIABILITIES)
    l_close = sum(_pair(w["liabilities"], k)[1] for k, _ in LIABILITIES)
    rec = Reconciliation(a_open - l_open, a_close - l_close, (a_close - l_close) - (a_open - l_open))
    f = result.figures
    declared = f.get("total_income", 0) + f.get("capital_gains", 0) + f.get("pod_separate", 0) + f.get("dividend", 0)
    exempt_in_return = _exempt_in_return(ret, result)
    rec.inflows.append(("Income declared in the return", declared, "Return of income"))
    if exempt_in_return:
        rec.inflows.append(("Exempt amounts within salary", exempt_in_return, "Second Schedule"))
    for key, label in INFLOWS:
        if _n(w["inflows"].get(key)):
            rec.inflows.append((label, _n(w["inflows"][key]), ""))
    rec.outflows.append(("Income tax paid / deducted", f.get("tax_paid", 0), "Taxes are a use of income"))
    for key, label in OUTFLOWS:
        if _n(w["outflows"].get(key)):
            rec.outflows.append((label, _n(w["outflows"][key]), ""))
    return rec


def _exempt_in_return(ret: dict, result: Result) -> float:
    s = ret["salary"]
    gross = _n(s["basic"]) + _n(s["allowances"]) + _n(s["medical_allowance"]) + _n(s["perquisites"])
    return max(0.0, gross - result.figures.get("salary", 0))
