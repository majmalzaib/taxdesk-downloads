"""Tax rules for each tax year, loaded from data/tyYYYY.json.

The rates live in data files rather than code so they can be checked and corrected against the
Income Tax Ordinance 2001 / Sales Tax Act 1990 (as amended by each Finance Act) without
programming. A copy in the user's data folder, when present, takes precedence over the built-in one.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

BUILTIN = Path(__file__).resolve().parent / "data"
_override_dir: Path | None = None


def set_override_dir(path: Path | None) -> None:
    """Folder holding user-edited copies of the rule files (tyYYYY.json)."""
    global _override_dir
    _override_dir = path
    _CACHE.clear()


def available_years() -> list[int]:
    years = {int(p.stem[2:]) for p in BUILTIN.glob("ty*.json")}
    if _override_dir and _override_dir.exists():
        years |= {int(p.stem[2:]) for p in _override_dir.glob("ty*.json") if p.stem[2:].isdigit()}
    return sorted(years)


_CACHE: dict[int, "Rules"] = {}


def load(year: int) -> "Rules":
    if year not in _CACHE:
        path = BUILTIN / f"ty{year}.json"
        if _override_dir and (_override_dir / f"ty{year}.json").exists():
            path = _override_dir / f"ty{year}.json"
        if not path.exists():
            raise ValueError(f"No rules for tax year {year}.")
        _CACHE[year] = Rules(json.loads(path.read_text(encoding="utf-8")), path)
    return _CACHE[year]


@dataclass
class SlabResult:
    tax: float
    row: list  # [from, to, fixed, rate]

    def explain(self, income: float) -> str:
        lo, hi, fixed, rate = self.row
        if rate == 0 and fixed == 0:
            return f"{money(income)} falls in the 0% slab (up to {money(hi)})."
        band = f"{money(lo)} – {money(hi)}" if hi else f"above {money(lo)}"
        return (f"{money(income)} falls in the {band} slab: {money(fixed)} + {rate:.1%} of the amount above "
                f"{money(lo)} ({money(income - lo)}) = {money(self.tax)}.")


class Rules:
    def __init__(self, data: dict[str, Any], path: Path):
        self.data, self.path = data, path
        self.year: int = data["tax_year"]
        self.label: str = data["label"]

    def __getitem__(self, key: str) -> Any:
        return self.data[key]

    def slab(self, name: str, income: float) -> SlabResult:
        rows = self.data["slabs"][name]["rows"]
        income = max(0.0, income)
        for row in rows:
            lo, hi, fixed, rate = row
            if hi is None or income <= hi:
                return SlabResult(round(fixed + rate * (income - lo), 2), row)
        raise ValueError("Slab table has no open-ended top row.")

    def withholding(self, section: str) -> dict:
        for w in self.data["withholding"]:
            if w["section"] == section:
                return w
        return {"section": section, "title": f"Section {section}", "nature": "adjustable", "head": "any", "rate": None}

    def holding_rate(self, table: list, years: float) -> float:
        for limit, rate in table:
            if limit is None or years <= limit:
                return rate
        return 0.0

    def verify_items(self) -> list[str]:
        """Rules marked "verify": figures to confirm against the current law before relying on them."""
        out = []

        def walk(node: Any, path: str) -> None:
            if isinstance(node, dict):
                if node.get("verify"):
                    out.append(f"{path} ({node.get('law', node.get('section', ''))})".strip())
                for k, v in node.items():
                    walk(v, f"{path}.{k}" if path else k)
            elif isinstance(node, list):
                for item in node:
                    if isinstance(item, dict) and item.get("verify"):
                        out.append(f"Withholding {item.get('section')}: {item.get('title')}")
        walk(self.data, "")
        return out


def money(v: float | None) -> str:
    if v is None:
        return "—"
    sign, v = ("−" if v < 0 else ""), abs(float(v))
    return f"{sign}Rs {v:,.0f}" if v.is_integer() else f"{sign}Rs {v:,.2f}"
