"""More practice cases, by topic: five each for salary, business income, rental income, capital gains, other income
and the wealth statement, and ten monthly sales tax returns. All for Tax Year 2025.

The model answer of each case is its solution document: the app computes every figure from it, so a case's facts must
state exactly what goes into the return, traps included (an expense that isn't allowed, a deduction that is final).
"""
from __future__ import annotations

from .cases import ITR_CHECKS, Case, _itr

SALARY, BUSINESS, RENTAL, GAINS, OTHER, WEALTH, SALES = (
    "Salary", "Business income", "Rental income", "Capital gains", "Other income", "Wealth statement", "Sales tax")
PROPERTY_CHECKS = ITR_CHECKS + (("property", "Income from property"),)
CG_CHECKS = ITR_CHECKS + (("cg_tax", "Capital gains tax"),)
WEALTH_CHECKS = ITR_CHECKS + (("unreconciled", "Unreconciled amount"),)
ST_CHECKS = (("output", "Output tax"), ("further", "Further tax"), ("input_adjusted", "Input tax adjusted"),
             ("carry_forward", "Carried forward"), ("payable", "Sales tax payable"))


def _str(name: str, period: str, sales: list, purchases: list, carry_in: float = 0) -> dict:
    return {"kind": "str", "tax_year": 2025, "period": period, "business": {"name": name},
            "sales": sales, "purchases": purchases, "carry_forward_in": carry_in}


def _sale(description: str, value: float, registered: bool = True, kind: str = "taxable", rate: float | None = None) -> dict:
    s = {"description": description, "value": value, "buyer_registered": registered, "type": kind}
    if rate is not None:
        s["rate"] = rate
    return s


def _buy(description: str, tax: float, admissible: bool = True, capital: bool = False) -> dict:
    p = {"description": description, "sales_tax": tax, "admissible": admissible}
    if capital:
        p["capital"] = True
    return p


C = Case
CASES: list[Case] = [
    # ================================================================ salary
    C("sal_perqs", "Zainab — a car and a house from the employer", "itr", "Intermediate", 2025,
      "Zainab is a bank manager. For Tax Year 2025:\n• Basic salary Rs 2,400,000; utilities allowance Rs 240,000\n"
      "• Medical allowance Rs 240,000 (no free medical treatment)\n"
      "• A bank car costing Rs 3,000,000, used for both official and private travel\n"
      "• A house provided by the bank, which would otherwise cost the bank Rs 900,000 a year in rent (there is no "
      "time scale for her basic pay)\n• Tax deducted under section 149: Rs 300,000",
      "Value the car and the house under rules 4 and 5, enter them as perquisites, and find the balance.",
      ("perquisites", "exemptions", "salary_income", "adjustable_tax"),
      _itr(2025, taxpayer={"name": "Zainab"},
           salary={"basic": 2400000, "allowances": 240000, "medical_allowance": 240000, "perquisites": 1230000},
           withholding=[{"section": "149", "amount": 300000}]), ITR_CHECKS, topic=SALARY),
    C("sal_two_jobs", "Hassan — two employers in one year", "itr", "Beginner", 2025,
      "Hassan changed jobs on 1 January 2025.\n• First employer (July to December): basic Rs 900,000, allowances "
      "Rs 300,000, tax deducted Rs 30,000\n• Second employer (January to June): basic Rs 1,200,000, allowances "
      "Rs 360,000, medical allowance Rs 120,000, tax deducted Rs 60,000",
      "Add both salaries into one return, enter both certificates, and find what is still payable.",
      ("salary_income", "exemptions", "slab_rates", "adjustable_tax"),
      _itr(2025, taxpayer={"name": "Hassan"},
           salary={"basic": 2100000, "allowances": 660000, "medical_allowance": 120000},
           withholding=[{"section": "149", "amount": 30000}, {"section": "149", "amount": 60000}]),
      ITR_CHECKS, topic=SALARY),
    C("sal_senior", "Mr Rashid — a senior citizen's salary", "itr", "Beginner", 2025,
      "Mr Rashid is 62 and works part time for a school on a basic salary of Rs 960,000 a year, with no allowances. "
      "The school deducted Rs 18,000 under section 149.",
      "Apply the senior citizen reduction and work out his refund.",
      ("tax_reductions", "slab_rates", "salaried_test", "tax_payable_refund"),
      _itr(2025, taxpayer={"name": "Mr Rashid", "age": 62}, salary={"basic": 960000},
           withholding=[{"section": "149", "amount": 18000}]), ITR_CHECKS, topic=SALARY),
    C("sal_reliefs", "Maryam — Zakat, a donation and a pension fund", "itr", "Intermediate", 2025,
      "Maryam is an engineer: basic salary Rs 3,600,000 and allowances Rs 1,200,000 (no medical allowance). Tax "
      "deducted under section 149: Rs 700,000.\n• Zakat deducted by her bank under the Zakat and Ushr Ordinance: "
      "Rs 100,000\n• Donation by cheque to an approved hospital: Rs 500,000\n• Contribution to an approved "
      "voluntary pension fund: Rs 300,000",
      "Which is a deductible allowance and which are tax credits? Work out each credit at the average rate.",
      ("deductible_allowances", "tax_credits", "average_rate", "salary_income"),
      _itr(2025, taxpayer={"name": "Maryam"}, salary={"basic": 3600000, "allowances": 1200000},
           deductions={"zakat": 100000}, credits={"donations": 500000, "pension": 300000},
           withholding=[{"section": "149", "amount": 700000}]),
      ITR_CHECKS + (("credits", "Tax credits"),), topic=SALARY),
    C("sal_tuition", "Imran — school fees and the education allowance", "itr", "Intermediate", 2025,
      "Imran is a clerk: basic salary Rs 1,100,000 and allowances Rs 200,000. His employer deducted Rs 20,000.\n"
      "He paid tuition fees of Rs 400,000 for his two children at a school with an NTN.",
      "Is he eligible for the section 60D allowance? Work out the allowance and the balance.",
      ("deductible_allowances", "slab_rates", "salary_income"),
      _itr(2025, taxpayer={"name": "Imran"}, salary={"basic": 1100000, "allowances": 200000},
           deductions={"education_fee": 400000, "children": 2},
           withholding=[{"section": "149", "amount": 20000}]), ITR_CHECKS, topic=SALARY),

    # ================================================================ business income
    C("bus_pharmacy", "Nasir — a pharmacy's inadmissible expenses", "itr", "Intermediate", 2025,
      "Nasir runs a pharmacy as a sole proprietor.\n• Sales Rs 18,000,000; cost of goods sold Rs 14,500,000\n"
      "• Expenses in the accounts Rs 2,000,000. They include: a helper's salary of Rs 40,000 a month paid in cash "
      "(Rs 480,000), a fine of Rs 25,000 for a late licence renewal, and Rs 60,000 of his family's mobile bills\n"
      "• Tax depreciation on fittings Rs 120,000\n• Tax collected by suppliers under section 236H Rs 45,000; tax in "
      "the shop's electricity bills (section 235) Rs 25,000",
      "Find the inadmissible expenses under section 21, the business income and the tax payable.",
      ("inadmissible_expenses", "business_income", "depreciation", "adjustable_tax"),
      _itr(2025, taxpayer={"name": "Nasir"},
           business={"turnover": 18000000, "cost_of_sales": 14500000, "expenses": 2000000, "inadmissible": 565000,
                     "depreciation": 120000},
           withholding=[{"section": "236H", "amount": 45000}, {"section": "235", "amount": 25000}]),
      ITR_CHECKS, topic=BUSINESS),
    C("bus_loss", "Sana — a boutique's first-year loss", "itr", "Intermediate", 2025,
      "Sana has a job (basic salary Rs 1,800,000, tax deducted Rs 120,000) and opened a boutique this year.\n"
      "• Boutique sales Rs 3,000,000; cost of goods sold Rs 2,400,000\n• Expenses Rs 900,000, all for the business\n"
      "• Tax depreciation Rs 100,000",
      "Work out the boutique's result. Can the loss reduce the tax on her salary?",
      ("loss_setoff", "business_income", "salaried_test"),
      _itr(2025, taxpayer={"name": "Sana"}, salary={"basic": 1800000},
           business={"turnover": 3000000, "cost_of_sales": 2400000, "expenses": 900000, "depreciation": 100000},
           withholding=[{"section": "149", "amount": 120000}]), ITR_CHECKS, topic=BUSINESS),
    C("bus_contractor", "Rafiq — minimum tax on a contract", "itr", "Advanced", 2025,
      "Rafiq, an individual contractor on the ATL, built a school for a company.\n• Contract receipts "
      "Rs 20,000,000; costs of the contract Rs 19,000,000; tax depreciation on machinery Rs 300,000\n"
      "• The company deducted Rs 1,500,000 under section 153(1)(c)",
      "Compare the tax on his profit with the tax deducted. Which one is his liability?",
      ("minimum_tax", "business_income", "slab_rates"),
      _itr(2025, taxpayer={"name": "Rafiq"},
           business={"turnover": 20000000, "expenses": 19000000, "depreciation": 300000},
           withholding=[{"section": "153(1)(c)", "amount": 1500000}]), ITR_CHECKS, topic=BUSINESS),
    C("bus_clinic", "Dr Saima — a private clinic and advance tax", "itr", "Intermediate", 2025,
      "Dr Saima runs a clinic.\n• Fees received Rs 9,000,000\n• Expenses Rs 4,200,000, including Rs 150,000 given to "
      "a local mosque (not an approved institution) and Rs 90,000 of fuel for her family car\n"
      "• Tax depreciation on equipment Rs 300,000\n• Advance tax paid under section 147: Rs 400,000",
      "Separate the personal items, work out the business income and the balance after advance tax.",
      ("inadmissible_expenses", "business_income", "adjustable_tax"),
      _itr(2025, taxpayer={"name": "Dr Saima"},
           business={"turnover": 9000000, "expenses": 4200000, "inadmissible": 240000, "depreciation": 300000},
           withholding=[{"section": "147", "amount": 400000}]), ITR_CHECKS, topic=BUSINESS),
    C("bus_side_shop", "Kashif — salary and a small shop", "itr", "Beginner", 2025,
      "Kashif earns basic salary Rs 2,400,000 (tax deducted Rs 230,000). He also owns a small shop: sales "
      "Rs 2,000,000, cost of goods sold Rs 1,400,000 and expenses Rs 200,000.",
      "Does the salaried rate table still apply? Compare with Sara's case.",
      ("salaried_test", "business_income", "slab_rates"),
      _itr(2025, taxpayer={"name": "Kashif"}, salary={"basic": 2400000},
           business={"turnover": 2000000, "cost_of_sales": 1400000, "expenses": 200000},
           withholding=[{"section": "149", "amount": 230000}]), ITR_CHECKS, topic=BUSINESS),

    # ================================================================ rental income
    C("rent_shop", "Mrs Khalida — a shop let to a company", "itr", "Beginner", 2025,
      "Mrs Khalida has no other income. She lets a shop to a company for Rs 150,000 a month (Rs 1,800,000 a year) "
      "and paid property tax of Rs 30,000. The company deducted Rs 135,000 under section 155.",
      "Apply the section 15A allowances, work out the income from property and the refund.",
      ("property_income", "property_adjustments", "adjustable_tax"),
      _itr(2025, taxpayer={"name": "Mrs Khalida"}, property={"rent_received": 1800000, "local_taxes": 30000},
           withholding=[{"section": "155", "amount": 135000}]), PROPERTY_CHECKS, topic=RENTAL),
    C("rent_jointly", "Asif — half of a rented plaza", "itr", "Intermediate", 2025,
      "Asif and his brother own a plaza 50:50, bought with their own money. Asif also earns basic salary "
      "Rs 2,000,000 (tax deducted Rs 120,000).\n• Total rent Rs 4,800,000; building insurance Rs 60,000; the "
      "agent's collection fee Rs 300,000\n• The tenant deducted Rs 255,000 under section 155 from Asif's half",
      "Enter the full amounts with his 50% share, apply the 4% limit on collection charges, and find which rate "
      "table applies.",
      ("co_ownership", "property_adjustments", "salaried_test", "property_income"),
      _itr(2025, taxpayer={"name": "Asif"}, salary={"basic": 2000000},
           property={"rent_received": 4800000, "co_owner_share": 50, "insurance": 60000, "collection_charges": 300000},
           withholding=[{"section": "149", "amount": 120000}, {"section": "155", "amount": 255000}]),
      PROPERTY_CHECKS, topic=RENTAL),
    C("rent_advance", "Shahid — a non-refundable advance", "itr", "Intermediate", 2025,
      "Shahid lets a building to a school for Rs 1,200,000 a year. When the lease began this year, the school also "
      "paid him Rs 600,000 that is not adjustable against rent. He pays Rs 200,000 a year of profit on the bank "
      "loan he took to build it. The school deducted Rs 135,000 under section 155, on the rent and the advance.",
      "Spread the advance under section 16, deduct the allowances, and find the refund.",
      ("property_adjustments", "property_income", "adjustable_tax"),
      _itr(2025, taxpayer={"name": "Shahid"},
           property={"rent_received": 1200000, "non_adjustable": 600000, "interest": 200000},
           withholding=[{"section": "155", "amount": 135000}]), PROPERTY_CHECKS, topic=RENTAL),
    C("rent_tips_table", "Amna — rent that changes her rate table", "itr", "Advanced", 2025,
      "Amna earns basic salary Rs 3,000,000 and allowances Rs 600,000 (tax deducted Rs 600,000). She lets a house "
      "to a company for Rs 200,000 a month; the company deducted Rs 255,000 under section 155.",
      "Add the income from property to taxable income. Is her salary still more than 75% of it?",
      ("salaried_test", "property_income", "slab_rates"),
      _itr(2025, taxpayer={"name": "Amna"}, salary={"basic": 3000000, "allowances": 600000},
           property={"rent_received": 2400000},
           withholding=[{"section": "149", "amount": 600000}, {"section": "155", "amount": 255000}]),
      PROPERTY_CHECKS, topic=RENTAL),
    C("rent_loss", "Farhan — when the mortgage exceeds the rent", "itr", "Advanced", 2025,
      "Farhan has basic salary Rs 2,000,000 (tax deducted Rs 150,000) and a small trading business with a profit "
      "of Rs 150,000 (sales Rs 1,000,000, cost of goods sold Rs 850,000).\nHe lets a new flat for Rs 600,000 a year. "
      "He paid Rs 700,000 of profit on the flat's mortgage and Rs 20,000 of property tax. The tenant is an "
      "individual who deducted no tax.",
      "Work out the property loss. What can it be set off against, and what happens to the rest?",
      ("loss_setoff", "property_adjustments", "property_income"),
      _itr(2025, taxpayer={"name": "Farhan"}, salary={"basic": 2000000},
           business={"turnover": 1000000, "cost_of_sales": 850000},
           property={"rent_received": 600000, "interest": 700000, "local_taxes": 20000},
           withholding=[{"section": "149", "amount": 150000}]), PROPERTY_CHECKS, topic=RENTAL),

    # ================================================================ capital gains
    C("cg_flat", "Rehana — a flat held for three years", "itr", "Beginner", 2025,
      "Rehana (on the ATL) bought a flat on 15 January 2022 for Rs 9,000,000 and sold it on 20 March 2025 for "
      "Rs 12,000,000. Advance tax of Rs 360,000 was collected under section 236C on the sale. She has no other "
      "income.",
      "Apply the holding-period table for flats and work out the refund.",
      ("capital_gains", "separate_block", "adjustable_tax"),
      _itr(2025, taxpayer={"name": "Rehana"},
           capital_gains=[{"asset": "property", "kind": "flat", "acquired": "2022-01-15", "disposed": "2025-03-20",
                           "cost": 9000000, "sale": 12000000}],
           withholding=[{"section": "236C", "amount": 360000}]), CG_CHECKS, topic=GAINS),
    C("cg_new_plot", "Tariq — a plot bought after 1 July 2024", "itr", "Intermediate", 2025,
      "Tariq (on the ATL) has basic salary Rs 1,500,000 (tax deducted Rs 45,000). He bought an open plot on "
      "1 September 2024 for Rs 5,000,000 and sold it on 1 June 2025 for Rs 6,500,000. Advance tax of Rs 195,000 "
      "was collected under section 236C.",
      "Which rate applies to property acquired after 30 June 2024? Find the capital gains tax and the balance.",
      ("capital_gains", "separate_block", "adjustable_tax"),
      _itr(2025, taxpayer={"name": "Tariq"}, salary={"basic": 1500000},
           capital_gains=[{"asset": "property", "kind": "open_plot", "acquired": "2024-09-01",
                           "disposed": "2025-06-01", "cost": 5000000, "sale": 6500000}],
           withholding=[{"section": "149", "amount": 45000}, {"section": "236C", "amount": 195000}]),
      CG_CHECKS, topic=GAINS),
    C("cg_not_atl", "Waqas — selling a plot while off the ATL", "itr", "Advanced", 2025,
      "Waqas is NOT on the Active Taxpayers List. He bought an open plot on 1 August 2024 for Rs 6,000,000 and sold "
      "it on 30 April 2025 for Rs 10,000,000. Advance tax of Rs 1,000,000 was collected under section 236C. He has "
      "no other income.",
      "Work out the tax for a person not on the ATL and compare it with the 15% an active taxpayer pays.",
      ("capital_gains", "atl", "slab_rates"),
      _itr(2025, taxpayer={"name": "Waqas", "atl": False},
           capital_gains=[{"asset": "property", "kind": "open_plot", "acquired": "2024-08-01",
                           "disposed": "2025-04-30", "cost": 6000000, "sale": 10000000}],
           withholding=[{"section": "236C", "amount": 1000000}]), CG_CHECKS, topic=GAINS),
    C("cg_house", "Huma — a house sold after three and a half years", "itr", "Intermediate", 2025,
      "Huma (on the ATL) bought a constructed house on 1 October 2021 for Rs 15,000,000 and sold it on 1 April 2025 "
      "for Rs 21,000,000. Advance tax of Rs 630,000 was collected under section 236C. She has no other income.",
      "Find the holding period and the rate for constructed property, then the refund.",
      ("capital_gains", "separate_block", "adjustable_tax"),
      _itr(2025, taxpayer={"name": "Huma"},
           capital_gains=[{"asset": "property", "kind": "constructed", "acquired": "2021-10-01",
                           "disposed": "2025-04-01", "cost": 15000000, "sale": 21000000}],
           withholding=[{"section": "236C", "amount": 630000}]), CG_CHECKS, topic=GAINS),
    C("cg_shares", "Bilqees — two lots of listed shares", "itr", "Intermediate", 2025,
      "Bilqees (on the ATL) sold listed shares through the stock exchange:\n• Lot 1: bought 10 August 2024 for "
      "Rs 2,000,000, sold 10 February 2025 for Rs 2,600,000\n• Lot 2: bought 5 January 2023 for Rs 1,000,000, sold "
      "1 March 2025 for Rs 1,400,000\nNo tax has been collected on the gains yet, and she has no other income.",
      "Tax each lot under section 37A: which date rule applies to each?",
      ("capital_gains", "separate_block", "tax_payable_refund"),
      _itr(2025, taxpayer={"name": "Bilqees"},
           capital_gains=[{"asset": "securities", "acquired": "2024-08-10", "disposed": "2025-02-10",
                           "cost": 2000000, "sale": 2600000},
                          {"asset": "securities", "acquired": "2023-01-05", "disposed": "2025-03-01",
                           "cost": 1000000, "sale": 1400000}]), CG_CHECKS, topic=GAINS),

    # ================================================================ other income
    C("oth_big_profit", "Saleem — bank profit above Rs 5 million", "itr", "Advanced", 2025,
      "Saleem (on the ATL) has no salary or business. His bank paid profit of Rs 6,000,000 on his deposits and "
      "deducted Rs 900,000 under section 151.",
      "Profit above the section 7B limit isn't taxed separately. Work out the tax at normal rates and the balance.",
      ("profit_on_debt", "other_sources", "slab_rates"),
      _itr(2025, taxpayer={"name": "Saleem"}, other_sources={"profit_on_debt": 6000000},
           withholding=[{"section": "151", "amount": 900000}]), ITR_CHECKS, topic=OTHER),
    C("oth_dividend_off_atl", "Shazia — dividends while off the ATL", "itr", "Intermediate", 2025,
      "Shazia is NOT on the Active Taxpayers List. Listed companies paid her dividends of Rs 400,000 and deducted "
      "Rs 120,000 under section 150. She has no other income.",
      "Find the rate for a person not on the ATL. What would she have saved by filing on time?",
      ("dividend", "atl", "final_tax"),
      _itr(2025, taxpayer={"name": "Shazia", "atl": False}, other_sources={"dividend": 400000},
           withholding=[{"section": "150", "amount": 120000}]),
      ITR_CHECKS + (("dividend_tax", "Tax on dividend"),), topic=OTHER),
    C("oth_gift", "Naveed — a cash gift from a friend", "itr", "Intermediate", 2025,
      "Naveed earns basic salary Rs 1,800,000 (tax deducted Rs 120,000). A friend, not a relative, gave him "
      "Rs 500,000 in cash.",
      "Is the gift income? Under which head, and how does it change the tax?",
      ("other_sources", "salaried_test", "slab_rates"),
      _itr(2025, taxpayer={"name": "Naveed"}, salary={"basic": 1800000}, other_sources={"other": 500000},
           withholding=[{"section": "149", "amount": 120000}]), ITR_CHECKS, topic=OTHER),
    C("oth_sublease", "Rubina — sub-letting a rented shop", "itr", "Intermediate", 2025,
      "Rubina rents a shop for Rs 900,000 a year and sub-lets it for Rs 1,200,000 a year. She also earns basic "
      "salary Rs 2,400,000 (tax deducted Rs 230,000).",
      "Sub-lease rent is not income from property. Enter the net income under the right head and find the balance.",
      ("other_sources", "salaried_test", "slab_rates"),
      _itr(2025, taxpayer={"name": "Rubina"}, salary={"basic": 2400000}, other_sources={"other": 300000},
           withholding=[{"section": "149", "amount": 230000}]), ITR_CHECKS, topic=OTHER),
    C("oth_retired_saver", "Mr Akbar — a retired saver", "itr", "Beginner", 2025,
      "Mr Akbar is 66 and on the ATL. His bank paid profit of Rs 1,200,000 and deducted Rs 180,000 under section "
      "151. A debt mutual fund paid him a dividend of Rs 200,000 and deducted Rs 50,000 under section 150.",
      "Which rates apply to the bank profit and to a debt fund's dividend? Is anything payable?",
      ("profit_on_debt", "dividend", "final_tax", "separate_block"),
      _itr(2025, taxpayer={"name": "Mr Akbar", "age": 66},
           other_sources={"profit_on_debt": 1200000, "dividend": 200000, "dividend_kind": "debt_fund"},
           withholding=[{"section": "151", "amount": 180000}, {"section": "150", "amount": 50000}]),
      ITR_CHECKS + (("pod_tax", "Tax on profit on debt"), ("dividend_tax", "Tax on dividend")), topic=OTHER),

    # ================================================================ wealth statement
    C("wl_car_loan", "Adeel — a car bought on a bank loan", "itr", "Intermediate", 2025,
      "Adeel's basic salary is Rs 2,400,000; his employer deducted Rs 230,000, which is exactly his tax.\n"
      "• 30 June 2024: bank Rs 800,000\n• 30 June 2025: bank Rs 450,000; a car bought for Rs 4,000,000; the car "
      "loan outstanding Rs 2,500,000\n• Household expenses for the year Rs 1,020,000",
      "Fill in the wealth statement with the loan as a liability, and make the reconciliation balance.",
      ("wealth_statement", "wealth_reconciliation", "personal_expenses"),
      _itr(2025, taxpayer={"name": "Adeel"}, salary={"basic": 2400000},
           withholding=[{"section": "149", "amount": 230000}],
           wealth={"assets": {"bank": {"open": 800000, "close": 450000}, "vehicles": {"open": 0, "close": 4000000}},
                   "liabilities": {"loans": {"open": 0, "close": 2500000}}, "inflows": {},
                   "outflows": {"personal_expenses": 1020000}}), WEALTH_CHECKS, topic=WEALTH),
    C("wl_inherited", "Sadia — an inherited house", "itr", "Beginner", 2025,
      "Sadia's basic salary is Rs 1,800,000; her employer deducted Rs 120,000, which is exactly her tax.\n"
      "• 30 June 2024: bank Rs 300,000\n• 30 June 2025: bank Rs 680,000, and a house worth Rs 12,000,000 she "
      "inherited from her father during the year\n• Household expenses Rs 1,300,000",
      "Where does the inheritance go? Make the reconciliation balance.",
      ("wealth_statement", "wealth_reconciliation"),
      _itr(2025, taxpayer={"name": "Sadia"}, salary={"basic": 1800000},
           withholding=[{"section": "149", "amount": 120000}],
           wealth={"assets": {"bank": {"open": 300000, "close": 680000},
                              "property": {"open": 0, "close": 12000000}},
                   "liabilities": {}, "inflows": {"inheritance": 12000000},
                   "outflows": {"personal_expenses": 1300000}}), WEALTH_CHECKS, topic=WEALTH),
    C("wl_trader", "Hina — a trader's capital, cash and jewellery", "itr", "Intermediate", 2025,
      "Hina runs a cloth shop: sales Rs 6,000,000, cost of goods sold Rs 4,000,000, expenses Rs 800,000. Tax "
      "collected under section 236H Rs 50,000 and advance tax paid under section 147 Rs 40,000.\n"
      "• 30 June 2024: business capital Rs 3,000,000, jewellery Rs 500,000, cash Rs 200,000\n"
      "• 30 June 2025: business capital Rs 3,200,000, jewellery Rs 500,000, cash Rs 350,000, bank Rs 150,000\n"
      "• Household expenses Rs 610,000",
      "Work out her business income and tax, then reconcile her wealth.",
      ("wealth_statement", "wealth_reconciliation", "business_income"),
      _itr(2025, taxpayer={"name": "Hina"},
           business={"turnover": 6000000, "cost_of_sales": 4000000, "expenses": 800000},
           withholding=[{"section": "236H", "amount": 50000}, {"section": "147", "amount": 40000}],
           wealth={"assets": {"business_capital": {"open": 3000000, "close": 3200000},
                              "jewellery": {"open": 500000, "close": 500000}, "cash": {"open": 200000, "close": 350000},
                              "bank": {"open": 0, "close": 150000}},
                   "liabilities": {}, "inflows": {}, "outflows": {"personal_expenses": 610000}}),
      WEALTH_CHECKS, topic=WEALTH),
    C("wl_remittance", "Omar — a plot his salary can't explain", "itr", "Advanced", 2025,
      "Omar's basic salary is Rs 3,600,000; his employer deducted Rs 550,000, which is exactly his tax.\n"
      "• 30 June 2024: bank Rs 2,000,000\n• 30 June 2025: bank Rs 900,000 and a plot bought for Rs 5,000,000\n"
      "• Household expenses Rs 650,000\n• His brother in Dubai sent him Rs 1,500,000 through a bank towards the plot",
      "Without the remittance the wealth statement shows an unexplained increase. Find it, then reconcile it.",
      ("wealth_reconciliation", "unexplained_income", "foreign_remittance"),
      _itr(2025, taxpayer={"name": "Omar"}, salary={"basic": 3600000},
           withholding=[{"section": "149", "amount": 550000}],
           wealth={"assets": {"bank": {"open": 2000000, "close": 900000}, "property": {"open": 0, "close": 5000000}},
                   "liabilities": {}, "inflows": {"foreign_remittance": 1500000},
                   "outflows": {"personal_expenses": 650000}}), WEALTH_CHECKS, topic=WEALTH),
    C("wl_car_sold", "Nighat — selling a car and buying shares", "itr", "Intermediate", 2025,
      "Nighat's basic salary is Rs 2,000,000; her employer deducted Rs 150,000, which is exactly her tax.\n"
      "• 30 June 2024: car Rs 3,000,000 (cost), bank Rs 500,000\n• During the year she sold the car for "
      "Rs 2,700,000 and bought listed shares for Rs 2,500,000\n• 30 June 2025: shares Rs 2,500,000, bank "
      "Rs 1,100,000\n• Household expenses Rs 1,450,000",
      "A personal car isn't a capital asset, so the loss isn't in the return. Where does it go in the reconciliation?",
      ("wealth_reconciliation", "asset_disposal", "personal_expenses"),
      _itr(2025, taxpayer={"name": "Nighat"}, salary={"basic": 2000000},
           withholding=[{"section": "149", "amount": 150000}],
           wealth={"assets": {"vehicles": {"open": 3000000, "close": 0}, "bank": {"open": 500000, "close": 1100000},
                              "investments": {"open": 0, "close": 2500000}},
                   "liabilities": {}, "inflows": {},
                   "outflows": {"loss_on_assets": 300000, "personal_expenses": 1450000}}), WEALTH_CHECKS, topic=WEALTH),

    # ================================================================ sales tax
    C("st_first_return", "Hamza Traders — a distributor's first return", "str", "Beginner", 2025,
      "Hamza Traders, a registered distributor, for January 2025:\n• Sales to registered retailers Rs 5,000,000\n"
      "• Input tax on purchases Rs 720,000, all on invoices in the suppliers' returns",
      "Work out output tax, input tax adjusted and the tax payable.",
      ("output_tax", "input_tax", "st_payable"),
      _str("Hamza Traders", "January 2025", [_sale("Registered retailers", 5000000)], [_buy("Stock", 720000)]),
      ST_CHECKS, topic=SALES),
    C("st_cap", "Bright Plastics — the 90% cap", "str", "Intermediate", 2025,
      "Bright Plastics, a registered manufacturer, for February 2025:\n• Sales to registered buyers Rs 8,000,000\n"
      "• Input tax on raw materials Rs 1,500,000",
      "How much input can be set off this month? What is carried forward?",
      ("input_cap", "carry_forward", "output_tax"),
      _str("Bright Plastics", "February 2025", [_sale("Registered buyers", 8000000)], [_buy("Raw materials", 1500000)]),
      ST_CHECKS, topic=SALES),
    C("st_exporter", "Pak Leather — an exporter", "str", "Intermediate", 2025,
      "Pak Leather for March 2025:\n• Exports Rs 20,000,000 (zero-rated)\n• Local sales to registered buyers "
      "Rs 2,000,000\n• Input tax on hides and chemicals Rs 1,800,000",
      "Apply the zero rate to exports, the 90% cap to local output, and find the excess input to claim as a refund.",
      ("output_tax", "input_cap", "carry_forward"),
      _str("Pak Leather", "March 2025", [_sale("Exports", 20000000, kind="zero"), _sale("Local sales", 2000000)],
           [_buy("Hides and chemicals", 1800000)]), ST_CHECKS, topic=SALES),
    C("st_exempt", "Green Agro — taxable and exempt supplies", "str", "Intermediate", 2025,
      "Green Agro for April 2025:\n• Taxable sales to registered buyers Rs 6,000,000\n• Exempt sales Rs 4,000,000\n"
      "• Input tax Rs 900,000 on inputs used for both kinds of supply",
      "Apportion the input tax under rule 25: how much is admissible?",
      ("exempt_supplies", "inadmissible_input", "input_tax"),
      _str("Green Agro", "April 2025", [_sale("Taxable sales", 6000000), _sale("Exempt sales", 4000000, kind="exempt")],
           [_buy("Inputs: taxable share", 540000), _buy("Inputs: exempt share", 360000, admissible=False)]),
      ST_CHECKS, topic=SALES),
    C("st_unregistered", "Sohail Electronics — sales to unregistered shops", "str", "Beginner", 2025,
      "Sohail Electronics for May 2025:\n• Sales to registered buyers Rs 3,000,000\n• Sales to unregistered shops "
      "Rs 2,000,000\n• Input tax Rs 600,000",
      "Add further tax on the unregistered sales. Can input tax be set against it?",
      ("further_tax", "output_tax", "st_payable"),
      _str("Sohail Electronics", "May 2025",
           [_sale("Registered buyers", 3000000), _sale("Unregistered shops", 2000000, registered=False)],
           [_buy("Stock", 600000)]), ST_CHECKS, topic=SALES),
    C("st_machine", "Sunrise Foods — a new machine", "str", "Advanced", 2025,
      "Sunrise Foods for June 2025:\n• Sales to registered buyers Rs 10,000,000\n• Input tax on raw materials "
      "Rs 1,700,000\n• Input tax on a new packing machine (capital goods) Rs 900,000",
      "Apply the 90% cap to raw materials and the rule for capital goods. What is carried forward?",
      ("input_cap", "carry_forward", "input_tax"),
      _str("Sunrise Foods", "June 2025", [_sale("Registered buyers", 10000000)],
           [_buy("Raw materials", 1700000), _buy("Packing machine", 900000, capital=True)]), ST_CHECKS, topic=SALES),
    C("st_inadmissible", "City Builders Supply — input that can't be claimed", "str", "Intermediate", 2025,
      "City Builders Supply for July 2024:\n• Sales to registered buyers Rs 7,000,000\n• Input tax on goods bought "
      "for resale Rs 900,000\n• Input tax on office furniture Rs 36,000\n• Input tax on an invoice from a supplier "
      "who is not an active taxpayer Rs 54,000\n• Input tax on a car for the director Rs 90,000",
      "Which input tax is inadmissible under section 8 and rule 12A? Work out the tax payable.",
      ("inadmissible_input", "input_tax", "st_payable"),
      _str("City Builders Supply", "July 2024", [_sale("Registered buyers", 7000000)],
           [_buy("Goods for resale", 900000), _buy("Office furniture", 36000, admissible=False),
            _buy("Non-active supplier's invoice", 54000, admissible=False),
            _buy("Director's car", 90000, admissible=False)]), ST_CHECKS, topic=SALES),
    C("st_carry_in", "Hilal Textiles — last month's carry-forward", "str", "Intermediate", 2025,
      "Hilal Textiles for August 2024:\n• Sales to registered buyers Rs 6,000,000\n• Input tax this month "
      "Rs 700,000\n• Excess input tax carried forward from July Rs 400,000",
      "Add the carry-forward to this month's input, apply the 90% cap and find the new carry-forward.",
      ("carry_forward", "input_cap", "st_payable"),
      _str("Hilal Textiles", "August 2024", [_sale("Registered buyers", 6000000)], [_buy("Yarn", 700000)], 400000),
      ST_CHECKS, topic=SALES),
    C("st_reduced_rate", "Medi Supplies — a reduced-rate supply", "str", "Intermediate", 2025,
      "Medi Supplies for September 2024:\n• Goods taxed at a reduced rate of 10% under the Eighth Schedule, sold to "
      "registered buyers: Rs 4,000,000 (the notification allows input tax)\n• Other goods at the standard rate, "
      "sold to registered buyers: Rs 3,000,000\n• Input tax Rs 500,000",
      "Charge each supply at its own rate and find the tax payable.",
      ("output_tax", "input_tax", "st_payable"),
      _str("Medi Supplies", "September 2024",
           [_sale("Reduced-rate goods", 4000000, rate=10), _sale("Standard-rate goods", 3000000)],
           [_buy("Stock", 500000)]), ST_CHECKS, topic=SALES),
    C("st_full_return", "Indus Steel Traders — a complete monthly return", "str", "Advanced", 2025,
      "Indus Steel Traders for October 2024:\n• Sales to registered buyers Rs 12,000,000\n• Sales to unregistered "
      "buyers Rs 3,000,000\n• Exports Rs 2,000,000 (zero-rated)\n• Input tax on steel bought for resale Rs 2,500,000\n"
      "• Input tax on a car for the owner Rs 180,000\n• Input tax on a forklift (capital goods) Rs 270,000\n"
      "• Excess input tax carried forward from September Rs 150,000",
      "Prepare the whole return: output, further tax, admissible input, the 90% cap, capital goods and the "
      "carry-forward.",
      ("output_tax", "further_tax", "inadmissible_input", "input_cap", "carry_forward"),
      _str("Indus Steel Traders", "October 2024",
           [_sale("Registered buyers", 12000000), _sale("Unregistered buyers", 3000000, registered=False),
            _sale("Exports", 2000000, kind="zero")],
           [_buy("Steel for resale", 2500000), _buy("Owner's car", 180000, admissible=False),
            _buy("Forklift", 270000, capital=True)], 150000), ST_CHECKS, topic=SALES),
]
