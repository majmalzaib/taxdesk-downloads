"""Statutory deadlines: when returns, statements and payments are due, with the law that sets each date.

Deadlines are rules ("the 18th of every month", "30 September every year"); events() turns them into dated
entries for any range, each saying which period it is for. A date that falls on a weekend is flagged: under
section 10 of the General Clauses Act 1897 an act due on a day the office is closed may be done on the next
working day. FBR also extends dates by notification from time to time, so the official notices come first.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

AREAS = ("Income tax", "Withholding", "Sales tax", "Tax year")
MONTHS = ("January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
          "November", "December")


@dataclass(frozen=True)
class Deadline:
    id: str
    area: str  # one of AREAS
    title: str
    who: str
    law: str
    detail: str
    concept: str = ""
    monthly_day: int = 0  # due on this day of every month, for the month before
    dates: tuple[tuple[int, int], ...] = ()  # (month, day) every year
    verify: bool = False


D = Deadline
DEADLINES: list[Deadline] = [
    D("return_individual", "Income tax", "Return of income and wealth statement",
      "Individuals, AOPs and companies whose tax year ends 30 June are covered by the separate company deadline below",
      "Sections 114, 116 and 118; rules 34 and 36",
      "The return for the tax year that ended on 30 June, filed in IRIS with the wealth statement and its "
      "reconciliation. Filing on time keeps you on the Active Taxpayers List.",
      "return_obligation", dates=((9, 30),)),
    D("return_company", "Income tax", "Return of income: companies",
      "Companies whose tax year ends between 1 January and 30 June", "Section 118",
      "Companies with a tax year ending between 1 January and 30 June file by 31 December; other companies file "
      "by 30 September.", "companies", dates=((12, 31),), verify=True),
    D("advance_tax", "Income tax", "Advance tax instalment",
      "Persons required to pay advance tax under section 147, e.g. on business or property income above the "
      "threshold", "Section 147",
      "Advance tax for the current tax year is paid in four quarterly instalments, worked out on the latest assessed "
      "income or the estimated income for the year. Salary is excluded.",
      "adjustable_tax", dates=((9, 25), (12, 25), (3, 25), (6, 15)), verify=True),
    D("atl", "Income tax", "Active Taxpayers List published",
      "Everyone: check you are on it", "Section 181A; rule 81B",
      "FBR publishes the Active Taxpayers List on 1 March each year, listing those who filed the return for the "
      "latest tax year. A late filer can be added on paying the ATL surcharge.",
      "atl", dates=((3, 1),)),
    D("wht_statement", "Withholding", "Quarterly withholding statement",
      "Every withholding agent: employers, companies, AOPs and others who deduct or collect tax",
      "Section 165; rule 44",
      "A statement of every payee, payment and the tax deducted or collected in the quarter, filed by the 20th of the "
      "month after the quarter ends.",
      "withholding_statement", dates=((10, 20), (1, 20), (4, 20), (7, 20)), verify=True),
    D("st_payment", "Sales tax", "Sales tax payment",
      "Registered persons", "Section 6; rule 14",
      "Sales tax for a month is paid by the 15th of the following month, using the payment slip (PSID) generated "
      "with the return.", "st_payable", monthly_day=15),
    D("st_return", "Sales tax", "Monthly sales tax return",
      "Registered persons", "Section 26; rule 18",
      "The monthly return (Annex A purchases, Annex C sales) is filed electronically by the 18th of the following "
      "month.", "st_payable", monthly_day=18),
    D("ty_end", "Tax year", "Tax year ends",
      "Everyone", "Section 74",
      "The tax year ends on 30 June and is named after the calendar year in which it ends. Gather certificates and "
      "statements for the return.", "tax_year", dates=((6, 30),)),
    D("ty_start", "Tax year", "New tax year begins",
      "Everyone", "Section 74",
      "A new tax year starts on 1 July. The Finance Act passed in June sets its rates.", "tax_year", dates=((7, 1),)),
]
BY_ID = {d.id: d for d in DEADLINES}

STANDING = [
    ("Paying withholding tax to the government", "Section 160; rule 43",
     "Tax deducted or collected is paid into the government treasury within the time set by rule 43: on the same day "
     "for the Federal or a Provincial Government, and for other agents within seven days of the end of each week "
     "ending on Sunday. Late payment makes the agent liable under section 161 and adds default surcharge under "
     "section 205."),
    ("Withholding certificates", "Section 164; rule 42",
     "Payees should receive a certificate of the tax deducted, which they use to claim the tax in their return."),
]


@dataclass(frozen=True)
class Event:
    when: date
    deadline: Deadline
    period: str  # what the deadline is for, e.g. "Tax Year 2026" or "September 2026"

    @property
    def weekend(self) -> bool:
        return self.when.weekday() >= 5

    @property
    def next_working_day(self) -> date:
        d = self.when
        while d.weekday() >= 5:
            d += timedelta(days=1)
        return d


def _period(d: Deadline, when: date) -> str:
    """Which period a dated deadline belongs to."""
    if d.monthly_day:
        prev = when.replace(day=1) - timedelta(days=1)
        return f"{MONTHS[prev.month - 1]} {prev.year}"
    year_ending = when.year + (1 if when.month >= 7 else 0)  # the tax year running on that date
    if d.id == "return_individual":
        return f"Tax Year {when.year}"
    if d.id == "return_company":
        return f"Tax year ending between January and June {when.year}"
    if d.id == "advance_tax":
        n = {9: 1, 12: 2, 3: 3, 6: 4}[when.month]
        return f"Instalment {n} of 4, Tax Year {year_ending}"
    if d.id == "wht_statement":
        start = (when.month - 4) % 12 + 1
        end_year = when.year if when.month != 1 else when.year - 1
        return f"Quarter {MONTHS[start - 1]}–{MONTHS[(start + 1) % 12]} {end_year}"
    if d.id == "atl":
        return f"Filers of Tax Year {when.year - 1}"
    if d.id == "ty_end":
        return f"Tax Year {when.year}"
    if d.id == "ty_start":
        return f"Tax Year {when.year + 1}"
    return ""


def events(start: date, end: date, areas: tuple[str, ...] = AREAS) -> list[Event]:
    """Every deadline from start to end inclusive, in date order."""
    out: list[Event] = []
    for d in DEADLINES:
        if d.area not in areas:
            continue
        for year in range(start.year, end.year + 1):
            days = [(m, d.monthly_day) for m in range(1, 13)] if d.monthly_day else list(d.dates)
            for month, day in days:
                when = date(year, month, day)
                if start <= when <= end:
                    out.append(Event(when, d, _period(d, when)))
    out.sort(key=lambda e: (e.when, AREAS.index(e.deadline.area), e.deadline.title))
    return out


def upcoming(today: date, count: int = 5, areas: tuple[str, ...] = AREAS) -> list[Event]:
    return events(today, today + timedelta(days=400), areas)[:count]


def countdown(when: date, today: date) -> str:
    n = (when - today).days
    if n == 0:
        return "today"
    if n == 1:
        return "tomorrow"
    if n > 0:
        return f"in {n} days"
    return f"{-n} day{'s' if n != -1 else ''} ago"


def ics(evts: list[Event]) -> str:
    """An iCalendar file of all-day events, for Google Calendar, Outlook or Apple Calendar."""
    def esc(text: str) -> str:
        return text.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//TaxDesk//Deadlines//EN", "CALSCALE:GREGORIAN",
             "X-WR-CALNAME:TaxDesk deadlines"]
    for e in evts:
        d = e.deadline
        lines += ["BEGIN:VEVENT", f"UID:{d.id}-{e.when:%Y%m%d}@taxdesk", f"DTSTAMP:{e.when:%Y%m%d}T000000Z",
                  f"DTSTART;VALUE=DATE:{e.when:%Y%m%d}", f"DTEND;VALUE=DATE:{e.when + timedelta(days=1):%Y%m%d}",
                  f"SUMMARY:{esc(f'{d.title} ({e.period})' if e.period else d.title)}",
                  f"DESCRIPTION:{esc(f'{d.detail} Law: {d.law}. Who: {d.who}.')}",
                  f"CATEGORIES:{esc(d.area)}", "BEGIN:VALARM", "TRIGGER:-P3D", "ACTION:DISPLAY",
                  f"DESCRIPTION:{esc(d.title)}", "END:VALARM", "END:VEVENT"]
    lines.append("END:VCALENDAR")
    return "\r\n".join(lines) + "\r\n"
