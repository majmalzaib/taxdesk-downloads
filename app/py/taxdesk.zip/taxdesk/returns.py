"""The returns as data: each return's sections in IRIS order, their fields and tables, and the worked computation of a
return. The desktop editors and the web app both build their screens from these, so the two can't drift apart."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from . import cases, income_tax, sales_tax, wealth, withholding
from .rules import money


@dataclass
class Field:
    """One entry of a form, at a path in the return ("salary.basic")."""
    path: str
    label: str
    kind: str = "money"  # money | text | int | bool | percent | choice
    law: str = ""
    concept: str = ""
    help: str = ""
    choices: tuple[tuple[str, str], ...] = ()  # (value, label)


@dataclass
class Col:
    """One column of a list of rows (capital gains, certificates, sales lines…)."""
    key: str
    header: str
    kind: str = "text"  # text | money | date | yesno | choice | percent
    choices: tuple[tuple[str, str], ...] = ()
    width: int = 0
    default: Any = None


@dataclass
class Section:
    """A section of a return: a form of fields ("form"), a list of rows kept at key ("table"), the wealth statement's
    grid ("wealth") or the reconciliation ("recon")."""
    kind: str
    name: str
    intro: str = ""
    fields: list[Field] = field(default_factory=list)
    cols: list[Col] = field(default_factory=list)
    key: str = ""
    add: str = "Add row"


F = Field
YESNO_DIV = (("general", "Listed company / general"), ("debt_fund", "Fund earning mostly profit on debt"),
             ("ipp", "Independent power producer"))


def itr_sections(rules) -> list[Section]:
    """The income tax return, as in IRIS, with the wealth statement."""
    wh_sections = tuple((w["section"], f"{w['section']} – {w['title']} ({w['nature']})") for w in rules["withholding"])
    return [
        Section("form", "Taxpayer", "Personal details. ATL status changes the rates on separate-block income.", [
            F("taxpayer.name", "Name", "text"), F("taxpayer.cnic", "CNIC / NTN", "text"),
            F("taxpayer.atl", "On the Active Taxpayers List", "bool", "Section 181A", "atl"),
            F("taxpayer.age", "Age at year end", "int", "", "tax_reductions", "Used for the senior citizen reduction.")]),
        Section("form", "Salary", "From the salary certificate. Tax deducted by the employer goes under Tax deducted "
                "(section 149).", [
            F("salary.basic", "Basic salary", law="Section 12", concept="salary_income"),
            F("salary.allowances", "Taxable allowances (house rent, utilities, others)", law="Section 12(2)(b)"),
            F("salary.medical_allowance", "Medical allowance (full amount)", law="Second Schedule, clause (139)",
              concept="exemptions", help="Enter it in full; the exempt part is worked out for you."),
            F("salary.perquisites", "Perquisites (car, accommodation...)", law="Section 13; rules 3–5",
              concept="perquisites"),
            F("salary.other_exempt", "Other exempt amounts", law="Second Schedule", concept="exemptions")]),
        Section("form", "Property", "Rent less a repairs allowance of one-fifth (worked out for you) and the expenses "
                "below is income from property, taxed with your other income. Enter amounts in full; your share is "
                "applied for you.", [
            F("property.rent_received", "Rent received / receivable", law="Section 15", concept="property_income"),
            F("property.non_adjustable", "Non-adjustable amount received from a tenant this year", law="Section 16",
              concept="property_adjustments",
              help="Enter it in full; a tenth is taxed this year and in each of the next nine."),
            F("property.co_owner_share", "Your ownership share", "percent", "Section 66", "co_ownership"),
            F("property.insurance", "Insurance of the building", law="Section 15A(1)(b)",
              concept="property_adjustments"),
            F("property.local_taxes", "Property tax and local rates", law="Section 15A(1)(c)"),
            F("property.interest", "Profit on money borrowed for the property", law="Section 15A(1)(e)"),
            F("property.collection_charges", "Administration and collection charges", law="Section 15A(1)(h)",
              help="Allowed up to 4% of the rent."),
            F("property.other_deductions", "Ground rent, legal costs, irrecoverable rent",
              law="Section 15A(1)(d), (i), (j)")]),
        Section("form", "Business", "Profit from a trade, profession or vocation.", [
            F("business.turnover", "Sales / receipts", law="Section 18", concept="business_income"),
            F("business.cost_of_sales", "Cost of sales"),
            F("business.expenses", "Expenses in the accounts", law="Section 20", concept="admissible_expenses"),
            F("business.inadmissible", "…of which inadmissible", law="Section 21", concept="inadmissible_expenses",
              help="Personal expenses, cash payments above the limit, payments without withholding, fines, capital "
                   "items."),
            F("business.depreciation", "Tax depreciation and initial allowance", law="Sections 22–23; rule 12",
              concept="depreciation")]),
        Section("table", "Capital gains", "Each disposal is taxed on its own: by holding period for assets bought "
                "before 1 July 2024, at a flat rate after. Tax collected at transfer (section 236C) goes under Tax "
                "deducted.", key="capital_gains", add="Add asset sold", cols=[
            Col("asset", "Asset", "choice", (("property", "Immovable property"), ("securities", "Securities")), 150),
            Col("kind", "Property type", "choice", (("open_plot", "Open plot"), ("constructed", "Constructed property"),
                                                    ("flat", "Flat")), 160),
            Col("acquired", "Acquired (YYYY-MM-DD)", "date", width=150),
            Col("disposed", "Disposed (YYYY-MM-DD)", "date", width=150),
            Col("cost", "Cost", "money", width=130), Col("sale", "Sale price", "money", width=130)]),
        Section("form", "Other sources", "", [
            F("other_sources.profit_on_debt", "Profit on debt (bank profit)", law="Section 7B", concept="profit_on_debt"),
            F("other_sources.dividend", "Dividend", law="Section 5", concept="dividend"),
            F("other_sources.dividend_kind", "Dividend paid by", "choice", choices=YESNO_DIV),
            F("other_sources.other", "Other income (normal rates)", law="Section 39", concept="other_sources")]),
        Section("form", "Deductible allowances", "Deducted from income before tax: they save tax at your top rate.", [
            F("deductions.zakat", "Zakat paid", law="Section 60", concept="deductible_allowances"),
            F("deductions.education_fee", "Children's tuition fees paid", law="Section 60D",
              concept="deductible_allowances"),
            F("deductions.children", "Number of children", "int")]),
        Section("form", "Tax credits", "Credits reduce the tax itself, at your average rate.", [
            F("credits.donations", "Donations to approved institutions", law="Section 61", concept="tax_credits"),
            F("credits.pension", "Contributions to an approved pension fund", law="Section 63", concept="tax_credits")]),
        Section("table", "Tax deducted / collected", "Every withholding certificate, CPR and advance tax payment. The "
                "section decides whether it is adjustable (refundable), final or minimum tax.", key="withholding",
                add="Add certificate", cols=[
            Col("section", "Section", "choice", wh_sections, 380),
            Col("amount", "Tax deducted / collected", "money", width=170),
            Col("agent", "Deducted by", width=200), Col("certificate", "Certificate / CPR no.")]),
        Section("wealth", "Wealth statement"),
        Section("recon", "Wealth reconciliation", "Inflows and outflows besides the income in this return. Income "
                "declared and tax paid are taken from the return automatically.",
                [F(f"wealth.inflows.{k}", label) for k, label in wealth.INFLOWS]
                + [F(f"wealth.outflows.{k}", label) for k, label in wealth.OUTFLOWS]),
    ]


STR_HEAD = Section("form", "Business and period", "A registered person files one return per month, by the 18th of "
                   "the following month.", [
    F("business.name", "Business name", "text"), F("business.strn", "STRN", "text"),
    F("period", "Tax period (month)", "text"),
    F("carry_forward_in", "Excess input brought forward", law="Section 10", concept="carry_forward")])
STR_SALES = Section("table", "Sales (Annex C)", "Annex C: sales during the month. Sales to unregistered buyers attract "
                    "further tax.", key="sales", add="Add sale", cols=[
    Col("description", "Description", width=220), Col("value", "Value excl. tax", "money", width=150),
    Col("buyer_registered", "Buyer registered?", "yesno", width=130),
    Col("type", "Supply", "choice", (("taxable", "Taxable"), ("zero", "Zero-rated"), ("exempt", "Exempt")), 130),
    Col("rate", "Rate % (blank = standard)", "percent")])
STR_PURCHASES = Section("table", "Purchases (Annex A)", "Annex A: purchases with sales tax invoices. Mark input tax the "
                        "law blocks (section 8) as not admissible.", key="purchases", add="Add purchase", cols=[
    Col("description", "Description", width=220), Col("value", "Value excl. tax", "money", width=150),
    Col("sales_tax", "Sales tax on invoice", "money", width=150),
    Col("admissible", "Input admissible?", "yesno", width=130),
    Col("capital", "Capital goods?", "yesno", width=110, default=False),
    Col("reason", "Reason if not")])
REGISTRATION = Section("form", "Registration check", "Does this business have to register for sales tax? (Section 14; "
                       "definitions in section 2(5AB) and 2(43A))", [
    F("kind", "Type of business", "choice", choices=(("manufacturer", "Manufacturer"), ("retailer", "Retailer"),
                                                     ("importer", "Importer"),
                                                     ("wholesaler", "Wholesaler / distributor"),
                                                     ("service", "Service provider"))),
    F("turnover", "Annual turnover"),
    F("industrial_connection", "Manufacturer: industrial gas or electricity connection", "bool"),
    F("residential", "Manufacturer: located in a residential area", "bool"),
    F("workers", "Manufacturer: number of workers", "int"),
    F("electricity", "Retailer: electricity bill, last 12 months"),
    F("chain", "Retailer: part of a national / international chain", "bool"),
    F("ac_mall", "Retailer: in an air-conditioned mall or plaza", "bool"),
    F("card_pos", "Retailer: accepts card payments (bank POS)", "bool"),
    F("wholesale_retail", "Retailer: wholesaler-cum-retailer of imported consumer goods", "bool")])


def str_sections(rules) -> list[Section]:
    """The monthly sales tax return (STR-7)."""
    return [STR_HEAD, STR_SALES, STR_PURCHASES]


WHT_HEAD = Section("form", "Withholding agent", "The person making payments and deducting tax (section 165 "
                   "statement).", [
    F("agent.name", "Withholding agent", "text", "Sections 160, 165; rules 43–44", concept="withholding_agent"),
    F("agent.ntn", "NTN", "text"), F("agent.period", "Period", "text")])


def wht_sections(rules) -> list[Section]:
    """The withholding statement (section 165)."""
    choices = tuple((w["section"], f"{w['section']} – {w['title']}") for w in rules["withholding"]
                    if w["section"] not in ("147", "149"))
    return [WHT_HEAD, Section("table", "Payments and tax deducted", "Every payment on which tax had to be withheld. "
                              "Check the payee's ATL status on the day of payment.", key="rows", add="Add payment", cols=[
        Col("payee", "Payee", width=180), Col("payee_atl", "Payee on ATL?", "yesno", width=110),
        Col("section", "Section", "choice", choices, 300), Col("gross", "Amount paid", "money", width=140),
        Col("rate", "Rate % (blank = from rules)", "percent", width=170), Col("deducted", "Tax deducted", "money")])]


SECTIONS = {"itr": itr_sections, "str": str_sections, "wht": wht_sections}
BLANK = {"itr": income_tax.blank_return, "str": sales_tax.blank_return, "wht": withholding.blank_statement}
# a step of a computation: (part, label, amount, law, note, concept, total)
STEP_ORDER = ["Salary", "Property", "Business", "Other sources", "Taxable income", "Tax on income", "Tax credits",
              "Separate block", "Tax chargeable", "Tax paid", "Balance", "Wealth reconciliation"]


def itr_steps(doc: dict, rules=None) -> tuple[list, list[str]]:
    """The worked income tax computation, with the wealth reconciliation when there's a wealth statement."""
    res = income_tax.compute(doc, rules)
    steps = [(s.part, s.label, s.amount, s.law, s.note, s.concept, s.total) for s in res.steps]
    if (doc.get("wealth") or {}).get("assets"):
        rec = wealth.reconcile(doc, res)
        steps += [("Wealth reconciliation", "Increase in net assets", rec.increase, "Section 116", "",
                   "wealth_reconciliation", False)]
        steps += [("Wealth reconciliation", label, v, law, "", "wealth_reconciliation", False)
                  for label, v, law in rec.inflows]
        steps += [("Wealth reconciliation", label, -v, law, "", "wealth_reconciliation", False)
                  for label, v, law in rec.outflows]
        steps += [("Wealth reconciliation", "Unreconciled", rec.unreconciled, "Section 111", rec.verdict(),
                   "unexplained_income", True)]
    return steps, res.warnings


def str_steps(doc: dict, rules=None) -> tuple[list, list[str]]:
    res = sales_tax.compute(doc, rules)
    return [("Sales tax return", ln.label, ln.amount, ln.law, ln.note, ln.concept, ln.total) for ln in res.lines], []


def wht_steps(doc: dict, rules=None) -> tuple[list, list[str]]:
    steps = []
    for r in withholding.check(doc, rules):
        steps.append(("Tax that should be deducted", f"{r.payee}: s.{r.section} on {money(r.gross)}",
                      r.expected or 0, f"Section {r.section}",
                      f"{r.title}; rate {r.rate:.2%} ({'ATL' if 'not on' not in r.note.lower() else 'non-ATL'}). "
                      f"Nature for the payee: {r.nature}.", "withholding_agent", False))
    return steps, []


STEPS = {"itr": itr_steps, "str": str_steps, "wht": wht_steps}


def model_steps(case: cases.Case) -> tuple[list, list[str]]:
    """The model answer's computation."""
    return STEPS[case.kind](case.solution)
