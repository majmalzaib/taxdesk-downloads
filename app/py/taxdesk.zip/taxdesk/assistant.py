"""Ask TaxDesk: a built-in tax tutor that answers from TaxDesk's own library, law index and calculators.

It works offline, with no outside service. A question is read for what it needs:
- a section or rule ("section 76", "rule 44 of the IT Rules") opens it with its rules and concepts;
- figures ("tax on a salary of Rs 3 million with Rs 250,000 deducted") are computed by the same engine as the
  returns, step by step with the law;
- rates, the attached return, lawful planning and comparisons ("difference between final and adjustable tax")
  each have their own answer;
- anything else is matched against the concept library, the question bank, the planning options and the
  headings of the Ordinance, the Act and both sets of Rules.
Every answer is Markdown with each section turned into a link the app opens (law:ACT:NUM, or a concept id).
"""
from __future__ import annotations

import html
import math
import re
from collections import Counter
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any

from . import certificates, guide, income_tax, knowledge, law, planning, quiz, rules, sales_tax, wealth, withholding
from .rules import money


def _n(v: Any) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


# ---------------------------------------------------------------- library look-ups (also used by the tests)
def run_tool(name: str, args: dict, attached: dict | None = None) -> Any:
    if name == "search_library":
        q = str(args.get("query", ""))
        concepts = [{"id": c.id, "title": c.title, "law": c.law, "summary": c.summary, "detail": c.detail,
                     "example": c.example} for c in knowledge.search(q)[:8]]
        if not concepts:  # word-by-word fallback
            words = [w for w in q.lower().split() if len(w) > 3]
            concepts = [{"id": c.id, "title": c.title, "law": c.law, "summary": c.summary}
                        for c in knowledge.CONCEPTS if any(w in f"{c.title} {c.summary} {c.detail}".lower() for w in words)][:8]
        sections = [{"law": a, "number": k, "heading": t} for a, k, t in law.search(q, limit=15)]
        return {"concepts": concepts, "sections_and_rules": sections}
    if name == "get_section":
        act, key = str(args.get("law", "ITO")), str(args.get("number", "")).strip().rstrip(".")
        entry = law.official(act, key)
        if not entry and not law.SECTIONS.get((act, key)):
            return {"error": f"{law.ACTS.get(act, act)} has no section/rule {key} in TaxDesk's index."}
        users = [c for c in knowledge.CONCEPTS
                 if (act, key) in law.cited(c.law, "STA" if c.area == "Sales tax" else "ITO")]
        return {"law": law.ACTS.get(act, act), "number": key, "heading": entry["title"] if entry else "",
                "omitted": bool(entry and entry.get("omitted")), "where": law.location(act, key),
                "note": law.SECTIONS.get((act, key), ""), "official_text": law.OFFICIAL.get(act),
                "rules_made_under_it": [{"law": a, "number": k, "heading": law.describe(a, k)}
                                        for a, k in law.related_rules(act, key)],
                "text": law.plain_text(act, key, 8000), "text_source": law.text_source(act),
                "concepts": [{"id": c.id, "title": c.title, "summary": c.summary, "detail": c.detail} for c in users]}
    if name == "compute_income_tax":
        ret = income_tax.merged({k: v for k, v in args.items()})
        res = income_tax.compute(ret)
        rec = wealth.reconcile(ret, res) if ret["wealth"].get("assets") else None
        return {"figures": res.figures, "warnings": res.warnings,
                "steps": [{"part": s.part, "item": s.label, "amount": s.amount, "law": s.law, "note": s.note}
                          for s in res.steps if s.amount or s.total or s.note],
                **({"wealth_unreconciled": rec.unreconciled, "wealth_verdict": rec.verdict()} if rec else {})}
    if name == "compute_sales_tax":
        res = sales_tax.compute({"kind": "str", **args})
        return {"figures": res.figures, "lines": [{"item": ln.label, "amount": ln.amount, "law": ln.law, "note": ln.note}
                                                  for ln in res.lines]}
    if name == "get_rates":
        year = int(args.get("tax_year") or 2025)
        if year not in rules.available_years():
            return {"error": f"TaxDesk has rates for {rules.available_years()} only."}
        r = rules.load(year)
        return {"tax_year": year, "period": r["period"], "finance_act": r["finance_act"], "rates": r.data,
                "verify": r.verify_items()}
    if name == "get_attached_document":
        if not attached:
            return {"error": "No document is attached to this chat."}
        out: dict[str, Any] = {"document": attached}
        if attached.get("kind", "itr") == "itr":
            res = income_tax.compute(attached)
            out["computed"] = {"figures": res.figures, "warnings": res.warnings}
        elif attached.get("kind") == "str":
            out["computed"] = sales_tax.compute(attached).figures
        return out
    if name == "planning_options":
        return [{"title": o.title, "category": o.category, "law": o.law, "how": o.how, "effect": o.effect,
                 "conditions": o.conditions, "caution": o.caution} for o in planning.OPTIONS]
    return {"error": f"Unknown tool {name}"}


# ---------------------------------------------------------------- links
def md_cite(text: str, act: str = "ITO") -> str:
    """Text with its law references turned into Markdown links (law:ACT:NUM) the app can open."""
    linked = law.linkify(text or "", act)
    linked = re.sub(r"<a href='([^']+)'>([^<]+)</a>", lambda m: f"[{m.group(2)}]({_url(m.group(1))})", linked)
    return html.unescape(linked)


def _url(href: str) -> str:
    """A Markdown link target; one with spaces (law:ITO:First Schedule) goes in angle brackets."""
    return f"<{href}>" if " " in href else href


def md_links(text: str) -> str:
    """Markdown answer with law references turned into markdown links the app can open."""
    return md_cite(text)


def _relation(c: knowledge.Concept, direction: str, label: str, other: str) -> str:
    """'Wealth reconciliation → a gap leads to → [Unexplained income]' or the reverse."""
    o = knowledge.BY_ID[other]
    if direction == "→":
        return f"{c.title} → *{label}* → [{o.title}]({other})"
    return f"[{o.title}]({other}) → *{label}* → {c.title}"


def _act_of(concept: knowledge.Concept) -> str:
    return "STA" if concept.area == "Sales tax" else law.act_for(concept.law)


def _official(act: str) -> str:
    return f"[Official text: {law.ACTS[act]} on FBR's website →]({law.OFFICIAL[act]})"


# ---------------------------------------------------------------- search index
_STOP = set("""a an the of to in on for and or is are was were be been it its this that these those what which who whom
how why when where do does did can could should would will shall may might must i me my we our you your he she they them
their his her there here with without by from as at about into than then so if not no yes any some all each every
please tell explain give show mean means meaning under per also more much many such one two get got have has had
up out over just like""".split())

SYNONYMS = {
    "wht": "withholding", "withheld": "withholding", "deducted": "withholding deduction", "gst": "sales tax",
    "filer": "atl active taxpayers", "nonfiler": "atl active taxpayers", "atl": "active taxpayers list",
    "ntn": "registration national tax number", "fbr": "", "iris": "return", "salaried": "salary",
    "employee": "salary", "employer": "salary withholding", "job": "salary", "pay": "salary",
    "shop": "business", "trader": "business", "profession": "business", "freelancer": "business",
    "interest": "profit debt", "bank": "profit debt", "savings": "profit debt", "rent": "property",
    "rental": "property", "landlord": "property", "tenant": "property", "plot": "property capital gain",
    "house": "property", "shares": "securities capital gain", "stock": "securities", "gain": "capital gain",
    "gains": "capital gain", "charity": "donation", "donate": "donation", "car": "vehicle", "vehicle": "vehicle",
    "refund": "refund", "late": "default surcharge penalty", "penalty": "penalty", "fine": "penalty",
    "unexplained": "unexplained income assets", "black": "unexplained", "gift": "gift wealth inflow",
    "remittance": "remittance foreign", "abroad": "foreign non resident", "overseas": "foreign non resident",
    "input": "input tax", "output": "output tax", "invoice": "invoice input", "turnover": "turnover",
    "slab": "slab rates", "slabs": "slab rates", "senior": "senior citizen reduction", "old": "senior",
    "zakat": "zakat deductible allowance", "school": "education", "fee": "education", "kids": "children",
    "aop": "association persons", "company": "companies", "partnership": "association persons",
    "evasion": "evasion avoidance", "avoid": "avoidance", "save": "planning", "reduce": "planning",
}


def _stem(w: str) -> str:
    for suf in ("ings", "ing", "ies", "es", "ed", "s"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            return w[: -len(suf)] + ("y" if suf == "ies" else "")
    return w


def _tokens(text: str, expand: bool = False) -> list[str]:
    words = re.findall(r"[a-z0-9]+", (text or "").lower())
    out = []
    for w in words:
        if w in _STOP or len(w) < 2:
            continue
        out.append(_stem(w))
        if expand and w in SYNONYMS:
            out += [_stem(x) for x in SYNONYMS[w].split()]
    return out


@dataclass
class Doc:
    kind: str  # concept | question | option | section | guide
    ref: Any
    tokens: Counter
    title: Counter


@lru_cache(maxsize=1)
def _corpus() -> tuple[list[Doc], dict[str, float]]:
    docs: list[Doc] = []
    for c in knowledge.CONCEPTS:
        body = Counter(_tokens(f"{c.summary} {c.summary} {c.detail} {c.example} {c.area}"))
        docs.append(Doc("concept", c, body, Counter(_tokens(c.title))))
    for q in quiz.QUESTIONS:
        docs.append(Doc("question", q, Counter(_tokens(f"{q.text} {' '.join(q.options)} {q.explain} {q.topic}")),
                        Counter()))
    for o in planning.OPTIONS:
        docs.append(Doc("option", o, Counter(_tokens(f"{o.how} {o.effect} {o.conditions} {o.caution} {o.category}")),
                        Counter(_tokens(o.title))))
    for act in law.ACTS:
        for e in law.index_items(act):
            if not e.get("omitted"):
                note = law.SECTIONS.get((act, e["num"]), "")
                docs.append(Doc("section", (act, e["num"], e["title"]), Counter(_tokens(note)),
                                Counter(_tokens(e["title"]))))
    for item in [*guide.TOPICS, *guide.FLOWS]:
        docs.append(Doc("guide", item, Counter(_tokens(guide.text_of(item))), Counter(_tokens(item.title))))
    df: Counter = Counter()
    for d in docs:
        df.update(set(d.tokens) | set(d.title))
    n = len(docs)
    idf = {t: math.log(1 + n / (1 + k)) for t, k in df.items()}
    return docs, idf


def search(text: str, kinds: tuple[str, ...] = ("concept", "question", "option", "section"),
           limit: int = 8) -> list[tuple[float, Doc]]:
    """Library entries ranked by how well they match the words of a question (titles count most)."""
    docs, idf = _corpus()
    q = _tokens(text, expand=True)
    if not q:
        return []
    qset = set(q)
    plain = " ".join(_tokens(text))
    scored = []
    for d in docs:
        if d.kind not in kinds:
            continue
        s = 0.0
        for t in qset:
            w = idf.get(t, 0)
            if t in d.title:
                s += 3.0 * w
            if t in d.tokens:
                s += w * (1 + math.log(d.tokens[t])) / (1 + 0.02 * sum(d.tokens.values()))
        title_words = list(d.title)
        if title_words and plain and " ".join(title_words) in plain:
            s += 4.0  # the whole title appears in the question
        if s > 0:
            scored.append((s, d))
    scored.sort(key=lambda x: -x[0])
    return scored[:limit]


# ---------------------------------------------------------------- reading figures out of a question
_AMOUNT = re.compile(
    r"(?<![\w.])(?:rs\.?|pkr|rupees)?\s*(\d{1,3}(?:,\d{2,3})+(?:\.\d+)?|\d+(?:\.\d+)?)\s*"
    r"(million|mn|m|lakhs?|lacs?|k|thousand|crores?|cr|%|percent)?(?![\w])", re.I)
_UNITS = {"million": 1e6, "mn": 1e6, "m": 1e6, "lakh": 1e5, "lakhs": 1e5, "lac": 1e5, "lacs": 1e5, "k": 1e3,
          "thousand": 1e3, "crore": 1e7, "crores": 1e7, "cr": 1e7}
_SECTION_BEFORE = re.compile(r"(?:section|sec\.?|s\.|rule|clause|para|part|division|schedule|year|ty|age|aged)\s*$", re.I)
_WHT_AFTER = re.compile(r"^\W*(?:was\s+|has\s+been\s+|is\s+)?(?:tax\s+)?(?:deducted|withheld|collected|"
                        r"cut|paid\s+as\s+(?:advance\s+)?tax|as\s+(?:withholding|advance)\s+tax|wht)", re.I)
_WHT_SEC = re.compile(r"(?:section|s\.)\s*(\d+[A-Z]{0,3}(?:\(\d+\)(?:\([a-z]\))?)?)", re.I)

# (pattern, field) in order of priority; field "wht" means tax already deducted or collected
INCOME_FIELDS: list[tuple[str, str]] = [
    (r"medical(?: allowance)?", "salary.medical_allowance"),
    (r"perquisite|perk|benefit", "salary.perquisites"),
    (r"allowance", "salary.allowances"),
    (r"deduct|withh|withholding|collected|tax paid|advance tax|wht", "wht"),
    (r"profit on debt|bank profit|interest|profit from (?:the )?bank|savings|deposit|tdr|(?<!business )profit of",
     "other_sources.profit_on_debt"),
    (r"dividend", "other_sources.dividend"),
    (r"donat|charit", "credits.donations"),
    (r"pension fund|vps|pension contribution|contribut", "credits.pension"),
    (r"zakat", "deductions.zakat"),
    (r"school|tuition|education", "deductions.education_fee"),
    (r"\brent", "property.rent_received"),
    (r"cost of (?:sales|goods)|cogs|purchases", "business.cost_of_sales"),
    (r"inadmissible|household|personal", "business.inadmissible"),
    (r"depreciation", "business.depreciation"),
    (r"expense", "business.expenses"),
    (r"turnover|sales|receipts|revenue|business|shop|fees? (?:earned|received)", "business.turnover"),
    (r"salary|salaried|basic|\bpay\b|wage|earn|income", "salary.basic"),
]
def _wht_section(text: str) -> str:
    t = text.lower()
    return ("151" if re.search(r"bank|profit|interest", t) else "150" if "dividend" in t else
            "155" if re.search(r"rent|tenant", t) else "236H" if "supplier" in t else
            "149" if re.search(r"employer|salary", t) else "")


WHT_FOR = {"other_sources.profit_on_debt": "151", "other_sources.dividend": "150", "property.rent_received": "155"}
SALES_FIELDS: list[tuple[str, str]] = [
    (r"brought forward|carried forward|carry[- ]forward|b/f|previous month", "carry_forward_in"),
    (r"input", "input"),
    (r"purchase", "input_purchases"),
    (r"unregistered|non-registered|not registered", "sale_unregistered"),
    (r"zero[- ]rated|export", "sale_zero"),
    (r"exempt", "sale_exempt"),
    (r"sale|suppl|turnover", "sale"),
]


@dataclass
class Amount:
    value: float
    start: int
    end: int
    before: str = ""
    after: str = ""


def amounts(text: str) -> list[Amount]:
    """Rupee amounts in a question with the words around each, leaving out years, ages, percentages and sections."""
    out: list[Amount] = []
    for m in _AMOUNT.finditer(text):
        raw, unit = m.group(1), (m.group(2) or "").lower()
        if unit in ("%", "percent") or _SECTION_BEFORE.search(text[: m.start()]):
            continue
        value = float(raw.replace(",", "")) * _UNITS.get(unit, 1)
        has_rs = bool(re.match(r"\s*(?:rs|pkr|rupees)", m.group(0), re.I))
        if not unit and not has_rs and "," not in raw and (value < 1000 or 1990 <= value <= 2100):
            continue  # a count, an age or a year, not money
        out.append(Amount(value, m.start(), m.end()))
    for i, a in enumerate(out):
        a.before = text[(out[i - 1].end if i else max(0, a.start - 60)): a.start][-60:]
        a.after = text[a.end: (out[i + 1].start if i + 1 < len(out) else a.end + 60)][:60]
    return out


def _field_for(a: Amount, table: list[tuple[str, str]]) -> str:
    if table is INCOME_FIELDS and _WHT_AFTER.search(a.after):
        return "wht"
    best, best_pos = "", -1
    for pat, fld in table:  # the keyword nearest before the amount; on a tie the more specific (earlier) one
        for m in re.finditer(pat, a.before, re.I):
            if m.end() > best_pos:
                best, best_pos = fld, m.end()
    if best:
        return best
    for pat, fld in table:  # otherwise the first keyword after it
        if re.search(pat, a.after[:40], re.I):
            return fld
    return ""


def _monthly(a: Amount) -> bool:
    return bool(re.match(r"\W*(?:a|per|each|every)\s+month|\W*monthly|\W*/\s*month|\W*p\.?m\b", a.after, re.I))


def tax_year(text: str, default: int) -> int:
    years = rules.available_years()
    m = re.search(r"\b(20\d\d)\s*[-–/]\s*(\d\d)\b", text)  # "2025-26" is Tax Year 2026
    if m and 2000 + int(m.group(2)) in years:
        return 2000 + int(m.group(2))
    for y in re.findall(r"\b(?:ty|tax year)?\s*(20\d\d)\b", text, re.I):
        if int(y) in years:
            return int(y)
    return default


def parse_income(text: str, year: int) -> tuple[dict, list[str]]:
    """A return built from the figures in a question, and the assumptions made in reading it."""
    ret = income_tax.blank_return(year)
    notes: list[str] = []
    low = text.lower()
    if re.search(r"non[- ]?filer|not on (?:the )?atl|non[- ]?atl|not (?:a )?filer", low):
        ret["taxpayer"]["atl"] = False
        notes.append("not on the Active Taxpayers List")
    m = re.search(r"(?:aged?|age of)\s*(\d{2})|(\d{2})\s*(?:years? old|-year-old)", low)
    if m:
        ret["taxpayer"]["age"] = int(m.group(1) or m.group(2))
    elif "senior citizen" in low:
        ret["taxpayer"]["age"] = 60
    m = re.search(r"(\d+)\s+(?:children|kids|child)", low)
    if m:
        ret["deductions"]["children"] = int(m.group(1))
    previous = ""  # the income just before, which a deduction mentioned next usually belongs to
    for a in amounts(text):
        fld = _field_for(a, INCOME_FIELDS)
        value = a.value * (12 if _monthly(a) else 1)
        if _monthly(a):
            notes.append(f"{money(a.value)} a month taken as {money(value)} a year")
        if fld == "wht":
            sec = _WHT_SEC.search(a.after) or _WHT_SEC.search(a.before)
            section = sec.group(1) if sec else (_wht_section(a.before) or WHT_FOR.get(previous)
                                                or _wht_section(a.after) or "149")
            ret["withholding"].append({"section": section, "amount": value})
            continue
        if fld == "salary.basic" and "income" in a.before.lower() and "salar" not in low and re.search(
                r"business|shop|trade|profession|freelanc", low):
            fld = "business.turnover"
        if not fld:
            fld = "salary.basic" if not ret["salary"]["basic"] else ""
            if fld:
                notes.append(f"{money(value)} taken as salary")
        if fld:
            head, key = fld.split(".")
            ret[head][key] = _n(ret[head][key]) + value
            previous = fld
    return ret, notes


def parse_sales(text: str, year: int) -> dict:
    doc = sales_tax.blank_return(year)
    doc.setdefault("sales", [])
    doc.setdefault("purchases", [])
    for a in amounts(text):
        fld = _field_for(a, SALES_FIELDS)
        ctx = f"{a.before} {a.after}".lower()
        if fld == "carry_forward_in":
            doc["carry_forward_in"] = a.value
        elif fld in ("input", "input_purchases"):
            tax = a.value if fld == "input" else a.value * rules.load(year)["sales_tax"]["standard_rate"]
            doc["purchases"].append({"description": "Purchases", "sales_tax": tax,
                                     "admissible": not re.search(r"inadmissible|car|vehicle|personal", ctx)})
        elif fld.startswith("sale"):
            doc["sales"].append({"description": "Sales", "value": a.value, "buyer_registered": fld != "sale_unregistered",
                                 "type": {"sale_zero": "zero", "sale_exempt": "exempt"}.get(fld, "taxable")})
    return doc


# ---------------------------------------------------------------- the bot
GREETING = re.compile(r"^\s*(hi|hello|hey|salam|assalam[ou]* ?alaikum|aoa|good (morning|afternoon|evening))\b", re.I)
HELP = re.compile(r"what can you do|how (do|can) (i|you) use|^\s*help\s*$|who are you", re.I)
THANKS = re.compile(r"^\s*(thanks|thank you|thx|jazak)", re.I)
EVASION = re.compile(r"hide (my )?(income|money|sales)|fake (invoice|expense|receipt|bill)|flying invoice|"
                     r"under[- ]?report|evade|evasion trick|avoid (being )?(caught|detected|detection)|"
                     r"not declare|without (paying|showing)|cash to avoid|benami|launder", re.I)
COMPUTE = re.compile(r"\b(comput|calculat|work out|how much|tax on|tax for|tax payable|my tax|liability|"
                     r"what (is|will be) (the|my) tax|refund)", re.I)
SALES_WORDS = re.compile(r"sales tax|input tax|output tax|\bgst\b|further tax|sales tax return", re.I)
RATES = re.compile(r"\b(rates?|slabs?|thresholds?|tax table)\b", re.I)
CERTIFICATE = re.compile(r"certificat|\bapply\b|application|documents? (?:required|needed)|procedure|"
                         r"\bapproval\b|register|registration|\bstrn\b|de-?registration|tax clearance", re.I)
PLANNING = re.compile(r"\b(save|saving|reduce|lower|minimi[sz]e|plan(ning)?|lawful(ly)?|legally)\b.*\btax|"
                      r"tax planning|tax[- ]saving", re.I)
DOC = re.compile(r"\b(my|attached|this) (return|computation|document|statement|wealth|figures|sales tax return)|"
                 r"explain (it|my)|check my|review my", re.I)
COMPARE = re.compile(r"difference between (.+?) and (.+?)[?.!]*$|(.+?) (?:vs\.?|versus|compared (?:to|with)) (.+?)[?.!]*$",
                     re.I)
MORE = re.compile(r"^\s*(more|tell me more|explain more|go on|example\??|give (me )?an example|why\??|"
                  r"and\??|elaborate|details?)\s*[.?!]*\s*$", re.I)
SECTION_REF = re.compile(r"\b(?:section|sec\.?|s\.|rule|r\.)\s*\d", re.I)

VERIFY_NOTE = ("*Rates and thresholds come from TaxDesk's rule file for the year; figures marked “verify” on "
               "“Rules & rates” should be checked against the current Finance Act.*")


# questions to start with, offered as buttons
SUGGESTIONS = [
    "What does section 76 say about the cost of an asset?",
    "Tax for Tax Year 2026 on a salary of Rs 3,000,000 with Rs 250,000 deducted by the employer",
    "How does the 90% limit on input tax work?",
    "Difference between final tax and adjustable tax",
    "Sales tax on sales of Rs 5 million with input tax of Rs 600,000",
    "How can I lawfully reduce my tax?",
]


@dataclass
class Bot:
    year: int = 2025
    attached: dict | None = None
    last: Any = None  # the last concept answered, for follow-ups like "example?"
    history: list[tuple[str, str]] = field(default_factory=list)

    def ask(self, question: str) -> str:
        answer = self.answer(question)
        self.history.append((question, answer))
        return answer

    # ------------------------------------------------------------ routing
    def answer(self, question: str) -> str:
        q = (question or "").strip()
        if not q:
            return "Ask me about a section, a concept, rates, or give me figures to compute."
        if THANKS.match(q) and len(q) < 40:
            return "You're welcome. Ask another question whenever you like."
        if (GREETING.match(q) and len(q) < 40) or HELP.search(q):
            return self.help_text()
        if EVASION.search(q):
            return self.refuse_evasion()
        if self.attached and DOC.search(q):
            return self.explain_document(self.attached)
        if MORE.match(q) and isinstance(self.last, knowledge.Concept):
            return self.concept_more(self.last)
        year = tax_year(q, self.year)
        found = amounts(q)
        if found and (SALES_WORDS.search(q) and (COMPUTE.search(q) or len(found) > 1)):
            return self.compute_sales(q, year)
        if found and (COMPUTE.search(q) or re.search(r"salary|rent|dividend|profit|turnover|earn", q, re.I)):
            return self.compute_income(q, year)
        if RATES.search(q) and not re.search(r"average rate|effective rate", q, re.I):
            rates = self.rates(q, year)
            if rates:
                return rates
        if CERTIFICATE.search(q):
            found = certificates.search(q)
            if found:
                return self.certificate(found[0], found[1:3])
        refs = self.section_refs(q)
        if refs:
            out = [self.section(a, k) for a, k in refs[:3]]
            if len(refs) > 3:
                out.append("Also mentioned: " + ", ".join(f"[{k}]({_url(f'law:{a}:{k}')})" for a, k in refs[3:]))
            return "\n\n---\n\n".join(out)
        if PLANNING.search(q):
            return self.planning(q)
        m = COMPARE.search(q)
        if m:
            a, b = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
            compared = self.compare(a, b)
            if compared:
                return compared
        if self.attached and re.search(r"\b(my|this)\b", q, re.I) and not search(q, ("concept",), 1):
            return self.explain_document(self.attached)
        return self.library(q)

    # ------------------------------------------------------------ answers
    def help_text(self) -> str:
        return ("**Assalam-o-Alaikum! I'm TaxDesk's built-in tax tutor.** I work offline and answer from TaxDesk's own "
                "library of the Income Tax Ordinance 2001, Income Tax Rules 2002, Sales Tax Act 1990 and Sales Tax "
                "Rules 2006, and from its calculators. Try:\n\n"
                "- **A section or rule:** “What is section 111?”, “rule 44”, “section 8B of the STA”\n"
                "- **A concept:** “What is final tax?”, “How does the 90% input limit work?”\n"
                "- **A comparison:** “Difference between final tax and adjustable tax”\n"
                "- **A computation:** “Tax on a salary of Rs 250,000 a month with Rs 300,000 deducted, Tax Year 2026”, "
                "or “Sales tax on sales of Rs 5 million with input tax of Rs 600,000”\n"
                "- **Rates:** “Salaried slab rates for 2026”, “rate under section 153(1)(a)”\n"
                "- **Planning:** “How can I lawfully reduce my tax?”\n"
                "- **Your return:** attach one at the top and ask “Explain my computation”\n\n"
                "Every section I mention is a link: click it to read the section card, the rules under it and FBR's "
                "official text.")

    def refuse_evasion(self) -> str:
        c = knowledge.BY_ID["avoidance_vs_evasion"]
        return ("**I can't help with hiding income, fake invoices or expenses, or avoiding detection.** That is tax "
                "evasion, not planning, and the law deals with it firmly:\n\n"
                f"- {md_cite('Section 111')}: unexplained income or assets are added to income.\n"
                f"- {md_cite('Section 109')}: arrangements without real substance can be disregarded.\n"
                f"- {md_cite('Section 192')}: false statements can be prosecuted; for sales tax, see "
                f"{md_cite('section 33 of the STA 1990')} (penalties).\n\n"
                f"**What the law does allow:** {c.summary} Ask “how can I lawfully reduce my tax?” to see the "
                f"options, or open [{c.title}]({c.id}).")

    def section_refs(self, q: str) -> list[tuple[str, str]]:
        default = "STA" if SALES_WORDS.search(q) or re.search(r"\bsta\b|sales tax act", q, re.I) else "ITO"
        refs: list[tuple[str, str]] = []
        for m in re.finditer(r"href='law:(\w+):([^']+)'", law.linkify(q, default)):
            ref = (m.group(1), m.group(2))
            if ref not in refs:
                refs.append(ref)
        return refs

    def section(self, act: str, key: str) -> str:
        entry = law.official(act, key)
        note = law.SECTIONS.get((act, key), "")
        kind = key if "Schedule" in key else (f"Rule {key}" if act in ("ITR", "STR") else f"Section {key}")
        if not entry and not note:
            near = law.search(key, limit=5)
            return (f"**{kind} isn't in TaxDesk's index of the {law.ACTS[act]}.** Check the number, or read the "
                    f"official text. {_official(act)}"
                    + ("\n\nDid you mean: " + ", ".join(f"[{a} {k}](law:{a}:{k}) {t}" for a, k, t in near) if near else ""))
        out = [f"### [{kind}]({_url(f'law:{act}:{key}')}){': ' + entry['title'] if entry else ''} · {law.ABBR[act]}"]
        where = law.location(act, key)
        if where:
            out.append(f"*{law.ACTS[act]} › {where}*")
        if entry and entry.get("omitted"):
            out.append("**This provision has been omitted from the law.**")
        if note and (not entry or note != entry["title"]):
            out.append(f"**In short:** {md_cite(note, act)}")
        wording = re.sub(r"⁽\d+⁾", "", law.plain_text(act, key, 600))
        if wording:
            quoted = "\n>\n".join("> " + re.sub(r"([\\`*_\[\]])", r"\\\1", ln) for ln in wording.splitlines())
            out.append(f"**The law says:**\n\n{quoted}\n\n[Read the full text and its amendment notes →]"
                       f"({_url(f'law:{act}:{key}')})")
        concepts = [c for c in knowledge.CONCEPTS if (act, key) in law.cited(c.law, _act_of(c))]
        if concepts:
            main = min(concepts, key=lambda c: len(law.cited(c.law, _act_of(c))))  # the most specific concept
            out.append(f"**How it works:** {md_cite(main.detail or main.summary, _act_of(main))}")
            if main.example:
                out.append(f"**Example:** {main.example}")
            self.last = main
            out.append("**Concepts built on it:** " + "; ".join(f"[{c.title}]({c.id})" for c in concepts[:6]))
        rel = law.related_rules(act, key)
        if rel:
            out.append("**Rules made under it:** " + "; ".join(
                f"[rule {k}](law:{a}:{k}) of the {law.ABBR[a]}: {law.describe(a, k)}" for a, k in rel))
        parents = [sec for sec, rs in law.SECTION_RULES.items() if (act, key) in rs]
        if parents:
            out.append("**Made under:** " + "; ".join(f"[section {k}](law:{a}:{k}) of the {law.ABBR[a]}: "
                                                      f"{law.describe(a, k)}" for a, k in parents))
        qs = [q for q in quiz.QUESTIONS if (act, key) in law.cited(q.law, "STA" if q.topic == "Sales tax" else "ITO")]
        if qs:
            out.append(self._quiz_block(qs[0]))
        out.append(_official(act))
        return "\n\n".join(out)

    def _quiz_block(self, q: quiz.Question) -> str:
        act = "STA" if q.topic == "Sales tax" else "ITO"
        return (f"**Test yourself:** {q.text}\n\n> **Answer:** {quiz.answer_text(q)}. "
                f"{md_cite(q.explain, act)}")

    def concept(self, c: knowledge.Concept, brief: bool = False) -> str:
        act = _act_of(c)
        self.last = c
        out = [f"### [{c.title}]({c.id})", f"**The law:** {md_cite(c.law, act)} · {law.ABBR[act] if act in law.ABBR else ''}",
               f"**{c.summary}**"]
        if not brief:
            out.append(md_cite(c.detail, act))
            if c.example:
                out.append(f"**Example:** {c.example}")
            rel = [_relation(c, d, label, o) for d, label, o in knowledge.related(c.id)[:6] if o in knowledge.BY_ID]
            if rel:
                out.append("**Related:**\n" + "\n".join(f"- {r}" for r in rel))
            refs = sorted(law.cited(c.law, act))
            if refs:
                out.append(_official(refs[0][0]))
        return "\n\n".join(out)

    def concept_more(self, c: knowledge.Concept) -> str:
        act = _act_of(c)
        out = [f"### More on [{c.title}]({c.id})"]
        if c.example:
            out.append(f"**Example:** {c.example}")
        qs = [q for q in quiz.QUESTIONS if q.concept == c.id]
        for q in qs[:2]:
            out.append(self._quiz_block(q))
        for d, label, o in knowledge.related(c.id)[:3]:
            other = knowledge.BY_ID.get(o)
            if other:
                out.append(f"{_relation(c, d, label, o)}: {md_cite(other.summary, _act_of(other))}")
        refs = sorted(law.cited(c.law, act))
        if refs:
            out.append("**Read the law:** " + ", ".join(f"[{k}]({_url(f'law:{a}:{k}')})" for a, k in refs[:6]) + " · "
                       + _official(refs[0][0]))
        if len(out) == 1:
            out.append(md_cite(c.detail, act))
        return "\n\n".join(out)

    def compare(self, a: str, b: str) -> str:
        ca = search(a, ("concept",), 1)
        cb = search(b, ("concept",), 1)
        if not ca or not cb or ca[0][1].ref.id == cb[0][1].ref.id:
            return ""
        x, y = ca[0][1].ref, cb[0][1].ref
        link = [label for d, label, o in knowledge.related(x.id) if o == y.id]
        rows = "\n".join(f"| **{name}** | {fx} | {fy} |" for name, fx, fy in (
            ("Law", md_cite(x.law, _act_of(x)), md_cite(y.law, _act_of(y))),
            ("In short", x.summary, y.summary),
            ("Example", x.example or "—", y.example or "—")))
        out = (f"### [{x.title}]({x.id}) vs [{y.title}]({y.id})\n\n| | {x.title} | {y.title} |\n|---|---|---|\n{rows}\n\n"
               f"**{x.title}:** {md_cite(x.detail, _act_of(x))}\n\n**{y.title}:** {md_cite(y.detail, _act_of(y))}")
        if link:
            out += f"\n\n**How they connect:** {x.title} {link[0]} {y.title}."
        self.last = x
        return out

    def library(self, q: str) -> str:
        hits = search(q)
        if not hits or hits[0][0] < 1.5:
            sections = law.search(q, limit=6)
            if sections:
                return ("I didn't find a concept on that, but these provisions match:\n\n" + "\n".join(
                    f"- [{'Rule' if a in ('ITR', 'STR') else 'Section'} {k}](law:{a}:{k}) of the {law.ABBR[a]}: {t}"
                    for a, k, t in sections))
            return ("**I couldn't find that in TaxDesk's library.** Try other words, a section number, or one of: "
                    "“What is the Active Taxpayers List?”, “What is minimum tax?”, “section 116”, “How is rent taxed?”."
                    "\n\nTaxDesk covers individuals' income tax, withholding, wealth statements and sales tax. For "
                    "anything else, read the official texts: " + " · ".join(
                        f"[{law.ABBR[a]}]({law.OFFICIAL[a]})" for a in law.ACTS))
        top = hits[0][1]
        concept = next((d.ref for s, d in hits if d.kind == "concept" and s >= hits[0][0] * 0.5), None)
        practice = search(q, ("guide",), 1)
        out: list[str] = []
        if top.kind == "option" and not concept:
            out.append(self._option(top.ref))
        elif top.kind == "question" and (not concept or hits[0][0] > 1.6 * next(
                s for s, d in hits if d.ref is concept)):
            q = top.ref
            out.append(self._quiz_block(q).replace("**Test yourself:** ", "**Question bank:** "))
            if q.concept in knowledge.BY_ID:
                out.append(self.concept(knowledge.BY_ID[q.concept], brief=True))
        elif concept:
            out.append(self.concept(concept))
            q = next((d.ref for s, d in hits if d.kind == "question" and d.ref.concept == concept.id), None)
            if q:
                out.append(self._quiz_block(q))
        else:
            act, key, _ = top.ref
            return self.section(act, key)
        if practice and practice[0][0] >= 1.5:
            item = practice[0][1].ref
            out.append(f"**Practice guide:** [{item.title}](guide:{item.id}), with what is included, what is "
                       "admissible and a worked example." if isinstance(item, guide.Topic) else
                       f"**Practice guide:** [{item.title}](guide:{item.id}), step by step.")
        others = [d for s, d in hits[1:6] if d.kind in ("concept", "section") and d.ref is not concept]
        if others:
            out.append("**See also:** " + "; ".join(
                f"[{d.ref.title}]({d.ref.id})" if d.kind == "concept" else
                f"[{'rule' if d.ref[0] in ('ITR', 'STR') else 'section'} {d.ref[1]}](law:{d.ref[0]}:{d.ref[1]}) "
                f"{law.ABBR[d.ref[0]]}: {d.ref[2]}" for d in others[:4]))
        return "\n\n".join(out)

    def _option(self, o: planning.Option) -> str:
        act = law.act_for(o.law)
        parts = [f"### {o.title}", f"**The law:** {md_cite(o.law, act)}"]
        parts += [f"**{name}:** {md_cite(text, act)}" for name, text in (
            ("How", o.how), ("Effect", o.effect), ("Conditions", o.conditions), ("Caution", o.caution)) if text]
        return "\n\n".join(parts)

    def certificate(self, c, others=()) -> str:
        """How to apply for a certificate, registration or approval, with its law and documents."""
        out = [f"### {c.title}", f"**The law:** {md_cite(c.law, c.act)}", c.purpose, f"**Who applies:** {c.who}",
               "**Procedure:**\n" + "\n".join(f"{i}. {md_cite(s, c.act)}" for i, s in enumerate(c.steps, start=1)),
               "**Documents to attach:**\n" + "\n".join(f"- {d}" for d in c.documents),
               f"**Decided by:** {md_cite(c.decided_by, c.act)}"]
        if c.validity:
            out.append(f"**Validity:** {md_cite(c.validity, c.act)}")
        if c.caution:
            out.append(f"**Caution:** {md_cite(c.caution, c.act)}")
        if c.verify:
            out.append("*The steps and documents follow FBR's IRIS forms and usual practice rather than a list printed "
                       "in the rule; confirm them against the current form.* The *Certificates* page has a printable "
                       "checklist.")
        if others:
            out.append("**Also see:** " + "; ".join(o.title for o in others))
        return "\n\n".join(out)

    def planning(self, q: str) -> str:
        specific = set(_tokens(q)) - {_stem(w) for w in "lawful lawfully legal legally reduce reducing save saving lower "
                                      "minimise minimize plan planning tax taxes way ways".split()}
        found = search(q, ("option",), 4) if specific else []
        hits = [d.ref for s, d in found if s > 2 and s >= found[0][0] * 0.6]
        intro = ("**Lawful planning means arranging real affairs within what the law allows.** It never means hiding "
                 f"income or inventing expenses ({md_cite('sections 109, 111 and 192')}).")
        if hits:
            return intro + "\n\n" + "\n\n".join(self._option(o) for o in hits[:3]) + \
                "\n\nThe *Tax planning* page has a what-if calculator that shows the saving on your own return."
        groups: dict[str, list[planning.Option]] = {}
        for o in planning.OPTIONS:
            groups.setdefault(o.category, []).append(o)
        body = "\n\n".join(f"**{cat}**\n" + "\n".join(
            f"- **{o.title}** ({md_cite(o.law, law.act_for(o.law))}): {o.effect}" for o in opts)
            for cat, opts in groups.items())
        return (f"{intro}\n\n{body}\n\nAsk about any one of these for its conditions and cautions, or use the "
                "what-if calculator on the *Tax planning* page.")

    def rates(self, q: str, year: int) -> str:
        r = rules.load(year)
        low = q.lower()
        head = f"### Rates for {r.label} ({r['period']}, {r['finance_act']})"
        if SALES_WORDS.search(q):
            st = r["sales_tax"]
            return (f"{head}\n\n| Item | Rate / limit |\n|---|---|\n| Standard rate | {st['standard_rate']:.0%} "
                    f"([section 3](law:STA:3)) |\n| Further tax on supplies to unregistered persons | "
                    f"{st['further_tax']:.0%} ([section 3(1A)](law:STA:3)) |\n| Input tax limit | {st['input_cap']:.0%} "
                    f"of output tax ([section 8B](law:STA:8B)) |\n| Cottage-industry turnover limit | "
                    f"{money(st['cottage_turnover'])} ([section 2(5AB)](law:STA:2)) |\n\n{VERIFY_NOTE}")
        sec = re.search(r"(?:section|s\.)\s*(\d+[A-Z]{0,3}(?:\(\d+\)(?:\([a-z]\))?)?)", q, re.I)
        if sec or re.search(r"withholding|wht|deduct", low):
            rows = [w for w in r["withholding"] if not sec or w["section"] == sec.group(1)
                    or law.base(w["section"]) == law.base(sec.group(1))]
            if sec and not rows:
                return ""  # not a withholding section: answer with the section itself
            if rows:
                lines = "\n".join(
                    f"| [s.{w['section']}](law:ITO:{law.base(w['section'])}) | {w['title']} | {w['nature']} | "
                    f"{(format(w['rate'], '.1%') if w.get('rate') is not None else w.get('note', 'see the law'))}"
                    f"{' / ' + format(w['rate_non_atl'], '.1%') + ' not on ATL' if w.get('rate_non_atl') else ''}"
                    f"{' (verify)' if w.get('verify') else ''} |" for w in rows)
                return (f"{head}\n\n| Section | Payment | Nature | Rate |\n|---|---|---|---|\n{lines}\n\n"
                        f"**Nature:** [final](final_tax) tax settles the liability on that income, "
                        f"[minimum](minimum_tax) tax can't be reduced below it, and [adjustable](adjustable_tax) tax is "
                        f"credited against the tax on the return.\n\n{VERIFY_NOTE}")
        names = ["salaried", "non_salaried", "property"]
        if "property" in low or "rent" in low:
            names = ["property"]
        elif re.search(r"non[- ]?salar|business", low):
            names = ["non_salaried"]
        elif "salar" in low:
            names = ["salaried"]
        out = [head]
        for name in names:
            slab = r["slabs"][name]
            rows = "\n".join(f"| {money(lo)} | {money(hi) if hi else 'and above'} | {money(fixed)} | {rate:.1%} |"
                             for lo, hi, fixed, rate in slab["rows"])
            title = ("Tax deducted from rent by tenants" if name == "property"
                     else f"{name.replace('_', '-').capitalize()} individuals")
            out.append(f"**{title}** ({md_cite(slab['law'])})\n\n"
                       f"| From | To | Fixed tax | Rate on the excess |\n|---|---|---|---|\n{rows}")
        if names == ["property"]:
            out.append("Rent itself is [income from property](property_income): after the section 15A allowances it "
                       "is taxed with your other income, and the tax a tenant deducts is credited against it.")
        else:
            share = r["salaried_share"]["value"]
            out.append(f"The salaried table applies when salary is more than {share:.0%} of taxable income "
                       f"([the 75% test](salaried_test)).")
        out.append(VERIFY_NOTE)
        return "\n\n".join(out)

    # ------------------------------------------------------------ computations
    def compute_income(self, q: str, year: int) -> str:
        ret, notes = parse_income(q, year)
        if not any(_n(v) for part in ("salary", "property", "business", "other_sources") for v in ret[part].values()
                   if not isinstance(v, str)) and not ret["withholding"]:
            return ("I couldn't tell which figures are income. Say what each amount is, e.g. “salary Rs 3,000,000 a "
                    "year, Rs 250,000 deducted by the employer” or “rent Rs 100,000 a month”.")
        res = income_tax.compute(ret)
        read = []
        s = ret["salary"]
        for label, v in (("Basic salary", s["basic"]), ("Allowances", s["allowances"]),
                         ("Medical allowance", s["medical_allowance"]), ("Perquisites", s["perquisites"]),
                         ("Rent received", ret["property"]["rent_received"]),
                         ("Business turnover / receipts", ret["business"]["turnover"]),
                         ("Cost of sales", ret["business"]["cost_of_sales"]), ("Expenses", ret["business"]["expenses"]),
                         ("Inadmissible expenses", ret["business"]["inadmissible"]),
                         ("Profit on debt", ret["other_sources"]["profit_on_debt"]),
                         ("Dividend", ret["other_sources"]["dividend"]), ("Zakat", ret["deductions"]["zakat"]),
                         ("Education fee", ret["deductions"]["education_fee"]),
                         ("Donations", ret["credits"]["donations"]), ("Pension fund", ret["credits"]["pension"])):
            if _n(v):
                read.append(f"{label} {money(v)}")
        read += [f"tax deducted under s.{w['section']} {money(w['amount'])}" for w in ret["withholding"]]
        out = [f"### Income tax for {rules.load(year).label}",
               "**I read your figures as:** " + "; ".join(read) + (f" ({'; '.join(notes)})" if notes else "")
               + ". If that's wrong, rephrase with a label beside each amount."]
        out.append(self._steps_table(res.steps))
        f = res.figures
        bal = f.get("balance", 0)
        out.append(f"**Result:** total tax chargeable **{money(f.get('tax_chargeable'))}**, tax already paid "
                   f"{money(f.get('tax_paid'))}, so **{'tax payable ' + money(bal) if bal > 0 else 'refundable ' + money(-bal) if bal < 0 else 'nothing more to pay'}**."
                   + (f" Average rate on normal income: {f['average_rate']:.2%}." if f.get("average_rate") else ""))
        for w in res.warnings:
            out.append(f"⚠ {md_cite(w)}")
        out.append("Open *Home → Income tax return* to prepare the full return, or attach a saved one here. "
                   + VERIFY_NOTE)
        return "\n\n".join(out)

    def _steps_table(self, steps, act: str = "ITO") -> str:
        rows = []
        for s in steps:
            label = getattr(s, "label", "")
            if not (s.amount or s.total) or not label:
                continue
            concept = getattr(s, "concept", "")
            name = f"[{label}]({concept})" if concept in knowledge.BY_ID else label
            rows.append(f"| {'**' + name + '**' if s.total else name} | {money(s.amount)} | {md_cite(s.law, act) or '—'} |")
        return "| Step | Amount | Law |\n|---|---:|---|\n" + "\n".join(rows)

    def compute_sales(self, q: str, year: int) -> str:
        doc = parse_sales(q, year)
        if not doc["sales"] and not doc["purchases"]:
            return ("I couldn't tell which amounts are sales and which are input tax. Try “sales Rs 10 million to "
                    "registered buyers, Rs 2 million to unregistered buyers, input tax Rs 1.5 million”.")
        res = sales_tax.compute(doc)
        read = [f"{'sales to unregistered buyers' if not s['buyer_registered'] else s['type'] + ' sales'} "
                f"{money(s['value'])}" for s in doc["sales"]]
        read += [f"{'inadmissible ' if not p['admissible'] else ''}input tax {money(p['sales_tax'])}" for p in doc["purchases"]]
        if doc.get("carry_forward_in"):
            read.append(f"brought forward {money(doc['carry_forward_in'])}")
        f = res.figures
        return "\n\n".join([
            f"### Sales tax return ({rules.load(year).label})",
            "**I read your figures as:** " + "; ".join(read) + ".",
            self._steps_table(res.lines, "STA"),
            f"**Result:** sales tax payable **{money(f.get('payable'))}**"
            + (f", with {money(f['carry_forward'])} carried forward to next month "
               f"([section 10](law:STA:10))" if f.get("carry_forward") else "") + ".",
            VERIFY_NOTE])

    def explain_document(self, doc: dict) -> str:
        kind = doc.get("kind", "itr")
        if kind == "str":
            res = sales_tax.compute(doc)
            return "\n\n".join([f"### Your sales tax return ({doc.get('period', '')})", self._steps_table(res.lines, "STA"),
                                f"**Sales tax payable:** {money(res.figures.get('payable'))}.", VERIFY_NOTE])
        if kind == "wht":
            rows = withholding.check(doc)
            gap = {r.index: max(0.0, -(r.difference or 0)) for r in rows}
            lines = "\n".join(
                f"| {r.payee} | [s.{r.section}](law:ITO:{law.base(r.section)}) | {money(r.gross)} | "
                f"{money(r.expected) if r.expected is not None else '—'} | {money(r.deducted)} | "
                f"{'✗ short ' + money(gap[r.index]) if gap[r.index] >= 1 else '✓'} |" for r in rows)
            short = sum(gap.values())
            return (f"### Your withholding statement ([section 165](law:ITO:165))\n\n| Payee | Section | Paid | Should "
                    f"deduct | Deducted | |\n|---|---|---:|---:|---:|---|\n{lines}\n\n"
                    + (f"**Shortfall {money(short)}.** Under [section 161](law:ITO:161) the agent becomes personally "
                       f"liable for tax not deducted, and [section 21](law:ITO:21) can disallow the expense."
                       if short else "**Every payment had the right deduction.**"))
        ret = income_tax.merged(doc)
        res = income_tax.compute(ret)
        f = res.figures
        out = [f"### Your return: {ret['taxpayer'].get('name') or 'untitled'} ({rules.load(int(ret['tax_year'])).label})"]
        if f.get("taxable_income"):
            share = f.get("salary", 0) / f["taxable_income"]
            out.append(f"**Rate table:** salary is {share:.0%} of taxable income, so the "
                       f"{'salaried' if f.get('salaried') else 'non-salaried'} table applies "
                       "([the 75% test](salaried_test)).")
        out.append(self._steps_table(res.steps))
        bal = f.get("balance", 0)
        out.append(f"**Bottom line:** {'tax payable ' + money(bal) if bal > 0 else 'refundable ' + money(-bal) if bal < 0 else 'nothing more to pay'}.")
        for w in res.warnings:
            out.append(f"⚠ {md_cite(w)}")
        if ret["wealth"].get("assets"):
            rec = wealth.reconcile(ret, res)
            out.append(f"**Wealth reconciliation** ([section 116](law:ITO:116)): unreconciled "
                       f"{money(rec.unreconciled)}. {md_cite(rec.verdict())}")
        out.append("Click any step's name to open its concept, or a section to read the law.")
        return "\n\n".join(out)


# ---------------------------------------------------------------- review notes for marked mock returns
def review_note(case, marked) -> str:
    """A tax manager's review note on a marked mock return (see exam.mark): what went well, each issue with its law,
    and what to read next."""
    wrong = [i for i in marked.items if not i.ok]
    right = [i for i in marked.items if i.ok and i.kind == "result" and i.correct]  # not figures that are nil anyway
    act = "STA" if case.kind == "str" else "ITO"
    out = [f"### Review note: {case.title}",
           f"**Score {marked.score:.0f}%** ({marked.grade}) · time {marked.time_text}."]
    if not wrong:
        out.append("Clean file. Every result and entry agrees with the model return. Ready to sign off.")
        return "\n\n".join(out)
    if right:
        out.append("**Done well:** " + ", ".join(i.label.lower() for i in right[:6]) + ".")
    out.append("**Points to clear before this return could be filed:**")
    seen: set[str] = set()
    for n, i in enumerate(wrong, start=1):
        line = f"{n}. **{i.label}**: you have {_fmt(i.yours)}, the return needs {_fmt(i.correct)}."
        if i.hint:
            line += f" {md_cite(i.hint, act)}"
        if i.law:
            line += f" See {md_cite(i.law, act)}."
        out.append(line)
        if i.concept:
            seen.add(i.concept)
    reading = [knowledge.BY_ID[c] for c in seen if c in knowledge.BY_ID]
    if reading:
        out.append("**Read before the next attempt:** " + "; ".join(
            f"[{c.title}]({c.id}) ({md_cite(c.law, _act_of(c))})" for c in reading))
    return "\n\n".join(out)


def _fmt(v: Any) -> str:
    if v is None:
        return "nothing"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return money(v)
    return str(v)
