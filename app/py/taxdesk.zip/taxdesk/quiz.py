"""Question bank: short questions on the main topics, each with an explanation citing the law.

Statements of law were checked against FBR's consolidated texts (Income Tax Ordinance 2001 amended up to
30 June 2026, Income Tax Rules 2002 up to 15 September 2026, Sales Tax Act 1990 up to 30 June 2025).
Questions with a figure get their answer from TaxDesk's own engine and rule files, so they always agree with
the returns.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Callable

from . import income_tax, rules, sales_tax
from .rules import money

TOPICS = ["Salary", "Business income and expenses", "Withholding taxes", "Wealth statement", "Sales tax",
          "Property and capital gains", "Allowances, credits and rates"]


@dataclass(frozen=True)
class Question:
    id: str
    topic: str
    level: str  # Basic | Intermediate | Advanced
    text: str
    options: tuple[str, ...] = ()        # choice questions
    answer: int = 0                      # index of the right option
    explain: str = ""
    law: str = ""
    concept: str = ""
    calc: Callable[[], float] | None = field(default=None, compare=False, hash=False)  # number questions

    @property
    def kind(self) -> str:
        return "number" if self.calc else "choice"

    def correct_value(self) -> float:
        return round(self.calc(), 2) if self.calc else 0.0

    def check(self, response) -> bool:
        if self.calc:
            try:
                return abs(float(str(response).replace(",", "").replace("Rs", "").strip()) - self.correct_value()) < 1
            except ValueError:
                return False
        return response == self.answer


def _tax(**parts) -> dict:
    ret = income_tax.blank_return(parts.pop("year", 2025))
    for k, v in parts.items():
        ret[k].update(v) if isinstance(v, dict) else ret.__setitem__(k, v)
    return income_tax.compute(ret).figures


TF = ("True", "False")
Q = Question
QUESTIONS: list[Question] = [
    # ================================================================ Salary
    Q("sal-1", "Salary", "Basic", "Which of these is NOT included in salary under section 12(2)?",
      ("A bonus paid by the employer", "A house rent allowance paid monthly",
       "An allowance spent solely in performing the employee's duties", "A payment in lieu of leave"), 2,
      "Salary includes pay, bonus, leave pay, allowances, perquisites and reimbursements. An allowance solely "
      "expended in the performance of the employee's duties is excluded (section 12(2)(c)).",
      "Section 12(2)", "salary_income"),
    Q("sal-2", "Salary", "Intermediate",
      "An employee gets a fixed 'travel allowance' of Rs 20,000 every month with the salary, without accounting for it. "
      "Is it excluded from salary as an allowance spent in performing duties?",
      ("Yes, travel is a duty-related expense", "No, it is taxable salary"), 1,
      "The Explanation to section 12(2)(c) says an allowance paid in the monthly salary on a fixed basis, or not "
      "wholly, exclusively, necessarily and actually spent on behalf of the employer, is not a duty allowance. It is "
      "taxable salary.", "Section 12(2)(c)", "salary_income"),
    Q("sal-3", "Salary", "Basic", "A golden handshake received on leaving a job is…",
      ("Exempt, because it is a capital receipt", "Salary, under section 12(2)(e)", "A capital gain", "Income from other sources"), 1,
      "Section 12(2) covers amounts of a revenue or capital nature, and 12(2)(e)(iii) includes compensation on "
      "termination of employment, including golden handshake payments.", "Section 12(2)(e)", "salary_income"),
    Q("sal-4", "Salary", "Basic", "When is salary taxed?",
      ("When it is earned, even if unpaid", "When it is received by the employee",
       "At the end of the employer's financial year", "Only when the employer deducts tax"), 1,
      "Section 12(1): salary received by an employee in a tax year is chargeable in that year.",
      "Section 12(1)", "salary_income"),
    Q("sal-5", "Salary", "Intermediate",
      "The employer provides a car that the employee uses partly for private and partly for official purposes. "
      "How is the perquisite valued?",
      ("Nil, because the car is partly official", "5% of the car's cost to the employer (or its value at the start of a lease)",
       "10% of the car's cost", "The car's monthly running costs"), 1,
      "Section 13(3) leaves the value to the Rules; rule 5 of the IT Rules 2002 values a car used partly privately "
      "at 5% of its cost (or fair market value at the start of a lease), and 10% if used only for private purposes.",
      "Section 13(3); rule 5", "perquisites"),
    Q("sal-6", "Salary", "Intermediate", "How is employer-provided accommodation valued as a perquisite?",
      ("Always at nil", "At what the employer would have paid as house rent allowance, but not less than 45% of the "
       "minimum of the time scale (or basic salary)", "At the property's market value", "At 10% of basic salary"), 1,
      "Rule 4 of the IT Rules 2002: the value equals what the employer would have paid had accommodation not been "
      "provided, but not less than 45% of the minimum of the time scale of basic salary (or basic salary where there "
      "is no time scale).", "Section 13; rule 4", "perquisites"),
    Q("sal-7", "Salary", "Basic",
      "The employer pays the salary of a driver who works for the employee at home. What is added to the employee's salary?",
      ("Nothing", "The driver's salary, less anything the employee pays the employer for it", "Half the driver's salary",
       "Only if the driver is also used for official work"), 1,
      "Section 13(5): the services of a housekeeper, driver, gardener or other domestic assistant are valued at the "
      "salary paid to them, reduced by any payment made by the employee to the employer.", "Section 13(5)", "perquisites"),
    Q("sal-8", "Salary", "Basic",
      "Basic salary Rs 1,200,000 and medical allowance Rs 150,000 (no free treatment). How much of the medical allowance is taxable?",
      ("Rs 0", "Rs 30,000", "Rs 120,000", "Rs 150,000"), 1,
      "Medical allowance is exempt up to 10% of basic salary where free medical treatment isn't provided (Second "
      "Schedule, clause (139)): 10% × 1,200,000 = 120,000 exempt, 30,000 taxable.",
      "Second Schedule, clause (139)", "exemptions"),
    Q("sal-9", "Salary", "Intermediate",
      "Tax Year 2025: an employee's salary income (after exemptions) is Rs 2,340,000 and there is no other income. "
      "What is the tax on taxable income?", explain="Salaried slab: Rs 180,000 + 25% of the amount above 2,200,000.",
      law="First Schedule, Part I, Division I, para (1A)", concept="slab_rates",
      calc=lambda: _tax(salary={"basic": 2340000})["tax_on_income"]),
    Q("sal-10", "Salary", "Intermediate",
      "Salary Rs 2,000,000 and business income Rs 1,000,000. Which rate table applies to the taxable income?",
      ("Salaried, because there is salary", "Non-salaried, because salary is not more than 75% of taxable income",
       "Salaried for the salary and non-salaried for the business", "The average of both tables"), 1,
      "The salaried table applies only when salary is more than 75% of taxable income. Here it is 67%, so all "
      "income is taxed on the non-salaried table.", "First Schedule, Part I, Division I, para (1A)", "salaried_test"),
    Q("sal-11", "Salary", "Basic", "Tax deducted by the employer under section 149 is…",
      ("Final tax", "Minimum tax", "Adjustable against the tax worked out in the return", "Not shown in the return"), 2,
      "Tax deducted from salary is adjustable: it is credited against the total tax chargeable and any excess is refundable.",
      "Section 149", "adjustable_tax"),
    Q("sal-12", "Salary", "Intermediate",
      "A business pays an employee Rs 40,000 a month in cash. What happens to the deduction for this salary in the business's accounts?",
      ("It is fully deductible", "It is not deductible, because salary above Rs 32,000 a month must be paid through a bank or digitally",
       "Only half is deductible", "It is deductible if tax was withheld"), 1,
      "Section 21(m) disallows salary over thirty-two thousand rupees a month paid other than by crossed cheque, direct "
      "transfer to the employee's bank account or digital means.", "Section 21(m)", "inadmissible_expenses"),
    # ================================================================ Business
    Q("bus-1", "Business income and expenses", "Basic", "What is the main test for a business expense to be deductible?",
      ("It was paid in cash", "It was incurred wholly and exclusively for the purposes of the business",
       "It is shown in the bank statement", "It is less than 10% of turnover"), 1,
      "Section 20(1) allows expenditure incurred in the year wholly and exclusively for the purposes of business.",
      "Section 20(1)", "admissible_expenses"),
    Q("bus-2", "Business income and expenses", "Basic", "A shop buys a new delivery van. Can the price be deducted as an expense in full?",
      ("Yes, in the year of purchase", "No, it is a depreciable asset: claim depreciation (and initial allowance) instead",
       "No, vehicles are never allowed", "Yes, if paid by cheque"), 1,
      "Section 20(2): expenditure on a depreciable asset with a useful life of more than a year is depreciated or "
      "amortised under sections 22–25.", "Sections 20(2), 22–23", "depreciation"),
    Q("bus-3", "Business income and expenses", "Basic", "Which of these is deductible from business income?",
      ("Income tax paid on the business profits", "A fine for breaking a traffic law", "Rent of the business premises",
       "The owner's household grocery bill"), 2,
      "Rent of business premises is a business expense (section 20). Tax on profits (s.21(a)), fines and penalties "
      "(s.21(g)) and personal expenditure (s.21(h)) are not deductible.", "Sections 20, 21", "admissible_expenses"),
    Q("bus-4", "Business income and expenses", "Intermediate",
      "A business pays a supplier Rs 400,000 in cash for stationery over the year (single account head). The expense is…",
      ("Fully deductible", "Not deductible, because over Rs 250,000 under one account head must go through the banking channel",
       "Deductible up to Rs 250,000", "Deductible if the supplier is on the ATL"), 1,
      "Section 21(l): expenditure under a single account head that in aggregate exceeds two hundred and fifty thousand "
      "rupees must be paid by a crossed cheque, crossed banking instrument, online transfer or credit card from the "
      "business account; otherwise it is disallowed.", "Section 21(l)", "inadmissible_expenses"),
    Q("bus-5", "Business income and expenses", "Intermediate",
      "Which of these is excluded from the banking-channel rule in section 21(l)?",
      ("Payment for raw material", "Electricity and gas bills", "Salary to staff", "Purchase of furniture"), 1,
      "The rule doesn't apply to expenditure up to twenty-five thousand rupees, or to utility bills, freight charges, "
      "travel fare, postage, and payment of taxes, duties, fees, fines or other statutory obligations.",
      "Section 21(l)", "inadmissible_expenses"),
    Q("bus-6", "Business income and expenses", "Intermediate",
      "A business paid a contractor without deducting the tax required under section 153. What is the effect on the expense?",
      ("No effect", "The expense is disallowed (section 21(c)), and the business is personally liable for the tax (section 161)",
       "Only a penalty applies", "The contractor must pay double tax"), 1,
      "Section 21(c) disallows expenditure from which tax had to be deducted unless it was deducted and paid. Section "
      "161 makes the payer liable for the tax not deducted. Recovering the tax under s.161 counts as tax paid.",
      "Sections 21(c), 161", "withholding_agent"),
    Q("bus-7", "Business income and expenses", "Advanced",
      "Tax wasn't withheld on purchases of raw materials worth Rs 10,000,000. What is the most that can be disallowed under section 21(c) for these purchases?",
      ("Rs 10,000,000", "Rs 2,000,000 (20% of the purchases)", "Rs 1,000,000", "Nothing, purchases are exempt"), 1,
      "The first proviso to section 21(c) caps the disallowance for purchases of raw materials and finished goods at "
      "twenty per cent of those purchases.", "Section 21(c)", "inadmissible_expenses"),
    Q("bus-8", "Business income and expenses", "Basic", "A sole trader has a business loss and a salary. Can the loss reduce the salary income?",
      ("Yes, losses set off against any income", "No, a business loss can't be set off against salary; it is carried forward",
       "Only half of the loss", "Only if the loss is small"), 1,
      "A business loss can't be set off against income under the heads salary or property; it is carried forward for "
      "up to six tax years against business income.", "Sections 56–57", "loss_setoff"),
    Q("bus-9", "Business income and expenses", "Intermediate",
      "Turnover Rs 25,000,000; cost of sales Rs 20,000,000; expenses Rs 2,200,000 of which Rs 300,000 are personal; "
      "tax depreciation Rs 100,000. What is the income from business?",
      explain="5,000,000 gross profit − 1,900,000 admissible expenses − 100,000 depreciation.",
      law="Sections 18, 20, 21", concept="business_income",
      calc=lambda: _tax(business={"turnover": 25000000, "cost_of_sales": 20000000, "expenses": 2200000,
                                   "inadmissible": 300000, "depreciation": 100000})["business"]),
    Q("bus-10", "Business income and expenses", "Intermediate",
      "Tax deducted on sale of goods under section 153(1)(a) for an individual is minimum tax. What does that mean?",
      ("It is refunded if the business makes a loss", "The tax on that income can't be lower than the amount deducted",
       "It is ignored in the return", "It replaces the return"), 1,
      "Minimum tax is the least tax payable on that income: if the tax worked out is lower, the deducted amount is "
      "the liability and the difference isn't refunded.", "Section 153", "minimum_tax"),
    Q("bus-11", "Business income and expenses", "Basic", "Contributions to a provident fund that is not recognised are…",
      ("Deductible", "Not deductible (section 21(e))", "Deductible up to 10% of salary", "A tax credit"), 1,
      "Section 21(e): no deduction for contributions to a fund that isn't a recognised provident fund, approved "
      "pension, superannuation or gratuity fund.", "Section 21(e)", "inadmissible_expenses"),
    # ================================================================ Withholding
    Q("wht-1", "Withholding taxes", "Basic", "Tax deducted by a bank from profit on a savings account (within the limit) is…",
      ("Adjustable", "Final tax", "Minimum tax", "Refundable in full"), 1,
      "Profit on debt within the limit is a separate block taxed under section 7B; the bank's deduction under section "
      "151 is the final tax on it.", "Sections 7B, 151", "profit_on_debt"),
    Q("wht-2", "Withholding taxes", "Basic", "Advance tax paid when buying a property under section 236K is…",
      ("Final", "Adjustable against the buyer's tax for the year", "Not claimable", "Minimum tax"), 1,
      "Section 236K collection is adjustable: the buyer claims it in the return.", "Section 236K", "adjustable_tax"),
    Q("wht-3", "Withholding taxes", "Basic", "Why does the Active Taxpayers List matter for withholding?",
      ("Only filers have tax deducted", "Persons not on the ATL suffer higher withholding rates, often double",
       "ATL persons are exempt from withholding", "It only matters for companies"), 1,
      "The Tenth Schedule applies higher rates to persons not on the ATL. Filing the return on time keeps you on it.",
      "Section 181A; Tenth Schedule", "atl"),
    Q("wht-4", "Withholding taxes", "Basic", "Which document does the withholding agent give the payee as proof of the tax deducted?",
      ("A wealth statement", "A certificate of collection or deduction of tax", "A sales tax invoice", "A return of income"), 1,
      "The payer issues a certificate (section 164); its form is in rule 42 of the IT Rules 2002 (other than salary).",
      "Section 164; rule 42", "withholding_agent"),
    Q("wht-5", "Withholding taxes", "Intermediate", "Where does a withholding agent report every payee and the tax deducted?",
      ("In its own income tax return only", "In the statements under section 165", "In the wealth statement",
       "Nowhere; depositing the tax is enough"), 1,
      "Section 165 requires statements of tax collected or deducted (rule 44 of the IT Rules 2002). FBR matches them "
      "with payees' returns.", "Section 165; rule 44", "withholding_statement"),
    Q("wht-6", "Withholding taxes", "Intermediate",
      "Tax Year 2025: a company pays Rs 2,000,000 for goods to a supplier who IS on the ATL. How much should it deduct "
      "under section 153(1)(a) at TaxDesk's rate?", explain="Rate for individuals/AOPs supplying goods × amount.",
      law="Section 153(1)(a)", concept="withholding_agent",
      calc=lambda: 2000000 * rules.load(2025).withholding("153(1)(a)")["rate"]),
    Q("wht-7", "Withholding taxes", "Basic", "Tax deducted from a dividend under section 150 is…",
      ("Adjustable", "Final", "Minimum", "Exempt"), 1, "Dividend is taxed as a separate block and the deduction is final.",
      "Sections 5, 150", "dividend"),
    Q("wht-8", "Withholding taxes", "Intermediate", "If adjustable tax deducted is more than the total tax for the year, the difference is…",
      ("Lost", "Refundable, by claiming it in the return", "Carried to next year automatically", "Paid to the employer"), 1,
      "Adjustable tax is credited against tax chargeable; any excess can be claimed as a refund (section 170).",
      "Sections 147, 170", "tax_payable_refund"),
    Q("wht-9", "Withholding taxes", "Intermediate",
      "Who is liable if a withholding agent fails to deduct tax?",
      ("Only the payee", "The withholding agent personally, with default surcharge", "Nobody", "The bank"), 1,
      "Section 161 makes the person who failed to collect or deduct personally liable for the amount; default "
      "surcharge applies under section 205.", "Sections 161, 205", "withholding_agent"),
    Q("wht-10", "Withholding taxes", "Basic", "Tax paid through electricity bills (section 235) by an individual is generally…",
      ("Final", "Adjustable", "Not tax", "Minimum"), 1, "Treated as adjustable in TaxDesk's rules: claim it in the return.",
      "Section 235", "adjustable_tax"),
    # ================================================================ Wealth
    Q("wlt-1", "Wealth statement", "Basic", "Whose assets must an individual include in the wealth statement?",
      ("Only their own", "Their own, and those of the spouse (if dependent), minor children and other dependents",
       "The whole household's, including adult earning children", "Only assets above Rs 1 million"), 1,
      "Section 116(1)(b): assets and liabilities of the spouse, minor children and other dependents. The Explanation "
      "says a spouse's assets are included only if the spouse is dependent.", "Section 116(1)", "wealth_statement"),
    Q("wlt-2", "Wealth statement", "Basic", "At what value are assets shown in the wealth statement?",
      ("Market value", "Cost", "FBR valuation", "Insurance value"), 1,
      "Assets are declared at cost, so the reconciliation compares like with like year to year.", "Section 116; rule 36",
      "wealth_statement"),
    Q("wlt-3", "Wealth statement", "Intermediate",
      "Net assets rose by Rs 4,200,000. Income declared Rs 3,000,000, tax paid Rs 380,000, household expenses "
      "Rs 920,000, and a documented gift of Rs 2,500,000 from her father. What is the unreconciled difference?",
      explain="Increase − (inflows − outflows) = 4,200,000 − (3,000,000 + 2,500,000 − 380,000 − 920,000).",
      law="Section 116", concept="wealth_reconciliation", calc=lambda: 4200000 - (3000000 + 2500000 - 380000 - 920000)),
    Q("wlt-4", "Wealth statement", "Basic", "Wealth grew by more than declared income and other inflows explain. What can the officer do?",
      ("Nothing", "Add the unexplained amount to income under section 111", "Only issue a warning", "Cancel the NTN"), 1,
      "Section 111: investments, money or expenditure whose source isn't satisfactorily explained can be included in "
      "income (from other sources).", "Section 111", "unexplained_income"),
    Q("wlt-5", "Wealth statement", "Intermediate",
      "A person explains new wealth as agricultural income. How much of the explanation is accepted?",
      ("All of it, agricultural income is exempt", "Up to the agricultural income worked back from the provincial agricultural income tax paid",
       "None of it", "Half of it"), 1,
      "The proviso to section 111(1) accepts agricultural income to the extent worked back on the basis of "
      "agricultural income tax paid under the provincial law.", "Section 111(1)", "agricultural_income"),
    Q("wlt-6", "Wealth statement", "Basic", "Is a gift received from a relative income?",
      ("Yes, taxable as other sources", "No, but it must be documented and shown as an inflow in the reconciliation",
       "Only if above Rs 100,000", "Yes, at a flat 10%"), 1,
      "A genuine documented gift isn't income, but it explains wealth only if shown as an inflow (and in the giver's "
      "wealth statement as an outflow). Undocumented 'gifts' risk section 111.", "Sections 111, 116", "wealth_reconciliation"),
    Q("wlt-7", "Wealth statement", "Intermediate",
      "Someone buys a plot for Rs 12 million in cash. Which risk does section 75A create?",
      ("None", "The purchase of an asset above the prescribed value must be made through the banking channel",
       "Only stamp duty increases", "The seller pays more tax"), 1,
      "Section 75A requires purchases of assets above the prescribed value to be made through a banking channel; cash "
      "purchases also invite questions under section 111.", "Sections 75A, 111", "banking_channel_assets"),
    Q("wlt-8", "Wealth statement", "Basic", "Which of these is an OUTFLOW in the wealth reconciliation?",
      ("Gift received", "Inheritance", "Household and personal expenses", "Exempt income"), 2,
      "Personal and household expenses, taxes paid, gifts given and losses are outflows; income, exempt income, gifts "
      "received and inheritance are inflows.", "Section 116(1)(d)", "personal_expenses"),
    Q("wlt-9", "Wealth statement", "Intermediate", "Money received from abroad through a bank account is…",
      ("Always taxable", "Protected from being treated as unexplained, within the conditions of section 111(4)",
       "Ignored in the wealth statement", "Treated as salary"), 1,
      "Section 111(4) protects foreign remittances through banking channels, subject to its conditions; keep the "
      "encashment certificate.", "Section 111(4)", "foreign_remittance"),
    # ================================================================ Sales tax
    Q("st-1", "Sales tax", "Basic", "What is the standard rate of sales tax in TaxDesk's rules (Tax Year 2025)?",
      ("13%", "16%", "17%", "18%"), 3, "Section 3 sets the standard rate; TaxDesk uses 18%.", "Section 3", "output_tax"),
    Q("st-2", "Sales tax", "Basic", "What is the most input tax that can be adjusted in a month (for goods other than capital goods)?",
      ("All of it", "90% of output tax", "80% of input tax", "50% of output tax"), 1,
      "Section 8B(1): input tax can't be adjusted above ninety per cent of output tax; the excess carries forward.",
      "Section 8B", "input_cap"),
    Q("st-3", "Sales tax", "Intermediate", "Does the 90% limit apply to input tax on a new machine (capital goods)?",
      ("Yes", "No, the first proviso to section 8B(1) excludes fixed assets and capital goods"), 1,
      "The restriction doesn't apply to fixed assets or capital goods.", "Section 8B", "input_cap"),
    Q("st-4", "Sales tax", "Basic", "Further tax applies to supplies made to…",
      ("Exporters", "Unregistered persons", "Government departments", "Registered persons"), 1,
      "Section 3(1A) charges further tax on supplies to persons who aren't registered; input tax can't be set against it.",
      "Section 3(1A)", "further_tax"),
    Q("st-5", "Sales tax", "Intermediate", "A buyer pays a supplier Rs 120,000 in cash for a taxable purchase in one month. The buyer's input tax on it is…",
      ("Allowed", "Not admissible, because payments above Rs 50,000 to a single supplier in a tax period must go through a bank",
       "Allowed at 50%", "Allowed if the supplier is on the ATL"), 1,
      "Section 73: payments exceeding fifty thousand rupees in aggregate to a single supplier in a tax period must be "
      "made through the banking channel (utility bills excepted), or input tax is denied.", "Section 73", "st_banking_channel"),
    Q("st-6", "Sales tax", "Intermediate", "Input tax was missed in its month. Can it still be claimed?",
      ("No, it is lost", "Yes, in any of the six succeeding tax periods", "Only with the Commissioner's approval", "Only at year end"), 1,
      "The proviso to section 7(1): input tax not deducted in the relevant period may be claimed in any of the six "
      "succeeding tax periods.", "Section 7", "input_tax"),
    Q("st-7", "Sales tax", "Basic", "Which purchase's input tax is NOT allowed?",
      ("Raw material for taxable goods", "Goods for personal or non-business use", "Packing material", "Electricity used in production"), 1,
      "Section 8(1)(g): goods and services acquired for personal or non-business consumption. Also blocked: goods for "
      "non-taxable purposes, fake invoices, purchases where the supplier didn't deposit the tax, and others in s.8.",
      "Section 8", "inadmissible_input"),
    Q("st-8", "Sales tax", "Intermediate", "What does the buyer need to claim input tax on a taxable purchase?",
      ("Any receipt", "A tax invoice in the buyer's name bearing the buyer's registration number", "A bank statement only", "Nothing"), 1,
      "Section 7(2)(i): input tax can be deducted only if the buyer holds a tax invoice in their name with their "
      "registration number (section 23 sets what an invoice contains).", "Sections 7(2), 23", "st_records_invoices"),
    Q("st-9", "Sales tax", "Basic", "How do zero-rated and exempt supplies differ?",
      ("They are the same", "Zero-rated: 0% tax but input tax can be claimed; exempt: no tax and no input claim",
       "Exempt: input can be claimed; zero-rated: it can't", "Both allow double input"), 1,
      "Zero-rating (section 4, e.g. exports) keeps the right to input tax; exempt supplies (section 13, Sixth Schedule) "
      "lose it.", "Sections 4, 13", "exempt_supplies"),
    Q("st-10", "Sales tax", "Intermediate",
      "A small manufacturer has turnover of Rs 7,000,000, no industrial connection, works from home in a residential area "
      "with 6 workers. Must it register for sales tax?",
      ("Yes", "No, it is a cottage industry"), 1,
      "Section 2(5AB): a cottage industry has no industrial gas or electricity connection, is in a residential area, "
      "has no more than ten workers and turnover up to eight million rupees.", "Section 2(5AB)", "st_definitions"),
    Q("st-11", "Sales tax", "Intermediate", "Which retailer is a Tier-1 retailer?",
      ("A small corner shop with a domestic meter", "A shop in an air-conditioned shopping mall", "A street vendor",
       "Any retailer with sales over Rs 1 million"), 1,
      "Section 2(43A) includes retailers in an air-conditioned mall or plaza (not kiosks), chain stores, those whose "
      "electricity bill over the last twelve months exceeds Rs 1.2 million, wholesaler-cum-retailers and others.",
      "Section 2(43A)", "st_definitions"),
    Q("st-12", "Sales tax", "Intermediate",
      "Month: taxable sales Rs 12,000,000 (Rs 2,000,000 to unregistered buyers); admissible input Rs 2,000,000; "
      "brought forward Rs 300,000. What is the sales tax payable?",
      explain="Output 18% × 12m = 2,160,000; input adjusted limited to 90% = 1,944,000; further tax 4% × 2m = 80,000.",
      law="Sections 3, 3(1A), 8B, 10", concept="st_payable",
      calc=lambda: sales_tax.compute({"tax_year": 2025, "sales": [{"value": 10000000}, {"value": 2000000, "buyer_registered": False}],
                                      "purchases": [{"sales_tax": 2000000}], "carry_forward_in": 300000}).figures["payable"]),
    Q("st-13", "Sales tax", "Basic", "Sales tax on services such as consultancy is collected by…",
      ("FBR under the Sales Tax Act", "The provinces (PRA, SRB, KPRA, BRA)", "The employer", "The bank"), 1,
      "Services are taxed by the provinces under their own laws.", "", "provincial_services"),
    Q("st-14", "Sales tax", "Basic", "For how long must sales tax records be kept?",
      ("One year", "Three years", "Six years", "Ten years"), 2, "Section 24: retention of record and documents for six years.",
      "Section 24", "st_records_invoices"),
    # ================================================================ Property and capital gains
    Q("pcg-1", "Property and capital gains", "Basic", "How is rent received by an individual taxed?",
      ("Added to other income after the section 15A allowances", "As a separate block on the property slab rates",
       "At a flat 15%", "It is exempt"), 0,
      "Sections 15 and 15A: rent less a one-fifth repairs allowance and the other allowed expenses is income from "
      "property, taxed with other income. The separate property rates were omitted by the Finance Act 2021.",
      "Sections 15, 15A", "property_income"),
    Q("pcg-2", "Property and capital gains", "Intermediate",
      "Tax Year 2025: a company pays an individual landlord rent of Rs 1,200,000. How much tax must it deduct under "
      "section 155?",
      explain="Section 155 slabs for individuals: Rs 15,000 + 10% of the amount above 600,000. The landlord adjusts "
      "it against the tax on his return.", law="Section 155", concept="adjustable_tax",
      calc=lambda: rules.load(2025).slab("property", 1200000).tax),
    Q("pcg-3", "Property and capital gains", "Intermediate",
      "An open plot bought in March 2020 for Rs 8,000,000 is sold in April 2025 for Rs 14,000,000 by an active taxpayer. "
      "What is the capital gains tax?", explain="Held just over 5 years: 2.5% under the holding-period table.",
      law="Section 37(1A)", concept="capital_gains",
      calc=lambda: _tax(capital_gains=[{"asset": "property", "kind": "open_plot", "acquired": "2020-03-01",
                                        "disposed": "2025-04-10", "cost": 8000000, "sale": 14000000}])["cg_tax"]),
    Q("pcg-4", "Property and capital gains", "Basic", "Which items form part of an asset's cost for capital gains?",
      ("Only the purchase price", "Price plus incidental costs of acquiring, improving and disposing of it",
       "Market value on sale", "The FBR valuation"), 1, "Section 76 defines cost.", "Section 76", "asset_cost"),
    Q("pcg-5", "Property and capital gains", "Intermediate", "A plot worth Rs 20m is sold to a brother for Rs 5m. On what amount is the seller taxed?",
      ("Rs 5m", "Fair market value of Rs 20m", "The original cost", "Nothing, family transfers are exempt"), 1,
      "Section 78: between associates or not at arm's length, fair market value is used.", "Section 78", "non_arms_length"),
    Q("pcg-6", "Property and capital gains", "Basic", "A capital loss on selling shares can be set off against…",
      ("Salary", "Business income", "Capital gains only", "Any income"), 2,
      "Capital losses are ring-fenced against capital gains.", "Sections 37, 37A", "capital_gains"),
    Q("pcg-7", "Property and capital gains", "Intermediate", "Two sisters own a rented house 50:50. How is the rent taxed?",
      ("All in the elder sister's hands", "Each is taxed on her half, with her own income", "As an AOP", "Not taxed"), 1,
      "Section 66: income of joint owners is divided in their shares.", "Section 66", "co_ownership"),
    # ================================================================ Allowances, credits, rates
    Q("acr-1", "Allowances, credits and rates", "Basic", "What is the difference between a deductible allowance and a tax credit?",
      ("None", "An allowance reduces taxable income (saves at the top rate); a credit reduces the tax (at the average rate)",
       "A credit reduces income; an allowance reduces tax", "Both are refunds"), 1,
      "Zakat (s.60) is a deductible allowance; donations (s.61) and pension contributions (s.63) are credits at the "
      "average rate.", "Sections 60, 61, 63", "deductible_allowances"),
    Q("acr-2", "Allowances, credits and rates", "Intermediate", "Up to what share of taxable income do donations earn a tax credit?",
      ("10%", "20%", "30%", "50%"), 2, "The donation credit is on the lower of the amount donated and 30% of taxable income.",
      "Section 61", "tax_credits"),
    Q("acr-3", "Allowances, credits and rates", "Intermediate", "Up to what share of taxable income do approved pension fund contributions earn a credit?",
      ("10%", "20%", "30%", "50%"), 1, "The pension credit is on the lower of the contribution and 20% of taxable income.",
      "Section 63", "tax_credits"),
    Q("acr-4", "Allowances, credits and rates", "Basic", "Where is the definition of a non-profit organisation whose donations qualify?",
      ("Section 2(36)", "Section 12", "Section 153", "Section 236K"), 0,
      "Section 2(36) defines a non-profit organisation; approval follows rule 211 of the IT Rules 2002.",
      "Section 2(36); rule 211", "tax_credits"),
    Q("acr-5", "Allowances, credits and rates", "Advanced",
      "Tax Year 2025: salary Rs 12,000,000 and a donation of Rs 1,000,000 to an approved trust. What is the donation credit?",
      explain="Average rate (tax ÷ taxable income) × the donation (within 30% of taxable income).",
      law="Section 61", concept="tax_credits", calc=lambda: _tax(salary={"basic": 12000000}, credits={"donations": 1000000})["credits"]),
    Q("acr-6", "Allowances, credits and rates", "Intermediate", "When does the surcharge under section 4AB apply to an individual?",
      ("Always", "When taxable income exceeds Rs 10 million", "Only for non-filers", "Only on capital gains"), 1,
      "TaxDesk's rules apply section 4AB above Rs 10 million taxable income.", "Section 4AB", "surcharge"),
    Q("acr-7", "Allowances, credits and rates", "Basic", "Tax Year 2025: what is the tax on a salaried individual's taxable income of Rs 600,000?",
      explain="The first Rs 600,000 is in the 0% slab.", law="First Schedule, Part I, Division I", concept="slab_rates",
      calc=lambda: _tax(salary={"basic": 600000})["tax_on_income"]),
    Q("acr-8", "Allowances, credits and rates", "Intermediate",
      "Tax Year 2026: salaried taxable income Rs 2,500,000. What is the tax on taxable income?",
      explain="TY2026 salaried slab: Rs 116,000 + 23% of the amount above 2,200,000.", law="First Schedule, Part I, Division I",
      concept="slab_rates", calc=lambda: _tax(year=2026, salary={"basic": 2500000})["tax_on_income"]),
]

BY_ID = {q.id: q for q in QUESTIONS}


def questions(topic: str | None = None, level: str | None = None, shuffle: bool = True) -> list[Question]:
    out = [q for q in QUESTIONS if (not topic or q.topic == topic) and (not level or q.level == level)]
    if shuffle:
        random.shuffle(out)
    return out


def answer_text(q: Question) -> str:
    return money(q.correct_value()) if q.calc else q.options[q.answer]
