"""Licences and the owner's remote control.

Licence keys are signed with the owner's private key (kept only on the owner's computer); the app checks the
signature with the public key below, so keys can't be forged and are checked even offline.

On start the app reads control.json from the public downloads repository. Through it the owner can switch every
copy off, require a minimum version, revoke licences, announce a message and point to the latest version.
The last copy read is cached, so a short time offline doesn't stop the app.
"""
from __future__ import annotations

import base64
import json
import platform
import re
import threading
import urllib.request
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from . import __version__

PUBLIC_KEY = "6X0Q/wllXNzNbwBARpIEakQuha6GHn1+94EbRbluJLg="
CONTROL_URL = "https://raw.githubusercontent.com/majmalzaib/taxdesk-downloads/main/control.json"
DOWNLOADS_URL = "https://github.com/majmalzaib/taxdesk-downloads/releases/latest"
KEY_PREFIX = "TD1-"
OFFLINE_GRACE_DAYS = 30


# ---------------------------------------------------------------- licences
@dataclass
class Licence:
    id: str
    name: str
    email: str = ""
    expires: str | None = None
    issued: str = ""

    @property
    def expired(self) -> bool:
        return bool(self.expires) and date.fromisoformat(self.expires) < date.today()


class LicenceError(ValueError):
    pass


def _b64d(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def parse_key(key: str, public_key: str = PUBLIC_KEY) -> Licence:
    """Check a licence key's signature and return its licence; raises LicenceError if it isn't genuine."""
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    k = re.sub(r"\s+", "", key or "")
    if not k.startswith(KEY_PREFIX) or k.count(".") != 1:
        raise LicenceError("That isn't a TaxDesk licence key.")
    body, sig = k[len(KEY_PREFIX):].split(".")
    try:
        payload, signature = _b64d(body), _b64d(sig)
        Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key)).verify(signature, payload)
        data = json.loads(payload)
    except (InvalidSignature, ValueError):
        raise LicenceError("This licence key isn't valid. Check it was copied completely.") from None
    lic = Licence(id=str(data["id"]), name=data.get("name", ""), email=data.get("email", ""),
                  expires=data.get("exp"), issued=data.get("iat", ""))
    if lic.expired:
        raise LicenceError(f"This licence expired on {lic.expires}. Ask for a new key.")
    return lic


def sign_key(payload: dict, private_key) -> str:
    """Owner side: make a licence key. private_key is an Ed25519PrivateKey."""
    body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode()
    sig = private_key.sign(body)
    enc = lambda b: base64.urlsafe_b64encode(b).decode().rstrip("=")  # noqa: E731
    return f"{KEY_PREFIX}{enc(body)}.{enc(sig)}"


def sign_data(payload: dict, private_key) -> dict:
    """Owner side: {"payload", "signature"} for data the app must be able to trust, e.g. a law update's manifest."""
    body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode()
    enc = lambda b: base64.urlsafe_b64encode(b).decode().rstrip("=")  # noqa: E731
    return {"payload": enc(body), "signature": enc(private_key.sign(body))}


def verify_data(signed: dict, public_key: str = PUBLIC_KEY) -> dict:
    """The payload of data signed with sign_data, after checking the owner's signature; raises LicenceError if it
    isn't genuine."""
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    try:
        body, signature = _b64d(signed["payload"]), _b64d(signed["signature"])
        Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key)).verify(signature, body)
        return json.loads(body)
    except (InvalidSignature, ValueError, KeyError, TypeError):
        raise LicenceError("This update isn't signed by TaxDesk's owner.") from None


# ---------------------------------------------------------------- versions and control
def version_tuple(v: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", v or "0")[:4]) or (0,)


@dataclass
class Decision:
    allowed: bool = True
    title: str = ""
    message: str = ""           # blocking reason, or a notice to show
    notice: str = ""            # owner's announcement
    update: str = ""            # newer version available
    download_url: str = DOWNLOADS_URL
    clear_licence: bool = False
    usage_url: str = ""
    contact: str = ""
    require_licence: bool = True
    extra: dict[str, Any] = field(default_factory=dict)


def evaluate(control: dict | None, lic: Licence | None, version: str = __version__) -> Decision:
    """What the app should do given the owner's control file and this copy's licence."""
    c = control or {}
    d = Decision(download_url=c.get("download_url") or DOWNLOADS_URL, usage_url=c.get("usage_url", ""),
                 contact=c.get("contact", ""), require_licence=bool(c.get("require_licence", True)))
    if c.get("enabled") is False:
        return Decision(False, "TaxDesk is not available", c.get("message") or "The owner has switched TaxDesk off.",
                        download_url=d.download_url, contact=d.contact)
    if c.get("min_version") and version_tuple(version) < version_tuple(c["min_version"]):
        return Decision(False, "Update required", f"This version ({version}) is no longer supported. Please install "
                        f"version {c['min_version']} or later.", download_url=d.download_url, contact=d.contact)
    if lic and lic.id in set(c.get("revoked", [])):
        return Decision(False, "Licence withdrawn", f"The licence for {lic.name or lic.id} has been withdrawn.",
                        clear_licence=True, download_url=d.download_url, contact=d.contact)
    if c.get("latest_version") and version_tuple(c["latest_version"]) > version_tuple(version):
        d.update = f"TaxDesk {c['latest_version']} is available (you have {version})."
    d.notice = c.get("message", "") if c.get("enabled", True) else ""
    return d


def fetch_control(url: str = CONTROL_URL, timeout: float = 5) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": f"TaxDesk/{__version__}", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 - fixed https URL
        return json.loads(r.read().decode("utf-8"))


def control_with_cache(settings, fetch=fetch_control) -> tuple[dict | None, bool, int | None]:
    """(control, fresh, days since the last successful check). Falls back to the cached copy when offline."""
    try:
        control = fetch()
        settings.setValue("control/json", json.dumps(control))
        settings.setValue("control/checked", datetime.now().isoformat(timespec="seconds"))
        return control, True, 0
    except Exception:  # noqa: BLE001 - offline or blocked: use the cache
        cached = settings.value("control/json")
        checked = settings.value("control/checked")
        days = (datetime.now() - datetime.fromisoformat(str(checked))).days if checked else None
        return (json.loads(cached) if cached else None), False, days


# ---------------------------------------------------------------- anonymous usage count
def install_id(settings) -> str:
    iid = settings.value("install/id")
    if not iid:
        iid = uuid.uuid4().hex
        settings.setValue("install/id", iid)
    return str(iid)


def usage_payload(settings, lic: Licence | None) -> dict:
    return {"install": install_id(settings), "version": __version__, "os": platform.system(),
            "licence": lic.id if lic else "", "date": date.today().isoformat()}


def report_usage(url: str, payload: dict) -> None:
    """Send the anonymous usage record in the background; failures are ignored."""
    if not url.startswith("https://"):
        return

    def send() -> None:
        try:
            req = urllib.request.Request(url, data=json.dumps(payload).encode(), method="POST",
                                         headers={"Content-Type": "application/json",
                                                  "User-Agent": f"TaxDesk/{__version__}"})
            urllib.request.urlopen(req, timeout=8).read()  # noqa: S310
        except Exception:  # noqa: BLE001 - usage counting must never disturb the user
            pass
    threading.Thread(target=send, daemon=True).start()
