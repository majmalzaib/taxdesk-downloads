"""Withholding statements (section 165).

A withholding agent (employer, company, bank, government department...) deducts tax when paying
and files a periodic statement listing every payee, the section, the amount paid and the tax deducted.
The payee then claims that tax in their own return: adjustable, final or minimum, by section.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .rules import Rules, load, money


def blank_statement(year: int) -> dict[str, Any]:
    return {"kind": "wht", "tax_year": year, "agent": {"name": "", "ntn": "", "period": "Quarter 1"}, "rows": []}


@dataclass
class CheckedRow:
    index: int
    payee: str
    section: str
    title: str
    nature: str
    gross: float
    rate: float | None
    expected: float | None
    deducted: float
    note: str

    @property
    def difference(self) -> float | None:
        return None if self.expected is None else round(self.deducted - self.expected, 2)


def _n(v: Any) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def check(statement: dict[str, Any], rules: Rules | None = None) -> list[CheckedRow]:
    """Each row with the tax that should have been deducted and the difference."""
    rules = rules or load(int(statement.get("tax_year") or 2025))
    out = []
    for i, row in enumerate(statement.get("rows", []), start=1):
        info = rules.withholding(str(row.get("section")))
        atl = bool(row.get("payee_atl", True))
        rate = row.get("rate")
        rate = _n(rate) / 100 if rate not in (None, "") else (
            info.get("rate") if atl else info.get("rate_non_atl") or (info["rate"] * 2 if info.get("rate") else None))
        gross, deducted = _n(row.get("gross")), _n(row.get("deducted"))
        expected = round(gross * rate, 2) if rate is not None else None
        if expected is None:
            note = info.get("note") or "Enter the rate that applies to this payment."
        elif abs(deducted - expected) < 1:
            note = "Deducted correctly."
        elif deducted < expected:
            note = (f"Short by {money(expected - deducted)}. The agent is personally liable for tax not deducted "
                    "(section 161), with default surcharge, and the expense may be disallowed (section 21(c)).")
        else:
            note = f"Excess of {money(deducted - expected)} deducted; the payee claims it in their return."
        if not atl and rate is not None:
            note += " Payee not on the Active Taxpayers List: higher rate."
        out.append(CheckedRow(i, str(row.get("payee", "")), info["section"], info["title"], info["nature"], gross,
                              rate, expected, deducted, note))
    return out


def summary(rows: list[CheckedRow]) -> dict[str, float]:
    return {
        "payments": sum(r.gross for r in rows),
        "deducted": sum(r.deducted for r in rows),
        "expected": sum(r.expected or 0 for r in rows),
        "short": sum(-(r.difference or 0) for r in rows if (r.difference or 0) < 0),
    }


def to_return_entries(statement: dict[str, Any], payee: str) -> list[dict[str, Any]]:
    """The certificate entries a given payee would carry into their own return."""
    return [{"section": r.get("section"), "amount": _n(r.get("deducted")), "agent": statement["agent"].get("name", ""),
             "certificate": f"{statement['agent'].get('period', '')}"}
            for r in statement.get("rows", []) if str(r.get("payee", "")).strip().lower() == payee.strip().lower()]
