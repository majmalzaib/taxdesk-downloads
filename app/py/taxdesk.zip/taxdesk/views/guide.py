"""The practice guide as HTML: each head of income and sales tax in detail, and the flow of filling each return."""
from __future__ import annotations

import html

from .. import guide, law
from . import palette

# where each kind of point is marked: tick for what counts or is allowed, cross for what isn't
MARKS = {guide.INCLUDED: ("✔", "success"), guide.ALLOWED: ("✔", "success"), guide.DISALLOWED: ("✘", "danger"),
         guide.EXCLUDED: ("○", "muted"), "Admissible": ("✔", "success"), "Inadmissible": ("✘", "danger"),
         "Not admissible": ("✘", "danger")}


FLOW_OF = {"ITO": "itr_flow", "STA": "str_flow"}


def _c(name: str, light: bool) -> str:
    """A theme colour; the light palette for a page printed to PDF."""
    return palette.color(name, light)


def _sources(act: str) -> str:
    acts = ("ITO", "ITR") if act == "ITO" else ("STA", "STR")
    return "; ".join(law.text_source(a) or law.index_source(a) or law.ACTS[a] for a in acts)


def _footer(act: str) -> str:
    return (f"<p style='color:gray; font-size:11px'>Written from the wording of the law ({html.escape(_sources(act))}). "
            "Click a section or rule to read it. Rates change with each Finance Act: see Rules &amp; rates.</p>")


def topic_html(t: guide.Topic, light: bool = False) -> str:
    out = (f"<h2>{html.escape(t.title)}</h2>"
           f"<p style='color:gray'>{html.escape(t.group)} · {law.linkify(t.law, t.act)}</p>"
           f"<p><b>{law.linkify(t.summary, t.act)}</b></p>")
    for heading, points in t.parts:
        mark, color = MARKS.get(heading, ("•", "accent"))
        out += (f"<h3 style='color:{_c(color, light)}'>{mark} {html.escape(heading)}</h3><ul>"
                + "".join(f"<li style='margin-bottom:4px'>{law.linkify(p, t.act)}</li>" for p in points) + "</ul>")
    if t.example:
        e = t.example
        rows = ""
        for text, amount in e.rows:
            total = amount.startswith("=")
            style = f" style='border-top:1px solid {_c('border', light)}; font-weight:bold'" if total else ""
            rows += (f"<tr><td{style}>{law.linkify(text, t.act)}</td>"
                     f"<td align='right'{style}>{html.escape(amount.lstrip('='))}</td></tr>")
        out += (f"<h3>Worked example: {html.escape(e.title)}</h3>"
                f"<table width='100%' cellspacing='0' cellpadding='5' style='background:{_c('surface2', light)}'>"
                f"<tr><th align='left'>Item</th><th align='right'>Rs</th></tr>{rows}</table>"
                + (f"<p>{law.linkify(e.result, t.act)}</p>" if e.result else ""))
    flow = guide.BY_ID.get(FLOW_OF.get(t.act, ""))
    if flow:
        out += f"<p>Where this goes in the return: <a href='guide:{flow.id}'>{html.escape(flow.title)} →</a></p>"
    return f"<div style='font-size:13px; line-height:1.45'>{out}{_footer(t.act)}</div>"


def _children_html(steps: tuple[guide.Step, ...], number: str, act: str) -> str:
    if not steps:
        return ""
    items = ""
    for i, s in enumerate(steps, 1):
        n = f"{number}.{i}"
        items += (f"<li style='margin-bottom:4px'><b>{n} {html.escape(s.title)}</b> "
                  f"<span style='color:gray'>· {law.linkify(s.law, act)}</span><br>{law.linkify(s.what, act)}"
                  f"{_children_html(s.children, n, act)}</li>")
    return f"<ul style='list-style-type:none'>{items}</ul>"


def flow_html(f: guide.Flow, light: bool = False) -> str:
    """The steps as numbered boxes joined by arrows, with sub-steps nested inside their box."""
    out = (f"<h2>{html.escape(f.title)}</h2><p style='color:gray'>Filing flow · {law.linkify(f.law, f.act)}</p>"
           f"<p><b>{html.escape(f.summary)}</b></p>")
    for i, s in enumerate(f.steps, 1):
        if i > 1:
            out += f"<p align='center' style='color:{_c('accent', light)}; font-size:16px; margin:2px'>▼</p>"
        out += (f"<table width='100%' cellspacing='0' cellpadding='8' style='background:{_c('surface2', light)}'><tr>"
                f"<td width='34' align='center' valign='top' style='background:{_c('accent', light)}; color:white; "
                f"font-weight:bold'>{i}</td>"
                f"<td valign='top'><b>{html.escape(s.title)}</b> "
                f"<span style='color:gray'>· {law.linkify(s.law, f.act)}</span><br>{law.linkify(s.what, f.act)}"
                f"{_children_html(s.children, str(i), f.act)}</td></tr></table>")
    return f"<div style='font-size:13px; line-height:1.45'>{out}{_footer(f.act)}</div>"


def item_html(item: guide.Topic | guide.Flow, light: bool = False) -> str:
    return flow_html(item, light) if isinstance(item, guide.Flow) else topic_html(item, light)
