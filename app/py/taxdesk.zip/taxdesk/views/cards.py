"""The law as HTML: a section or rule's card, the arrangement of every law (References) and what a search found."""
from __future__ import annotations

import html

from .. import forms, knowledge, law, planning

def concept_act(c: knowledge.Concept) -> str:
    return "STA" if c.area == "Sales tax" else law.act_for(c.law)


def _refs(text: str, act: str) -> set[tuple[str, str]]:
    return law.cited(text, act)


def ref_title(act: str, key: str) -> str:
    if "Schedule" in key or "Division" in key:
        return key
    return f"Rule {key}" if act in ("ITR", "STR") else f"Section {key}"


def users_of(act: str, key: str) -> tuple[list, list]:
    """Concepts and planning options that cite this section or rule."""
    concepts = [c for c in knowledge.CONCEPTS if (act, key) in _refs(c.law, concept_act(c))]
    options = [o for o in planning.OPTIONS if (act, key) in _refs(o.law, law.act_for(o.law))]
    return concepts, options


def section_card_html(act: str, key: str, highlight: str = "") -> str:
    """The card for a section or rule: what it is, where it sits, what uses it, and then its wording from FBR's
    consolidated text with the amendment notes. Words matching highlight are marked in the wording."""
    official = law.official(act, key)
    head = law.heading(act, key)
    note = law.SECTIONS.get((act, key), "")
    kind = ("division" if "Division" in key else "schedule" if "Schedule" in key else "rule" if act in ("ITR", "STR")
            else "section")
    within = key.startswith(("First Schedule, ", "Chapter "))  # a division or part: look for it within its place
    find = key.split(", ")[-1] if within else key if kind == "schedule" else key + "."
    see = (law.text(act, key) or {}).get("see", "")
    concepts, options = users_of(act, key)
    out = (f"<h2>{html.escape(ref_title(act, key))}{': ' + html.escape(head) if head else ''} "
           f"<span style='font-size:13px; color:gray'>· {law.ABBR[act]}</span></h2>"
           f"<p style='color:gray'>{law.ACTS[act]}"
           + (f" › {html.escape(law.location(act, key))}" if law.location(act, key) else "") + "</p>"
           + ("<p style='color:#c2410c'><b>This provision has been omitted from the law.</b></p>"
              if official and official.get("omitted") else "")
           + (f"<p><b>{html.escape(note)}</b></p>" if note and note != head else "")
           + (f"<p style='color:gray'>{law.linkify(see, act)}</p>" if see else "")
           + ("" if official or note or head else "<p>Not in TaxDesk's index.</p>")
           + f"<p><a href='{law.OFFICIAL[act]}'>Official text: {law.ACTS[act]} on FBR's website →</a><br>"
           f"<span style='color:gray'>Open the latest consolidated version and search for "
           f"“{html.escape(find)}”{' in ' + html.escape(law.location(act, key)) if within else ''}.</span><br>"
           f"<a href='{law.search_url(act, key)}'>Search the web for this {kind} →</a></p>")
    sections = law.division_sections(act, key)
    if sections:
        out += "<h3>Sections in this Division</h3><ul>" + "".join(
            f"<li><a href='law:{act}:{e['num']}'>Section {e['num']}</a>: {html.escape(e['title'])}</li>"
            for e in sections) + "</ul>"
    if key == "First Schedule" and law.schedule_divisions(act):  # read a division at a time
        out += "<h3>Its parts and divisions</h3><ul>" + "".join(
            f"<li><a href='law:{act}:{k}'>{html.escape(k.split(', ', 1)[1])}</a>: "
            f"{html.escape(law.heading(act, k) or law.SECTIONS.get((act, k), ''))}</li>"
            for k in law.schedule_divisions(act)) + "</ul>"
    rules = law.related_rules(act, key)
    if rules:
        out += "<h3>Rules made under it</h3><ul>" + "".join(
            f"<li><a href='law:{a}:{k}'>{ref_title(a, k)}, {law.ABBR[a]}</a>: {html.escape(law.describe(a, k))}</li>"
            for a, k in rules) + "</ul>"
    parents = [sec for sec, rs in law.SECTION_RULES.items() if (act, key) in rs]
    if parents:
        out += "<h3>Made under</h3><ul>" + "".join(
            f"<li><a href='law:{a}:{k}'>{ref_title(a, k)}, {law.ABBR[a]}</a>: {html.escape(law.describe(a, k))}</li>"
            for a, k in parents) + "</ul>"
    prescribed = forms.prescribed_by(act, key)
    if prescribed:
        out += "<h3>Forms it prescribes</h3><ul>" + "".join(
            f"<li><a href='form:{act}:{f.index}'>{html.escape(f.name)}</a>: {html.escape(f.title)}</li>"
            for f in prescribed) + "</ul>"
    if concepts:
        out += "<h3>Concepts based on it</h3><ul>" + "".join(
            f"<li><a href='{c.id}'>{html.escape(c.title)}</a>: {html.escape(c.summary)}</li>" for c in concepts) + "</ul>"
    if options:
        out += "<h3>Planning options</h3><ul>" + "".join(f"<li>{html.escape(o.title)}</li>" for o in options) + "</ul>"
    wording = law.text_html(act, key, highlight)
    if not wording and key.startswith("First Schedule, "):
        out += ("<p style='color:gray'>TaxDesk doesn't have the wording of this Division; it may have been omitted. "
                f"Read the First Schedule in the <a href='{law.OFFICIAL[act]}'>official PDF</a>.</p>")
    if wording:
        out += (f"<h3>Text of the {kind}</h3><p style='color:gray'>From the {html.escape(law.text_source(act))}. "
                "Words in [brackets] were changed by the amendment in the note with the same number. Tables and "
                f"formulas read best in the <a href='{law.OFFICIAL[act]}'>official PDF</a>.</p>"
                f"<div style='font-size:13.5px; line-height:1.5'>{wording}</div>")
    return f"<div style='font-size:13px; line-height:1.45'>{out}</div>"


def references_html() -> str:
    """Every section and rule TaxDesk refers to, grouped by law."""
    out = ("<h2>References</h2><p>The complete arrangement of each law, from FBR's consolidated texts. Click a section "
           "or rule to see what it covers, the rules made under it and the concepts built on it. Omitted provisions are "
           "shown in grey. Jump to: "
           + " · ".join(f"<a href='#{a}'>{law.ACTS[a]}</a>" for a in law.ACTS)
           + " · Schedules of the <a href='#ITO-schedules'>Ordinance</a> and the <a href='#STA-schedules'>Act</a>"
           + " · <a href='#ITO-schedule'>First Schedule (rates)</a></p>")
    concept_map: dict[tuple[str, str], list] = {}
    for c in knowledge.CONCEPTS:
        for ref in _refs(c.law, concept_act(c)):
            concept_map.setdefault(ref, []).append(c)
    for act in law.ACTS:
        out += (f"<a name='{act}'></a><h2>{law.ACTS[act]}</h2><p style='color:gray'>{html.escape(law.index_source(act))}"
                f" · <a href='{law.OFFICIAL[act]}'>official text on FBR's website</a></p>")
        group = None
        rows: list[str] = []

        def flush() -> None:
            nonlocal rows, out
            if rows:
                out += ("<table border=1 cellpadding=3 cellspacing=0 width='100%'>"
                        "<tr><th width='12%'>No.</th><th>Heading</th><th width='34%'>Concepts</th></tr>"
                        + "".join(rows) + "</table>")
                rows = []
        for e in law.index_items(act):
            g = (e.get("chapter"), e.get("part"))
            if g != group:
                flush()
                group = g
                title = " › ".join(x for x in (
                    f"Chapter {e['chapter']} {e.get('chapter_title', '').title()}" if e.get("chapter") else "",
                    f"Part {e['part']} {e.get('part_title', '').title()}" if e.get("part") else "") if x)
                out += f"<h4>{html.escape(title)}</h4>"
            used = ", ".join(f"<a href='{c.id}'>{html.escape(c.title)}</a>" for c in concept_map.get((act, e["num"]), []))
            grey = " style='color:gray'" if e.get("omitted") else ""
            rows.append(f"<tr{grey}><td><a href='law:{act}:{e['num']}'>{e['num']}</a></td><td>{html.escape(e['title'])}</td>"
                        f"<td>{used or '—'}</td></tr>")
        flush()
        if law.schedules(act):
            out += f"<a name='{act}-schedules'></a><h3>Schedules</h3>"
        for key in law.schedules(act):
            used = ", ".join(f"<a href='{c.id}'>{html.escape(c.title)}</a>" for c in concept_map.get((act, key), []))
            title = law.heading(act, key) or law.SECTIONS.get((act, key), "")
            grey = " style='color:gray'" if title.startswith("Omitted") else ""
            rows.append(f"<tr{grey}><td><a href='law:{act}:{key}'>{html.escape(key)}</a></td>"
                        f"<td>{html.escape(title)}</td><td>{used or '—'}</td></tr>")
        flush()
        if law.schedule_divisions(act):  # the First Schedule's rates, a division at a time
            out += (f"<a name='{act}-schedule'></a><h3>First Schedule: rates of tax</h3><p style='color:gray'>Each "
                    "division of the Schedule, with its wording from the same consolidated text.</p>")
        for key in law.schedule_divisions(act):
            g = key.split(", ")[1]
            if g != group:
                flush()
                group = g
                out += f"<h4>{html.escape(g)}</h4>"
            used = ", ".join(f"<a href='{c.id}'>{html.escape(c.title)}</a>" for c in concept_map.get((act, key), []))
            title = law.heading(act, key) or law.SECTIONS.get((act, key), "")
            rows.append(f"<tr><td><a href='law:{act}:{key}'>{html.escape(key.split(', ')[-1])}</a></td>"
                        f"<td>{html.escape(title)}</td><td>{used or '—'}</td></tr>")
        flush()
    return f"<div style='font-size:13px; line-height:1.4'>{out}</div>"


def search_html(q: str, hits: list) -> str:
    """The References search's results: the provisions found by number or heading, then those whose wording has the
    words, each with the sentence they appear in."""
    if not hits:
        return (f"<p style='color:gray'>Nothing matches “{html.escape(q)}”. Try a number (153, 37A), a reference "
                "(rule 44, Second Schedule, Division VIII of Part I) or other words.</p>")
    mark = law.marker(q)

    def row(act: str, key: str, title: str, snippet: str, how: str) -> str:
        what = ref_title(act, key) if "Schedule" in key or "Division" in key else \
            f"{'Rule' if act in ('ITR', 'STR') else 'Section'} {key}"
        link = f"{'find' if how == 'wording' else 'law'}:{act}:{key}"
        found = (f"<br><span style='color:gray'>{mark.sub(lambda m: f'<b>{m.group(0)}</b>', html.escape(snippet))}"
                 "</span>") if snippet else ""
        return (f"<tr><td width='9%' style='color:gray'>{law.ABBR[act]}</td><td><a href='{link}'><b>{html.escape(what)}"
                f"</b></a>{': ' + html.escape(title) if title else ''}{found}</td></tr>")
    named = [h for h in hits if h[4] != "wording"]
    worded = [h for h in hits if h[4] == "wording"]
    out = "<p style='color:gray'>Press Enter to open the first. Click any to open its card.</p>"
    if named:
        out += ("<h3>Sections, rules and Schedules</h3><table cellpadding=4 cellspacing=0 width='100%'>"
                + "".join(row(*h) for h in named) + "</table>")
    if worded:
        out += (f"<h3>In the wording of the law</h3><p style='color:gray'>Opening one marks “{html.escape(q)}” in its "
                "text.</p><table cellpadding=4 cellspacing=0 width='100%'>" + "".join(row(*h) for h in worded)
                + "</table>")
    return f"<div style='font-size:13px; line-height:1.45'>{out}</div>"
