"""TaxDesk's colours, for the desktop app's theme and for HTML wherever it's shown (the desktop app, the web app)."""
from __future__ import annotations

PALETTES = {
    "dark": dict(
        bg="#0f1117", surface="#171a22", surface2="#1f232d", border="#2a2f3b",
        text="#e7e9ef", muted="#8a92a6", accent="#0d9488", accent_hover="#14b8a6",
        success="#22c55e", warning="#f59e0b", danger="#f05252", selection="#2a2c58",
    ),
    "light": dict(
        bg="#f4f5f9", surface="#ffffff", surface2="#f1f3f8", border="#e1e4ec",
        text="#1a1e29", muted="#697186", accent="#0f766e", accent_hover="#0d9488",
        success="#16a34a", warning="#d97706", danger="#dc2626", selection="#e3e6ff",
    ),
}


# Categorical series colors, validated for colour-vision deficiency against each surface.
# Assigned in fixed order and never cycled; extra series fold into "Other".
CHART_COLORS = {
    "light": ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"],
    "dark": ["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#008300"],
}

current = "dark"  # the palette in use, set by the app's theme


def color(name: str, light: bool = False) -> str:
    """A colour of the palette in use, as #rrggbb; the light palette for a page printed or saved as PDF."""
    return PALETTES["light" if light else current][name]
