"""Law changes as HTML: one change, with the amendment behind it and the old wording against the new."""
from __future__ import annotations

import html

from .. import changes, law
from . import palette
from .cards import ref_title

KIND_COLOR = {"new": "success", "omitted": "danger", "changed": "warning"}


def heading(c: changes.Change) -> str:
    """The heading now, or for a division that has gone, last year's."""
    return (law.heading(c.act, c.key) or (changes.previous(c.act, c.key) or {}).get("title", "")
            or law.describe(c.act, c.key))


def change_html(c: changes.Change) -> str:
    """One change: what it is, the amendment behind it, and the old wording against the new."""
    head = heading(c)
    note = law.describe(c.act, c.key)
    color = palette.color(KIND_COLOR[c.kind])
    then, now = changes.edition(changes.previous_source(c.act)), changes.edition(law.text_source(c.act))
    out = (f"<h2>{html.escape(ref_title(c.act, c.key))}{': ' + html.escape(head) if head else ''} "
           f"<span style='font-size:13px; color:gray'>· {law.ABBR[c.act]}</span></h2>"
           f"<p><b style='color:{color}'>{changes.KINDS[c.kind]}</b> between the edition {html.escape(then)} and the "
           f"edition {html.escape(now)}"
           + (f" · <a href='law:{c.act}:{c.key}'>Open its card →</a>" if c.kind != "omitted" or law.text(c.act, c.key)
              else "") + "</p>"
           + (f"<p><b>{html.escape(note)}</b></p>" if note and note != head else ""))
    notes = changes.new_notes(c.act, c.key)
    if notes:
        out += ("<h3>The amendments</h3><p style='color:gray'>The notes in the current text that last year's didn't "
                "have.</p><ul>" + "".join(f"<li>{html.escape(n)}</li>" for n in notes) + "</ul>")
    if c.kind == "changed":
        out += (f"<h3>The wording, old against new</h3><p style='color:gray'>"
                f"<span style='{changes.DEL}'>Struck through</span>: last year's words that were removed. "
                f"<span style='{changes.INS}'>Highlighted</span>: words added since. Unchanged paragraphs away from a "
                "change are folded. Tables read best in the official PDF.</p>"
                f"<div style='font-size:13.5px; line-height:1.5'>{changes.diff_html(c.act, c.key)}</div>")
    else:
        which = "Its wording now" if c.kind == "new" else "Its wording last year"
        text = (law.text_html(c.act, c.key) if c.kind == "new"
                else "".join(f"<p style='margin:0 0 6px {p[0] * 22}px'>{html.escape(changes._MARK.sub('', p[1]))}</p>"
                             for p in (changes.previous(c.act, c.key) or {}).get("paras", [])))
        out += f"<h3>{which}</h3><div style='font-size:13.5px; line-height:1.5'>{text}</div>"
    return f"<div style='font-size:13px; line-height:1.45'>{out}</div>"
