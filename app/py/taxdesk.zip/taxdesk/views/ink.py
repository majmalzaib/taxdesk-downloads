"""Handwritten notes: the ink format both apps keep, and ink drawn as SVG (the web app shows it as it is).

Ink is JSON: {"w": 1000, "h": 700, "strokes": [{"c": "#1f2937", "s": 3.0, "p": [[x, y, pressure], …]}, …]}. Points are
on a page 1000 units wide, whatever the screen, so a note looks the same on the computer and the iPad; pressure is 0 to
1 (0.5 from a mouse or finger), and s is the pen's width at full pressure.
"""
from __future__ import annotations

import html
import json

WIDTH, HEIGHT = 1000, 700
PENS = {"ink": "#1f2937", "blue": "#1d4ed8", "red": "#b91c1c", "green": "#15803d"}
SIZES = {"fine": 2.0, "medium": 3.5, "thick": 6.0}


def blank() -> dict:
    return {"w": WIDTH, "h": HEIGHT, "strokes": []}


def load(text: str | None) -> dict:
    """Ink from its JSON, or a blank page."""
    try:
        ink = json.loads(text) if text else blank()
        return ink if isinstance(ink, dict) and isinstance(ink.get("strokes"), list) else blank()
    except ValueError:
        return blank()


def dump(ink: dict) -> str:
    """Ink as compact JSON, its points rounded (a page of writing in a few kilobytes); '' when nothing is written."""
    strokes = [{"c": s.get("c", PENS["ink"]), "s": round(float(s.get("s", 3)), 1),
                "p": [[round(x, 1), round(y, 1), round(p, 2)] for x, y, p in s.get("p", [])]}
               for s in ink.get("strokes", []) if s.get("p")]
    if not strokes:
        return ""
    return json.dumps({"w": ink.get("w", WIDTH), "h": ink.get("h", HEIGHT), "strokes": strokes}, separators=(",", ":"))


def width(stroke: dict, pressure: float) -> float:
    """A pen's width at a pressure: from a third of the pen at the lightest touch to the full pen."""
    return float(stroke.get("s", 3)) * (0.35 + 0.65 * max(0.0, min(1.0, pressure)))


def svg(ink: dict, shown_width: int = 640) -> str:
    """The ink as an SVG drawing, scaled to shown_width pixels, each segment as thick as the pressure on it."""
    w, h = ink.get("w", WIDTH), ink.get("h", HEIGHT)
    used = max((y for s in ink.get("strokes", []) for _, y, _ in s.get("p", [])), default=0)
    h = min(h, used + 40) if used else 80  # no empty paper below the writing
    lines = []
    for s in ink.get("strokes", []):
        pts, color = s.get("p", []), html.escape(s.get("c", PENS["ink"]))
        if len(pts) == 1:
            x, y, p = pts[0]
            lines.append(f"<circle cx='{x}' cy='{y}' r='{width(s, p) / 2:.1f}' fill='{color}'/>")
        for (x1, y1, p1), (x2, y2, p2) in zip(pts, pts[1:]):
            lines.append(f"<line x1='{x1}' y1='{y1}' x2='{x2}' y2='{y2}' stroke='{color}' "
                         f"stroke-width='{width(s, (p1 + p2) / 2):.1f}' stroke-linecap='round'/>")
    return (f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {w} {h:.0f}' width='{shown_width}' "
            f"height='{shown_width * h / w:.0f}'>{''.join(lines)}</svg>")
