"""The Law library as HTML: each law chapter by chapter, its forms, and what a search of the law found."""
from __future__ import annotations

import html
import re
from typing import Callable

from .. import forms as forms_mod
from .. import law
from .cards import ref_title, section_card_html

ORDER = ("ITR", "STR", "ITO", "STA")  # the Rules first


def _title(text: str) -> str:
    """'DETERMINATION OF INCOME - HEADS OF INCOME' -> 'Determination of income - heads of income'; '' for a title that
    only repeats its number ('CHAPTER - I', 'PART-I')."""
    if re.fullmatch(r"\s*(chapter|part)\s*-?\s*[ivxl]+[a-z]?\s*", text, re.I):
        return ""
    return text[:1].upper() + text[1:].lower() if text.isupper() else text


def chapters(act: str) -> list[tuple[str, list[dict]]]:
    """[(label, provisions)] in the law's order: its chapters, and within a chapter each part."""
    out: list[tuple[str, list[dict]]] = []
    group = None
    for e in law.index_items(act):
        g = (e.get("chapter"), e.get("part"))
        if g != group:
            group = g
            label = " › ".join(x for x in (
                f"Chapter {e['chapter']}" + (f": {_title(e['chapter_title'])}" if _title(e.get("chapter_title", "")) else "")
                if e.get("chapter") else "",
                f"Part {e['part']}" + (f": {_title(e['part_title'])}" if _title(e.get("part_title", "")) else "")
                if e.get("part") else "") if x) or "Preliminary"
            out.append((label, []))
        out[-1][1].append(e)
    return out


def provision_label(act: str, e: dict) -> str:
    what = "Rule" if act in ("ITR", "STR") else "Section"
    return f"{what} {e['num']}  {e['title']}" if not e.get("omitted") else f"{what} {e['num']}  (omitted)"


def form_html(f: forms_mod.Form, picture: Callable[[forms_mod.Form], str] | None = None) -> str:
    """A form: what it is, the rule behind it, where it is in FBR's text, and a picture of its first page (picture
    gives its address: the file on the desktop, by default)."""
    pdf, edition = forms_mod.source(f.act)
    rules = ", ".join(f"<a href='law:{f.act}:{r}'>rule {r}</a>" for r in f.rules)
    pages = f"page {f.pages[0]}" if f.page_count == 1 else f"pages {f.pages[0]}–{f.pages[1]}"
    picture = picture(f) if picture else f.picture.as_uri()
    return (f"<div style='font-size:13px; line-height:1.45'><h2>{html.escape(f.name)}: {html.escape(f.title)} "
            f"<span style='font-size:13px; color:gray'>· {law.ABBR[f.act]}</span></h2>"
            f"<p style='color:gray'>{law.ACTS[f.act]} › {html.escape(f.group)}</p>"
            + (f"<p><b>Prescribed by</b> {rules}.</p>" if rules else "")
            + f"<p>{pages.capitalize()} of FBR's consolidated text ({html.escape(edition)}). "
            f"<a href='{pdf}#page={f.pages[0]}'>Open the whole form in FBR's PDF →</a></p>"
            f"<p style='color:gray'>Its first page, as FBR prints it:</p>"
            f"<p><img src='{picture}' width='760'></p></div>")


def law_html(act: str) -> str:
    rows = "".join(f"<li><a href='chapter:{act}:{i}'>{html.escape(label)}</a> "
                   f"<span style='color:gray'>({len(items)})</span></li>" for i, (label, items) in enumerate(chapters(act)))
    extra = ""
    if law.schedules(act):
        extra += f"<p><a href='schedules:{act}'>Its Schedules ({len(law.schedules(act))}) →</a></p>"
    if forms_mod.forms(act):
        extra += (f"<p><a href='forms:{act}'>The documents and forms it prescribes "
                  f"({len(forms_mod.forms(act))}) →</a></p>")
    return (f"<div style='font-size:13px; line-height:1.45'><h2>{law.ACTS[act]}</h2>"
            f"<p style='color:gray'>{html.escape(law.text_source(act))} · "
            f"<a href='{law.OFFICIAL[act]}'>official text on FBR's website</a></p>{extra}"
            f"<h3>Chapters</h3><ul>{rows}</ul></div>")


def results_html(query: str, hits: dict[tuple[str, str], tuple[str, str]]) -> str:
    """What a search found, law by law: each provision with the sentence the words are in, then the forms. hits is
    {(act, key): (how found, sentence)}, from law.find."""
    mark = law.marker(query)
    out = (f"<h2>Results for “{html.escape(query)}”</h2><p style='color:gray'>Sections, rules and Schedules whose "
           "number, heading or wording has it, in each law. Opening one marks the words in its text.</p>")
    for act in ORDER:
        found = [(k, how, snippet) for (a, k), (how, snippet) in hits.items() if a == act]
        fs = [f for f in forms_mod.forms(act) if query.lower() in f"{f.name} {f.title} {f.group}".lower()]
        if not found and not fs:
            continue
        out += f"<h3>{law.ACTS[act]} <span style='color:gray; font-size:12px'>({len(found) + len(fs)})</span></h3><ul>"
        for k, how, snippet in found:
            sentence = mark.sub(lambda m: f"<b>{m.group(0)}</b>", html.escape(snippet))
            out += (f"<li><a href='law:{act}:{k}'>{html.escape(ref_title(act, k))}</a>: "
                    f"{html.escape(law.heading(act, k) or law.describe(act, k))}"
                    + (f"<br><span style='color:gray'>{sentence}</span>" if snippet else "") + "</li>")
        out += "".join(f"<li><a href='form:{act}:{f.index}'>{html.escape(f.name)}</a>: {html.escape(f.title)} "
                       "<span style='color:gray'>(form)</span></li>" for f in fs) + "</ul>"
    return f"<div style='font-size:13px; line-height:1.45'>{out}</div>"


def list_html(title: str, rows: list[tuple[str, str, str, bool]]) -> str:
    items = "".join(f"<li{' style=color:gray' if omitted else ''}><a href='{href}'>{html.escape(name)}</a>: "
                    f"{html.escape(heading)}</li>" for href, name, heading, omitted in rows)
    return f"<div style='font-size:13px; line-height:1.45'><h2>{html.escape(title)}</h2><ul>{items}</ul></div>"


def forms_html(act: str, group: str | None) -> str:
    pdf, edition = forms_mod.source(act)
    out = (f"<h2>{law.ACTS[act]} › Forms & formats{' › ' + html.escape(group) if group else ''}</h2>"
           f"<p style='color:gray'>The documents and forms the Rules prescribe, from FBR's consolidated text "
           f"({html.escape(edition)}). Open one to see the rule behind it and its first page.</p>")
    for g in ([group] if group else forms_mod.groups(act)):
        out += f"<h3>{html.escape(g)}</h3><ul>" + "".join(
            f"<li><a href='form:{act}:{f.index}'>{html.escape(f.name)}</a>: {html.escape(f.title)}"
            + (f" <span style='color:gray'>(rule {', '.join(f.rules)})</span>" if f.rules else "") + "</li>"
            for f in forms_mod.forms(act) if f.group == g) + "</ul>"
    return f"<div style='font-size:13px; line-height:1.45'>{out}</div>"


def page_html(ref: str, query: str = "", hits: dict | None = None,
              picture: Callable[[forms_mod.Form], str] | None = None) -> str:
    """What the library shows for a reference: results:, law:ACT, law:ACT:KEY, chapter:ACT:N, schedules:ACT,
    forms:ACT, formgroup:ACT:N or form:ACT:N. A provision found by a search has the words marked."""
    hits = hits or {}
    kind, _, rest = ref.partition(":")
    act, _, key = rest.partition(":")
    if kind == "results":
        return results_html(query, hits)
    if kind == "law" and key:
        return section_card_html(act, key, query if (act, key) in hits else "")
    if kind == "law":
        return law_html(act)
    if kind == "chapter":
        label, items = chapters(act)[int(key)]
        return list_html(f"{law.ACTS[act]} › {label}", [
            (f"law:{act}:{e['num']}", ref_title(act, e["num"]), e["title"], e.get("omitted")) for e in items])
    if kind == "schedules":
        return list_html(f"{law.ACTS[act]} › Schedules", [
            (f"law:{act}:{k}", k, law.heading(act, k) or law.describe(act, k), False) for k in law.schedules(act)])
    if kind == "forms":
        return forms_html(act, None)
    if kind == "formgroup":
        return forms_html(act, forms_mod.groups(act)[int(key)])
    if kind == "form":
        return form_html(forms_mod.forms(act)[int(key)], picture)
    return ""
