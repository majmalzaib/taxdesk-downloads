"""TaxDesk for the iPad: the Python side of the web app. It runs in the browser (Pyodide) with the same taxdesk package as
the desktop app, and gives the page what it shows, as JSON: the HTML comes from taxdesk.views, so the iPad shows exactly
what the desktop does."""
from __future__ import annotations

import copy
import html
import json

from taxdesk import __version__, assistant, cases, changes, forms, guide, knowledge, law, licence, planning, quiz, \
    returns, wealth
from taxdesk.law import cite, linkify
from taxdesk.rules import available_years, load, money
from taxdesk.views import cards, palette
from taxdesk.views import changes as changes_view
from taxdesk.views import guide as guide_view
from taxdesk.views import library

PICTURE = lambda f: f"forms/{f.image}"  # noqa: E731 - a form's picture, served beside the page
_bot: assistant.Bot | None = None


def _j(value) -> str:
    return json.dumps(value, ensure_ascii=False)


def start(dark: bool) -> str:
    """Set the colours to the iPad's light or dark appearance; the app's version and the law's editions."""
    palette.current = "dark" if dark else "light"
    return _j({"version": __version__, "editions": [law.text_source(a) for a in law.ACTS]})


# ---------------------------------------------------------------- licence
def check_licence(key: str, control_json: str, days_offline: int = 0) -> str:
    """Whether this copy may open, as on the desktop: a genuine licence key where the owner requires one, and
    control.json allowing it (not switched off, revoked or too old), read within the last 30 days."""
    try:
        lic = licence.parse_key(key) if key else None
    except licence.LicenceError as e:
        return _j({"ok": False, "need_key": True, "title": "", "message": str(e), "notice": "", "name": ""})
    control = json.loads(control_json) if control_json else None
    d = licence.evaluate(control, lic, __version__)
    need_key = d.allowed and d.require_licence and lic is None
    message = d.message
    if d.allowed and not need_key and days_offline > licence.OFFLINE_GRACE_DAYS:
        message = (f"TaxDesk hasn't been able to check your licence for {days_offline} days. Connect to the internet "
                   "and open it again.")
    return _j({"ok": d.allowed and not need_key and days_offline <= licence.OFFLINE_GRACE_DAYS, "need_key": need_key,
               "title": d.title, "message": message, "notice": d.notice, "name": lic.name if lic else ""})


# ---------------------------------------------------------------- practice guide
def guide_tree() -> str:
    groups = []
    for group in guide.GROUPS:
        items = [i for i in [*guide.TOPICS, *guide.FLOWS]
                 if (i.group if isinstance(i, guide.Topic) else guide.GROUPS[-1]) == group]
        if items:
            groups.append({"title": group, "items": [{"id": i.id, "title": i.title, "act": i.act} for i in items]})
    return _j(groups)


def guide_page(item_id: str) -> str:
    return guide_view.item_html(guide.BY_ID[item_id])


def guide_search(text: str) -> str:
    return _j([i.id for i in guide.search(text)])


# ---------------------------------------------------------------- the law
def linked(text: str, act: str = "ITO") -> str:
    """The user's own words (a note, a card) escaped, lines kept, sections and rules linked."""
    return linkify(text or "", act).replace("\n", "<br>")


def cited(text: str, act: str = "ITO") -> str:
    """A law reference that names its law: "Section 13; rule 5 · ITO 2001, IT Rules 2002"."""
    return cite(text or "", act)


def card(act: str, key: str, highlight: str = "") -> str:
    return cards.section_card_html(act, key, highlight)


def concept(cid: str) -> str:
    c = knowledge.BY_ID[cid]
    act = cards.concept_act(c)
    rel = "".join(f"<li>{'This' if d == '→' else ''} <i>{html.escape(label)}</i> "
                  f"<a href='{o}'>{html.escape(knowledge.BY_ID[o].title)}</a>{'' if d == '→' else ' → this'}</li>"
                  for d, label, o in knowledge.related(cid))
    used = [k.title for k in cases.CASES if cid in k.concepts]
    plans = [o.title for o in planning.OPTIONS if o.concept == cid]
    out = (f"<h2>{html.escape(c.title)}</h2><p style='color:gray'>{html.escape(c.area)} · {cite(c.law, act)}</p>"
           f"<p><b>{linkify(c.summary, act)}</b></p>"
           + (f"<p>{linkify(c.detail, act)}</p>" if c.detail else "")
           + (f"<p class='example'><b>Example:</b> {linkify(c.example, act)}</p>" if c.example else "")
           + (f"<h3>Relations</h3><ul>{rel}</ul>" if rel else "")
           + (f"<h3>Practised in</h3><p>{html.escape(', '.join(used))}</p>" if used else "")
           + (f"<h3>Planning options</h3><p>{html.escape(', '.join(plans))}</p>" if plans else ""))
    return f"<div>{out}</div>"


def library_tree() -> str:
    """Each law: its chapters with their provisions, its Schedules, and its forms."""
    out = []
    for act in library.ORDER:
        node = {"title": law.ACTS[act], "ref": f"law:{act}", "children": []}
        for i, (label, items) in enumerate(library.chapters(act)):
            node["children"].append({"title": label, "ref": f"chapter:{act}:{i}", "children": [
                {"title": library.provision_label(act, e), "ref": f"law:{act}:{e['num']}",
                 "omitted": bool(e.get("omitted"))} for e in items]})
        if law.schedules(act):
            node["children"].append({"title": "Schedules", "ref": f"schedules:{act}", "children": [
                {"title": f"{k}  {law.heading(act, k) or law.describe(act, k)}".strip(), "ref": f"law:{act}:{k}"}
                for k in law.schedules(act) + law.schedule_divisions(act)]})
        if forms.forms(act):
            node["children"].append({"title": f"Forms & formats ({len(forms.forms(act))})", "ref": f"forms:{act}",
                                     "children": [{"title": g, "ref": f"formgroup:{act}:{n}", "children": [
                                         {"title": f"{f.name}  {f.title}", "ref": f"form:{act}:{f.index}"}
                                         for f in forms.forms(act) if f.group == g]}
                                         for n, g in enumerate(forms.groups(act))]})
        out.append(node)
    return _j(out)


_hits: dict = {}


def library_search(query: str) -> str:
    """What a search of the law finds: the references it found, for the tree, and the results page."""
    global _hits
    q = query.strip()
    _hits = {(a, k): (how, snippet) for a, k, _, snippet, how in law.find(q, limit=300)} if q else {}
    found = [f"law:{a}:{k}" for a, k in _hits]
    found += [f"form:{a}:{f.index}" for a in library.ORDER for f in forms.forms(a)
              if q and q.lower() in f"{f.name} {f.title} {f.group}".lower()]
    return _j({"refs": found, "html": library.results_html(q, _hits) if q else ""})


def library_page(ref: str, query: str = "") -> str:
    return library.page_html(ref, query.strip(), _hits, PICTURE)


def references_search(query: str) -> str:
    return cards.search_html(query, law.find(query)) if query.strip() else ""


# ---------------------------------------------------------------- law changes
_changes: list | None = None


def change_list() -> str:
    """Every new, changed and omitted provision (worked out once: it takes a moment)."""
    global _changes
    if _changes is None:
        _changes = [{"act": c.act, "key": c.key, "kind": c.kind, "law": law.ABBR[c.act],
                     "title": cards.ref_title(c.act, c.key), "heading": changes_view.heading(c)}
                    for c in changes.all_changes()]
    eds = [{"law": law.ABBR[a], "then": changes.edition(changes.previous_source(a)),
            "now": changes.edition(law.text_source(a))} for a in law.ACTS if changes.previous_source(a)]
    return _j({"changes": _changes, "editions": eds})


def change_page(act: str, key: str) -> str:
    c = next(c for c in changes.changes(act) if c.key == key)
    return changes_view.change_html(c)


# ---------------------------------------------------------------- practice cases
def case_list() -> str:
    return _j({"topics": cases.TOPICS, "cases": [
        {"id": c.id, "topic": c.topic, "level": c.level, "title": c.title,
         "kind": {"itr": "Income tax", "str": "Sales tax", "wht": "Withholding"}[c.kind]} for c in cases.CASES]})


def case_start(case_id: str) -> str:
    """A case: its facts and task, the sections of its return to fill in, and a blank return to start from."""
    c = cases.BY_ID[case_id]
    act = "STA" if c.kind == "str" else "ITO"
    rules = load(int(c.tax_year))
    doc = returns.BLANK[c.kind](c.tax_year)
    if c.kind == "itr":
        doc["taxpayer"]["name"] = c.solution["taxpayer"].get("name", "")
        doc["taxpayer"]["age"] = c.solution["taxpayer"].get("age", 35)
    concepts = ", ".join(f"<a href='{i}'>{html.escape(knowledge.BY_ID[i].title)}</a>" for i in c.concepts
                         if i in knowledge.BY_ID)
    facts = (f"<h2>{html.escape(c.title)}</h2><p style='color:gray'>{html.escape(c.topic)} · {html.escape(c.level)} · "
             f"Tax Year {c.tax_year}</p><p>{linkify(c.facts, act).replace(chr(10), '<br>')}</p>"
             f"<p><b>Your task:</b> {linkify(c.task, act)}</p><p><b>Concepts practised:</b> {concepts}</p>")
    sections = []
    for s in returns.SECTIONS[c.kind](rules):
        sec = {"kind": s.kind, "name": s.name, "intro": s.intro, "key": s.key, "add": s.add,
               "fields": [{"path": f.path, "label": f.label, "kind": f.kind, "choices": f.choices,
                           "law": cite(f.law, act) if f.law else "", "help": f.help} for f in s.fields],
               "cols": [{"key": col.key, "header": col.header, "kind": col.kind, "choices": col.choices,
                         "default": col.default} for col in s.cols]}
        if s.kind == "wealth":
            sec["assets"] = [{"key": k, "label": label} for k, label in wealth.ASSETS]
            sec["liabilities"] = [{"key": k, "label": label} for k, label in wealth.LIABILITIES]
        sections.append(sec)
    return _j({"facts": facts, "kind": c.kind, "sections": sections, "blank": doc})


def _computation_html(steps: list, warnings: list, act: str) -> str:
    """A worked computation as a table: each part with its lines, amounts, law and the reason for each."""
    order = returns.STEP_ORDER
    steps = sorted(steps, key=lambda st: order.index(st[0]) if st[0] in order else len(order))
    out, part = "", None
    for p, label, amount, law_ref, note, concept_id, total in steps:
        if p != part:
            out += f"<tr class='part'><td colspan=3>{html.escape(p)}</td></tr>"
            part = p
        c = knowledge.BY_ID.get(concept_id)
        why = (f"<div class='why'>{linkify(note, act)}</div>" if note else "") + \
              (f"<div class='why'>Concept: <a href='{c.id}'>{html.escape(c.title)}</a></div>" if c else "")
        out += (f"<tr class='{'total' if total else ''}'><td>{html.escape(label)}{why}</td>"
                f"<td class='num{' neg' if amount < 0 else ''}'>{money(amount) if amount or total else ''}</td>"
                f"<td class='law'>{cite(law_ref, act) if law_ref else ''}</td></tr>")
    warn = "".join(f"<p class='warn'>⚠ {html.escape(w)}</p>" for w in warnings)
    return f"{warn}<table class='computation'>{out}</table>"


def compute(case_id: str, doc_json: str) -> str:
    c = cases.BY_ID[case_id]
    doc = json.loads(doc_json)
    rules = load(int(doc.get("tax_year") or c.tax_year))
    steps, warnings = returns.STEPS[c.kind](doc, rules)
    return _computation_html(steps, warnings, "STA" if c.kind == "str" else "ITO")


def model_answer(case_id: str) -> str:
    c = cases.BY_ID[case_id]
    steps, warnings = returns.model_steps(c)
    return _computation_html(steps, warnings, "STA" if c.kind == "str" else "ITO")


def check(case_id: str, doc_json: str) -> str:
    """Check my answer: every result, right or wrong, with a hint for what's wrong."""
    c = cases.BY_ID[case_id]
    feedback = cases.check(c, json.loads(doc_json))
    results = [f for f in feedback if not f.label.startswith("Entry:")]
    right = sum(f.ok for f in results)
    fmt = lambda v: money(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else str(v)  # noqa: E731
    rows = "".join(
        f"<tr class='{'ok' if f.ok else 'bad'}'><td>{'✓' if f.ok else '✗'}</td><td>{html.escape(f.label)}</td>"
        f"<td class='num'>{fmt(f.yours) if f.yours is not None else '—'}</td>"
        f"<td class='num'>{fmt(f.correct) if f.correct is not None else '—'}</td><td>{linkify(f.hint)}</td></tr>"
        for f in feedback)
    all_ok = all(f.ok for f in feedback)
    return (f"<p class='{'ok' if all_ok else 'bad'} big'><b>{right} of {len(results)} results correct</b>"
            + (" · All entries match the model answer. Well done!" if all_ok else
               " · Rows marked ✗ show where your entries or results differ. Fix them and check again.") + "</p>"
            f"<table class='feedback'><tr><th></th><th>Item</th><th>Yours</th><th>Correct</th><th>Hint</th></tr>"
            f"{rows}</table>")


def solution(case_id: str) -> str:
    """The model return, to compare entries with."""
    return _j(copy.deepcopy(cases.BY_ID[case_id].solution))


# ---------------------------------------------------------------- question bank
def quiz_start(topic: str, level: str) -> str:
    qs = quiz.questions(topic or None, level or None)
    return _j({"topics": quiz.TOPICS, "questions": [
        {"id": q.id, "topic": q.topic, "level": q.level, "text": q.text, "kind": q.kind, "options": list(q.options)}
        for q in qs]})


def quiz_check(qid: str, response: str) -> str:
    q = next(q for q in quiz.QUESTIONS if q.id == qid)
    answer = response if q.kind == "number" else int(response)
    ok = q.check(answer)
    act = "STA" if q.topic == "Sales tax" else "ITO"
    return _j({"ok": ok, "answer": q.answer if q.kind == "choice" else None,
               "html": (f"<p class='{'ok' if ok else 'bad'} big'><b>{'Correct' if ok else 'Not quite'}.</b>"
                        + ("" if ok else f" The answer is <b>{html.escape(quiz.answer_text(q))}</b>.") + "</p>"
                        f"<p>{linkify(q.explain, act)}</p>"
                        + (f"<p style='color:gray'>{cite(q.law, act)}</p>" if q.law else "")
                        + (f"<p><a href='{q.concept}'>Read the concept →</a></p>" if q.concept else ""))})


# ---------------------------------------------------------------- Ask TaxDesk
def ask(question: str) -> str:
    """The built-in tutor's answer, as Markdown with law: links."""
    global _bot
    _bot = _bot or assistant.Bot(year=max(available_years()))
    return _bot.ask(question)


def suggestions() -> str:
    return _j(assistant.SUGGESTIONS)
